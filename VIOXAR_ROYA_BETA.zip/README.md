# VIOXAR ROYALE (BETA)

Battle royale 3D que roda direto no navegador (Android e PC).

## Publicar no GitHub Pages
1. Crie um repositório e envie **todos os arquivos desta pasta** (o `index.html` precisa ficar na raiz do repositório).
2. No GitHub: **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)` → Save**.
3. Aguarde ~1 minuto. O jogo abre em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

## Estrutura
```
index.html        página principal (raiz)
css/style.css     estilos
js/weapons.js     catálogo de armas
js/loading.js     telas de carregamento
js/game.js        lógica do jogo
js/friends.js     amigos + squad (SOLO/DUO/SQUAD)
js/platform.js    ajustes Android/PC + registro do PWA
images/           ícones das armas e imagens de carregamento
icons/ favicon.png manifest.json sw.js   instalação como app (PWA) e modo offline
```
Sons são gerados por código (Web Audio) e os modelos 3D são construídos por código (three.js), por isso não há arquivos de áudio ou `.glb`.

## Dependências externas (precisam de internet no 1º acesso)
- three.js r128 (cdnjs, com reserva automática no jsDelivr)
- Fonte Teko (Google Fonts; se falhar, usa Impact)

Para rodar 100% sem CDN, baixe `three.min.js` (r128) para `js/vendor/` e troque a tag `<script src="https://cdnjs...">` em `index.html` por `js/vendor/three.min.js`.

## Testar localmente
Abra um terminal na pasta e rode `python3 -m http.server 8000`, depois acesse `http://localhost:8000`.
(Abrir o `index.html` com duplo clique não registra o PWA; use o servidor local.)

## Dados salvos
Contas, moedas e amigos ficam no `localStorage` do navegador (neste aparelho). Não há servidor.
