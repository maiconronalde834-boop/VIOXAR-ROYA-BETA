/* ================= SISTEMA DE AMIGOS + SQUAD ================= */
;(()=>{try{
const TM={solo:1,duo:2,sq:4},TN={solo:'SOLO',duo:'DUO',sq:'SQUAD'},cap=()=>TM[S.tm]||4;
/* BOTS DE TESTE: ids que você pode digitar na aba ADICIONAR. Para criar mais, some uma linha aqui. */
const BOTS=[{id:5120001,name:'Luizz',av:'🦊',ch:5},{id:5120002,name:'Wolf',av:'🐺',ch:2},{id:5120003,name:'Barbie',av:'👸',ch:3}];
let squad=[],pend=new Set(),who=null,tab='j',q='',found=null,msg='',tt=0;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const accs=()=>{try{const a=JSON.parse(localStorage.getItem('tempesta_acc'));return a&&a.users?Object.values(a.users):[]}catch(e){return[]}};
const info=id=>{id=+id;const b=BOTS.find(x=>x.id==id);if(b)return{id,name:b.name,av:b.av,bot:1};const a=accs().find(x=>x.id==id);return a?{id,name:a.name,av:'🧑',bot:0}:null};
const fr=()=>{if(!Array.isArray(S.fr)){S.fr=BOTS.map(b=>b.id);save()}return S.fr};
/* ---- personagens 3D dos amigos no lobby (em fila, como no Free Fire) ---- */
const POS=[-1.25,1.25,-2.5],mods={},V=new T.Vector3();
const spec=p=>{let ch=p.bot?p.ch:0;if(!p.bot){try{ch=JSON.parse(localStorage.getItem('tempesta_u_'+p.id)||'{}').ch|0}catch(e){}}return CH[ch]||CH[0]};
function sync(){
 for(const id in mods)if(!squad.includes(+id)){sc.remove(mods[id]);delete mods[id]}
 squad.forEach((id,i)=>{if(!mods[id]){const p=info(id);if(!p)return;try{const g=buildChar(spec(p));sc.add(g);mods[id]=g}catch(e){console.error(e);return}}
  const g=mods[id];g.position.set(POS[i],.15,0);g.rotation.y=POS[i]<0?.6:-.2;g.visible=mode=='lobby'&&!lobby.hidden})}
function place(){const sl=document.querySelectorAll('#sqs .sqs');if(!sl.length||mode!='lobby')return;const W=innerWidth,H=innerHeight;
 sl.forEach((el,i)=>{V.set(POS[i],.15,0).project(cam);const x=(V.x+1)/2*W,fy=(1-V.y)/2*H;V.set(POS[i],1,0).project(cam);const my=(1-V.y)/2*H;
  el.style.left=x+'px';el.style.bottom='auto';el.style.top=(el.classList.contains('sqem')?my-36:fy+2)+'px'})}
const friends=()=>fr().map(info).filter(Boolean);

const st=document.createElement('style');st.textContent=`
#sqp{position:absolute;right:52px;top:calc(clamp(32px,9vh,48px) + 100px);bottom:calc(92px + env(safe-area-inset-bottom));width:min(220px,34vw);display:flex;flex-direction:column;background:var(--panel);border-top:3px solid var(--sun);transition:transform .25s;z-index:2;backdrop-filter:blur(4px)}
#sqp.cl{display:none!important}
#sqx{background:#243566;color:#fff;font:700 16px var(--f);padding:1px 9px;margin-left:8px}
#sqp h4 span{flex:1}
#sqo{position:absolute;right:52px;top:calc(clamp(32px,9vh,48px) + 100px);z-index:2;background:var(--panel);border-top:3px solid var(--sun);color:#fff;font:600 18px var(--f);padding:6px 14px}
#sqo.dis{opacity:.55;border-top-color:#666}
#sqp:not(.cl)~#sqo{display:none}
#tms{position:absolute;right:52px;top:calc(clamp(32px,9vh,48px) + 62px);display:flex;gap:3px;z-index:2}
#tms button{background:var(--panel);font:700 16px var(--f);padding:2px 12px;border-bottom:3px solid transparent}
#tms button.on{background:var(--sun);color:var(--ink)}
#lobby.nolog #tms,#lobby.nolog #sqo{display:none}
#sqp h4{margin:0;padding:5px 10px;display:flex;justify-content:space-between;align-items:center;font:600 16px var(--f);background:rgba(255,255,255,.06)}
#sqp h4 b{color:var(--sun)}
#sql{flex:1;overflow:auto;padding:4px;display:flex;flex-direction:column;gap:4px;touch-action:pan-y}
.fr{display:grid;grid-template-columns:34px 1fr auto;gap:7px;align-items:center;background:linear-gradient(90deg,rgba(255,255,255,.1),rgba(255,255,255,.03));padding:4px 6px}
.fr .a{width:34px;height:34px;border-radius:6px;background:#243566;display:grid;place-items:center;font-size:20px}
.fr b{display:block;font:600 17px/1 var(--f);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fr small{font:600 12px var(--f);color:#5fe38a}.fr small.off{color:#8b90a8}
.fb{background:var(--sun);color:var(--ink);font:700 14px var(--f);padding:5px 8px;white-space:nowrap}
.fb:disabled{background:#3a4468;color:#aab}.fb.g{background:#243566;color:#fff}
#sqe{padding:10px;font:600 15px var(--f);opacity:.75;text-align:center}
#sqa{margin:4px;background:#243566;font:600 15px var(--f);padding:3px}
#sqs{position:absolute;inset:0;pointer-events:none}
.sqs{position:absolute;bottom:calc(11vh + 6px);transform:translateX(-50%);width:clamp(74px,13vw,104px);text-align:center;pointer-events:auto}
.sqs .av{height:clamp(42px,12vh,70px);display:grid;place-items:center;font-size:clamp(34px,9vh,54px);filter:drop-shadow(0 0 10px var(--volt))}
.sqs .sqpl{background:linear-gradient(90deg,rgba(255,194,51,.85),rgba(120,70,0,.8));padding:2px 4px;font:700 15px/1.1 var(--f);color:#fff;text-shadow:0 1px 2px #000;clip-path:polygon(6% 0,100% 0,94% 100%,0 100%)}
.sqs .sqpl small{display:block;font:600 11px var(--f);opacity:.85}
.sqs .k{position:absolute;right:-2px;top:0;background:rgba(0,0,0,.7);color:#fff;font-size:12px;padding:1px 6px;border-radius:50%}
.sqs.sqem{opacity:.85}.sqs.sqem .av{filter:none;border:2px dashed rgba(255,255,255,.55);border-radius:50%;width:clamp(40px,11vh,60px);height:clamp(40px,11vh,60px);margin:0 auto 4px;font-size:clamp(22px,6vh,34px);color:#fff}
.sqs.sqem .sqpl{background:rgba(0,0,0,.55);font-weight:600}
#sqc{position:absolute;left:50%;bottom:calc(4vh);transform:translateX(-50%);background:var(--panel);border-bottom:3px solid var(--sun);padding:3px 18px;font:700 20px var(--f);pointer-events:none}
#lobby.nolog #sqp,#lobby.nolog #sqs,#lobby.nolog #sqc{display:none}
#sqm{position:fixed;left:50%;bottom:16vh;transform:translateX(-50%);z-index:30;background:rgba(0,0,0,.85);border-left:4px solid var(--sun);padding:7px 18px;font:600 19px var(--f);pointer-events:none;opacity:0;transition:opacity .2s;white-space:nowrap}
#sqm.on{opacity:1}
#frs{position:fixed;inset:0;z-index:18;pointer-events:auto;background:radial-gradient(ellipse at 70% 0,#3a2166 0,#150d2b 55%,#0a0816);display:flex;padding:max(12px,env(safe-area-inset-top)) 14px 12px;gap:14px;box-sizing:border-box}
#frs[hidden]{display:none}
.ft{width:clamp(130px,22%,210px);display:flex;flex-direction:column;gap:8px;padding-top:38px}
.ft button{background:rgba(255,255,255,.07);padding:10px 12px;font:600 clamp(16px,4.4vh,22px) var(--f);text-align:left;border-bottom:2px solid rgba(255,255,255,.1)}
.ft button.on{background:var(--sun);color:var(--ink)}
.fm{flex:1;min-width:0;display:flex;flex-direction:column}
.fh{display:flex;justify-content:space-between;align-items:center;font:600 clamp(16px,4.6vh,24px) var(--f);min-height:34px}
.fh button{background:rgba(255,255,255,.1);font:700 22px var(--f);padding:2px 14px}
.fh span{opacity:.85}
.fs{display:flex;gap:6px;margin:6px 0}
.fs input{flex:1;min-width:0;box-sizing:border-box;padding:8px 10px;font-size:16px;background:rgba(0,0,0,.45);color:#fff;border:1px solid var(--volt)}
.fs button{background:var(--sun);color:var(--ink);font:700 20px var(--f);padding:0 16px}
.fl{flex:1;overflow:auto;display:flex;flex-direction:column;gap:6px;touch-action:pan-y}
.fl .fr{grid-template-columns:46px 1fr auto auto;padding:6px 10px;background:linear-gradient(90deg,rgba(255,255,255,.13),rgba(255,255,255,.04))}
.fl .fr .a{width:46px;height:46px;font-size:28px}.fl .fr b{font-size:22px}.fl .fr small{font-size:14px}
.fl .fr .fb{font-size:17px;padding:7px 12px}
.sqfi{font:600 15px var(--f);color:#ffb3ba;min-height:18px;margin:2px 0}.sqfi.ok{color:#8affb0}
.ft2{font:600 15px var(--f);opacity:.8;margin:8px 0 2px}
`;document.head.appendChild(st);

const lobby=$('#lobby');
lobby.insertAdjacentHTML('beforeend','<div id=sqs></div><div id=sqc></div><div id=tms><button data-tm=solo>SOLO</button><button data-tm=duo>DUO</button><button data-tm=sq>SQUAD</button></div><div id=sqp class=cl><h4><span>AMIGOS ONLINE</span><b id=sqn></b><button id=sqx>✕</button></h4><div id=sql></div><button id=sqa>＋ ADICIONAR AMIGO</button></div><button id=sqo></button>');
const fs=document.createElement('div');fs.id='frs';fs.hidden=true;document.body.appendChild(fs);
const tm=document.createElement('div');tm.id='sqm';document.body.appendChild(tm);
const toast=t=>{tm.textContent=t;tm.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>tm.classList.remove('on'),2200)};

const inSq=id=>squad.includes(+id);
const btn=p=>!p.bot?'<button class="fb" disabled>OFF-LINE</button>':inSq(p.id)?'<button class="fb g" data-a=kick data-id='+p.id+'>NO SQUAD ✕</button>':pend.has(p.id)?'<button class="fb" disabled>CONVIDANDO…</button>':'<button class="fb" data-a=inv data-id='+p.id+'>CONVIDAR</button>';
const row=(p,x)=>'<div class=fr><i class=a>'+p.av+'</i><div><b>'+esc(p.name)+'</b><small class="'+(p.bot?'':'off')+'">'+(p.bot?'Online':'off-line')+' · ID '+p.id+'</small></div>'+btn(p)+(x||'')+'</div>';

function render(){
 if(who!==S.id){who=S.id;squad=[];pend.clear();found=null;msg='';q=''}
 if(!S.id)return;
 const fl=friends(),on=fl.filter(p=>p.bot);
 document.querySelectorAll('#tms button').forEach(b=>b.classList.toggle('on',b.dataset.tm==(S.tm||'sq')));
 if(cap()<2)$('#sqp').classList.add('cl');
 $('#sqo').textContent=cap()<2?'👥 MODO SOLO':'👥 AMIGOS ('+on.length+')';$('#sqo').classList.toggle('dis',cap()<2);
 $('#sqc').style.display=cap()<2?'none':'';
 $('#sqn').textContent=TN[S.tm||'sq']+' '+(squad.length+1)+'/'+cap();
 $('#sql').innerHTML=on.length?on.map(row).join(''):'<div id=sqe>Nenhum amigo online.<br>Adicione amigos pelo ID.</div>';
 $('#sqc').textContent=TN[S.tm||'sq']+' '+(squad.length+1)+'/'+cap();
 const pos=['-15vw','15vw','-27vw'];
 $('#sqs').innerHTML=pos.slice(0,cap()-1).map((x,i)=>{const p=squad[i]&&info(squad[i]);
  return p?'<div class=sqs style="left:calc(50% + '+x+')"><button class=k data-a=kick data-id='+p.id+'>✕</button><div class=sqpl>'+esc(p.name)+'<small>ID '+p.id+'</small></div></div>'
  :'<div class="sqs sqem" data-a=openp style="left:calc(50% + '+x+')"><div class=av>＋</div><div class=sqpl>CHAMAR</div></div>'}).join('');
 sync();place();
 if(!fs.hidden)renderFs(fl);
}
function renderFs(fl){
 fl=fl||friends();
 let h='<div class=ft><button data-a=tab data-t=j class="'+(tab=='j'?'on':'')+'">AMIGOS DE JOGO</button><button data-a=tab data-t=a class="'+(tab=='a'?'on':'')+'">ADICIONAR</button></div><div class=fm><div class=fh><span>'+(tab=='j'?'AMIGOS DE JOGO '+fl.length+'/36':'ADICIONAR AMIGO')+'</span><span>'+TN[S.tm||'sq']+' '+(squad.length+1)+'/'+cap()+'</span><button data-a=close>✕</button></div>';
 if(tab=='j'){
  h+='<div class=fl>'+(fl.length?fl.map(p=>row(p,'<button class="fb g" data-a=del data-id='+p.id+'>🗑</button>')).join(''):'<div id=sqe>Você ainda não tem amigos. Use a aba ADICIONAR.</div>')+'</div>';
 }else{
  const ids=new Set(fl.map(p=>p.id)),sug=[...BOTS.map(b=>info(b.id)),...accs().map(a=>info(a.id))].filter(p=>p&&!ids.has(p.id)&&p.id!=S.id);
  h+='<div class=fs><input id=fq inputmode=numeric placeholder="Insira o ID do jogador para procurar" value="'+esc(q)+'"><button data-a=find>🔍</button></div><div class="sqfi'+(found&&!msg?' ok':'')+'">'+esc(msg||'Seu ID: '+S.id)+'</div><div class=fl>'
  +(found?'<div class=fr><i class=a>'+found.av+'</i><div><b>'+esc(found.name)+'</b><small>ID '+found.id+'</small></div><button class=fb data-a=add data-id='+found.id+'>＋ ADICIONAR</button><span></span></div>':'')
  +(sug.length?'<div class=ft2>PESSOAS QUE VOCÊ TALVEZ CONHEÇA</div>'+sug.map(p=>'<div class=fr><i class=a>'+p.av+'</i><div><b>'+esc(p.name)+'</b><small class="'+(p.bot?'':'off')+'">'+(p.bot?'Online':'off-line')+' · ID '+p.id+'</small></div><button class=fb data-a=add data-id='+p.id+'>＋ ADICIONAR</button><span></span></div>').join(''):'')+'</div>';
 }
 fs.innerHTML=h+'</div>';
}
const openFs=t=>{if(!S.id){toast('Faça login para usar amigos');return}tab=t||'j';found=null;msg='';fs.hidden=false;renderFs();beep(660,.05)};

function invite(id){const p=info(id);if(!p)return;
 if(cap()<2)return toast('Modo SOLO: troque para DUO ou SQUAD para chamar amigos');
 if(!p.bot)return toast(p.name+' está off-line');
 if(inSq(id)||pend.has(+id))return;
 if(squad.length+pend.size>=cap()-1)return toast('Squad cheio! Máximo de '+cap()+' jogadores');
 pend.add(+id);beep(520,.06);toast('Convite enviado para '+p.name);render();
 setTimeout(()=>{pend.delete(+id);if(who===S.id&&squad.length<cap()-1&&!inSq(id)){squad.push(+id);toast(p.name+' entrou no squad!');beep(880,.1)}render()},1100+Math.random()*900)}
function search(){const v=(($('#fq')||{}).value||q).trim();q=v;found=null;msg='';
 if(!/^\d{3,12}$/.test(v))msg='Digite um ID válido (apenas números)';
 else if(+v==S.id)msg='Esse é o seu próprio ID';
 else if(fr().includes(+v))msg='Esse jogador já é seu amigo';
 else{found=info(v);if(!found)msg='Nenhum jogador encontrado com esse ID'}
 renderFs();const i=$('#fq');if(i)i.value=q}
function add(id){id=+id;const p=info(id);if(!p||fr().includes(id))return;if(fr().length>=36)return toast('Lista de amigos cheia (36)');
 fr().push(id);save();if(found&&found.id==id)found=null;q='';msg='';toast(p.name+' foi adicionado aos amigos');beep(880,.1);render();renderFs()}
function del(id){id=+id;S.fr=fr().filter(x=>x!=id);squad=squad.filter(x=>x!=id);save();toast('Amigo removido');render()}

const act=e=>{const el=e.target.closest('[data-a]');if(!el)return;const a=el.dataset.a,id=el.dataset.id;e.stopPropagation();
 if(a=='inv')invite(id);else if(a=='kick'){squad=squad.filter(x=>x!=id);beep(330,.05);toast('Removido do squad');render()}
 else if(a=='openp')setP(true)
 else if(a=='tab'){tab=el.dataset.t;found=null;msg='';renderFs()}
 else if(a=='close'){fs.hidden=true;beep(330,.05)}
 else if(a=='find')search();else if(a=='add')add(id);else if(a=='del')del(id)};
fs.addEventListener('click',act);lobby.addEventListener('click',act);
fs.addEventListener('input',e=>{if(e.target.id=='fq')q=e.target.value});
fs.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.id=='fq')search()});
const setP=o=>{$('#sqp').classList.toggle('cl',!o);render()};
$('#sqx').onclick=()=>{setP(false);beep(330,.05)};
$('#sqo').onclick=()=>{if(cap()<2)return toast('Modo SOLO: troque para DUO ou SQUAD para chamar amigos');setP(true);beep(660,.05)};
function setTm(m){S.tm=m;save();pend.clear();if(squad.length>cap()-1)squad=squad.slice(0,cap()-1);beep(600,.05);toast('Modo '+TN[m]+(m=='solo'?'':' · até '+TM[m]+' jogadores'));render()}
document.querySelectorAll('#tms button').forEach(b=>b.onclick=()=>setTm(b.dataset.tm));
$('#sqa').onclick=()=>openFs('a');
const ab=document.querySelector('[data-x=amigos]');if(ab)ab.onclick=e=>{e.stopPropagation();openFs('j')};
const _an=anim;anim=function(g,t,sp,air){const r=_an.apply(this,arguments);
 if(g===me&&mode=='lobby'){const vis=!lobby.hidden;let i=0;for(const id of squad){const m=mods[id];if(m){m.visible=vis;if(vis)_an(m,t+.9*(i+1),0,false)}i++}if(vis)place()}return r};
const _sm=setMode;setMode=function(m){const r=_sm.apply(this,arguments);for(const id in mods)mods[id].visible=m=='lobby';return r};
setInterval(()=>{if(who!==S.id)render()},400);
render();
window.FRIENDS={open:openFs,invite,add,squad:()=>squad.slice()};
}catch(err){console.error('FRIENDS',err)}})();
