/* Imagens da tela de carregamento (images/loading/) */
const LDI=["images/loading/loading-1.jpg", "images/loading/loading-2.jpg", "images/loading/loading-3.jpg", "images/loading/loading-4.jpg"],LDN={i:Math.random()*4|0};
