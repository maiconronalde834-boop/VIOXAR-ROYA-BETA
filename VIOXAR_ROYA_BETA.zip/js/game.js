
const T=THREE,$=s=>document.querySelector(s);
// ---------- estado salvo ----------
let S={name:'Jogador',id:0,coins:0,dia:0,ch:0,set:'',gift:'',sens:5,q:1,fps:60,vol:.5,showfps:false,mode:0,sky:0,grav:1,spd:1,flt:0,hr:0,gm:'br',rp:{br:0,cs:0},pet:'🐶',dly:'',inv:[],eq:{},spins:0};
const S0=JSON.parse(JSON.stringify(S));try{const sid=+localStorage.getItem('tempesta_sess');if(sid){Object.assign(S,JSON.parse(localStorage.getItem('tempesta_u_'+sid)||'{}'));S.id=sid}}catch(e){}
S.mode=S.gm=='pe'?1:0;
if(S.sh==null)S.sh=+S.q>0?1:0;

const save=()=>{try{if(S.id)localStorage.setItem('tempesta_u_'+S.id,JSON.stringify(S))}catch(e){}};
let AC;const beep=(f=440,d=.08)=>{if(!S.vol)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain();o.frequency.value=f;g.gain.value=.15*S.vol;o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}catch(e){}};
// ---------- áudio: tiro por arma, recarga, toque de início e música original (tudo sintetizado, sem arquivos) ----------
const ac=()=>{try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state=='suspended')AC.resume();return AC}catch(e){return null}},midif=n=>440*2**((n-69)/12);
const SFX={kinds:['rifle','pistol','smg','shotgun'],nb:null,lt:0,
 noise(a){return SFX.nb||(()=>{const n=a.createBuffer(1,a.sampleRate,a.sampleRate),d=n.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;return SFX.nb=n})()},
 ns(a,t,f,q,dur,vol,type='bandpass',out=a.destination){const o=a.createBufferSource(),fl=a.createBiquadFilter(),g=a.createGain();o.buffer=SFX.noise(a);fl.type=type;fl.frequency.value=f;fl.Q.value=q;g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(fl);fl.connect(g);g.connect(out);o.start(t,Math.random()*.5);o.stop(t+dur+.02)},
 tone(a,t,f0,f1,dur,vol,type='sine',out=a.destination){const o=a.createOscillator(),g=a.createGain();o.type=type;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+dur);g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(g);g.connect(out);o.start(t);o.stop(t+dur+.02)},
 // cada arma tem seu timbre: [estalo, duração, grave do disparo, força do grave, eco]
 shot(k='rifle',v=1){if(!S.vol||v<.03)return;const a=ac();if(!a)return;const t=a.currentTime;if(t-SFX.lt<.03)return;SFX.lt=t;const w=S.vol*v*.6,
  [f,d,th,tv,tl]={rifle:[2600,.11,150,.55,.22],pistol:[3600,.07,220,.45,.14],smg:[3000,.06,180,.4,.12],shotgun:[1300,.28,90,.9,.45],sniper:[1800,.35,70,1,.7]}[k]||[2600,.11,150,.55,.22];
  SFX.ns(a,t,f,.7,d,.8*w);SFX.ns(a,t,f/4,.8,d*1.8,.7*w,'lowpass');SFX.tone(a,t,th,38,.14,tv*w);SFX.ns(a,t+.02,600,.5,tl,.14*w,'lowpass')},
 reload(){if(!S.vol)return;const a=ac();if(!a)return;const t=a.currentTime,w=S.vol*.5;
  for(const[o,f]of[[0,900],[.55,700],[1,350]]){SFX.tone(a,t+o,f,f/2,.05,.25*w,'square');SFX.ns(a,t+o,3000,1,.04,.5*w)}},
 start(){if(!S.vol)return;const a=ac();if(!a)return;const t=a.currentTime,w=S.vol;
  SFX.ns(a,t,700,.8,.35,.5*w);SFX.tone(a,t,130,45,.3,.6*w);[440,660,880].forEach((f,i)=>SFX.tone(a,t+i*.09,f,f*1.01,.3,.22*w,'triangle'))},
 tick(){if(!S.vol)return;const a=ac();if(a)SFX.tone(a,a.currentTime,1900,1700,.05,.14*S.vol)},
 hit(){if(!S.vol)return;const a=ac();if(!a)return;const t=a.currentTime;SFX.tone(a,t,170,60,.13,.35*S.vol);SFX.ns(a,t,500,.6,.1,.3*S.vol,'lowpass')}};
// música: Ré menor, 80 BPM, pads + baixo + harpa suave; as notas da melodia mudam a cada volta para não enjoar
const MUS={on:0,next:0,step:0,ch:[[50,53,57,60,64],[46,50,53,57,60],[43,46,50,53,57],[45,50,52,55,59]],rt:[38,34,31,33],mo:[1,3,2,4,3,1,4,2],
 start(){if(MUS.on)return;const a=ac();if(!a)return;MUS.on=1;const m=MUS.m=a.createGain(),bus=MUS.bus=a.createGain(),d=a.createDelay(1),fb=a.createGain(),wt=a.createGain();
  m.gain.value=0;d.delayTime.value=.375;fb.gain.value=.35;wt.gain.value=.35;bus.connect(m);bus.connect(d);d.connect(fb);fb.connect(d);d.connect(wt);wt.connect(m);m.connect(a.destination);
  MUS.next=a.currentTime+.1;setInterval(MUS.tick,100)},
 tick(){const a=AC;if(!a||a.state!='running')return;MUS.m.gain.setTargetAtTime((S.vol||0)*(mode=='game'?.09:.2),a.currentTime,.3);while(MUS.next<a.currentTime+.4){MUS.play(MUS.step++,MUS.next);MUS.next+=.1875}},
 play(s,t){const a=AC,c=(s>>4)%4,i=s&15,ch=MUS.ch[c],bus=MUS.bus,gm=mode=='game',tone=SFX.tone;
  if(i==0){const fl=a.createBiquadFilter();fl.type='lowpass';fl.frequency.value=1000;fl.connect(bus);
   for(const n of ch)for(const dt of[-7,7]){const o=a.createOscillator(),g=a.createGain();o.type='triangle';o.frequency.value=midif(n);o.detune.value=dt;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.03,t+.9);g.gain.linearRampToValueAtTime(0,t+3.4);o.connect(g);g.connect(fl);o.start(t);o.stop(t+3.5)}}
  if(i==0||i==10)tone(a,t,midif(MUS.rt[c]),midif(MUS.rt[c])*.995,i?.8:1.6,.24,'sine',bus);
  if(i%2==0&&Math.random()<(i%4?.5:.85)){const n=ch[(MUS.mo[i>>1]+(Math.random()<.25?1:0))%5]+12;tone(a,t,midif(n),midif(n)*.998,.6,.08,'triangle',bus)}
  if(i==12&&c%2==0){tone(a,t,midif(ch[4]+24),midif(ch[4]+24)*.999,1.6,.035,'sine',bus);tone(a,t,midif(ch[4]+24)*2.01,midif(ch[4]+24)*2,.8,.012,'sine',bus)}
  if(!gm){if(i%8==0)tone(a,t,110,42,.18,.15,'sine',bus);if(i==4||i==12)SFX.ns(a,t,7500,.5,.04,.03,'highpass',bus)}}};
['pointerdown','keydown'].forEach(k=>addEventListener(k,()=>{ac();MUS.start()},{once:true}));
document.addEventListener('visibilitychange',()=>{if(AC)document.hidden?AC.suspend():AC.resume()});
// ---------- personagens (originais) ----------
const CH=[
{n:'Kaelo',d:'Explorador veloz da costa. Sempre o primeiro a pousar.',sk:0xd9a273,h:0x2b1b12,hs:0,sh:0xe63946,pa:0x1d3557,sw:0xffffff},
{n:'Nayra',d:'Atiradora paciente das montanhas. Fala pouco, erra menos.',sk:0x8d5a3b,h:0x111111,hs:1,sh:0xffb703,pa:0x264653,sw:0xf1faee},
{n:'Torin',d:'Ex-lenhador de chapéu verde. Conhece cada floresta do mapa.',sk:0xf0c8a0,h:0xb5651d,hs:2,sh:0x2a9d8f,pa:0x3d3d3d,sw:0xe9c46a},
{n:'Lúmen',d:'Engenheira de luzes e raios. Cabelo rosa, ideias elétricas.',sk:0xc68642,h:0xff4fa3,hs:1,sh:0x7b2cbf,pa:0xf77f00,sw:0xffffff},
{n:'Brisa',d:'Surfista do litoral norte. Leve, rápida, de bom humor.',sk:0xffdbac,h:0x222a68,hs:0,sh:0x48cae4,pa:0xffffff,sw:0x023e8a},
{n:'Rakan',d:'Veterano de boné e jaqueta cinza. Calmo mesmo sob a tempestade.',sk:0x6b4226,h:0x0a0a0a,hs:2,sh:0x333333,pa:0x6a994e,sw:0xbc4749}];
const KING={n:'Rei Dourado',d:'Conjunto mítico: armadura dourada com capa, luz nas bordas, partículas flutuantes e aura que cresce quando você fica parado.',rar:'Mítica',rei:1,sk:0xf2b92e,h:0xffe27a,hs:0,sh:0xf2b92e,pa:0xc58a14,sw:0x8a5a0a};
const M=c=>new T.MeshLambertMaterial({color:c});
const mk=(w,h,d,c)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),M(c));m.castShadow=true;return m};
const add=(p,w,h,d,c,x,y,z)=>{const m=mk(w,h,d,c);m.position.set(x,y,z);p.add(m);return m};
// ---------- estilo voxel: tudo feito de cubos com textura pixelada (leve p/ Android) ----------
const VG={},VT={},VMC={},vbox=(w,h,d)=>{const k=w+'|'+h+'|'+d;return VG[k]||(VG[k]=new T.BoxGeometry(w,h,d))};
const vhash=(x,y,s)=>{let n=Math.imul(x+7,374761393)^Math.imul(y+13,668265263)^Math.imul(s+3,1274126177);n=Math.imul(n^(n>>>13),1274126177);return((n^(n>>>16))>>>0)%1000/1000};
const vsh=(c,f)=>`rgb(${Math.min(255,(c>>16&255)*f|0)},${Math.min(255,(c>>8&255)*f|0)},${Math.min(255,(c&255)*f|0)})`,vdk=(c,f)=>((c>>16&255)*f|0)<<16|((c>>8&255)*f|0)<<8|(c&255)*f|0;
const vtex=(k,w,h,col,amp=.22)=>VT[k]||(VT[k]=(()=>{const cv=document.createElement('canvas');cv.width=w;cv.height=h;const x=cv.getContext('2d');for(let j=0;j<h;j++)for(let i=0;i<w;i++){x.fillStyle=vsh(col(i,j),1-amp/2+vhash(i,j,w*h+k.length)*amp);x.fillRect(i,j,1,1)}const t=new T.CanvasTexture(cv);t.magFilter=t.minFilter=T.NearestFilter;t.generateMipmaps=false;return t})());
const vmat=(k,w,h,col,o)=>VMC[k]||(VMC[k]=new T.MeshLambertMaterial(Object.assign({map:vtex(k,w,h,col)},o)));
const vp=(p,geo,m,x,y,z)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;p.add(o);return o};
const GUNM=[M(0x2b2f3a),M(0x6b7488)];
// fuzil em blocos preso à mão direita (aparece só quando armado)
function addGun(a,u){const gn=new T.Group();u.mag=new T.Object3D();gn.position.x=.16;gn.visible=false;a.add(gn);u.gun=gn;u.bk=new T.Group();u.body.add(u.bk)}
// proporções de bloco: cabeça 8px, tronco 8x12, braços e pernas 4x12 (1px = 0,056)
function buildChar(c){if(c.rei)return buildKing(c);if(c.sombra)return buildSombra(c);const g=new T.Group(),u=g.userData,rt=new T.Group(),b=new T.Group(),hs=c.hs,sk=c.sk,hr=c.h,sh=c.sh,pa=c.pa,sw=c.sw,K=sk+'|'+hr+'|'+hs+'|';
 g.add(rt);rt.add(b);b.position.y=.675;u.rt=rt;u.body=b;
 const fr=(i,j)=>(j<2||(j==2&&(i<1||i>6))||(hs==1&&(i<1||i>6)))?hr:(j==4&&(i==1||i==6))?0xffffff:(j==4&&(i==2||i==5))?0x2a2f6e:(j==6&&(i==3||i==4))?vdk(sk,.7):sk;
 const S=vmat(K+'s',8,8,(i,j)=>hs==1||j<3?hr:sk),Tp=vmat(K+'t',8,8,()=>hr),Bt=vmat('sk'+sk,8,8,()=>sk),Fr=vmat(K+'f',8,8,fr),Bk=vmat(K+'b',8,8,(i,j)=>hs==1||j<(hs==0?6:3)?hr:sk);
 const head=vp(b,vbox(.45,.45,.45),[S,S,Tp,Bt,Fr,Bk],0,.9,0),HM=vmat('h'+hr,4,4,()=>hr);u.head=head;
 vp(head,vbox(.47,.1,.47),HM,0,.215,0);
 if(hs==1)vp(head,vbox(.47,.46,.06),HM,0,-.02,-.25);
 if(hs==2)vp(head,vbox(.4,.04,.2),HM,0,.1,.3);
 const F=vmat(sh+'|'+pa+'|'+sk+'|bf',8,12,(i,j)=>j>=10?pa:(j<2&&i>=3&&i<=4)?sk:sh),O=vmat(sh+'|'+pa+'|bo',8,12,(i,j)=>j>=10?pa:sh);
 vp(b,vbox(.45,.675,.225),[O,O,O,O,F,O],0,.3375,0);
 const AM_=vmat('a'+sh+'|'+sk,4,9,(i,j)=>j<6?sh:sk),HD=vmat('hd'+sk,4,3,()=>sk),LG=vmat('l'+pa,4,10,()=>pa),FT=vmat('ft'+sw,4,2,()=>sw);
 const arm=s=>{const p=new T.Group();p.position.set(s*.3375,.645,0);vp(p,vbox(.225,.5,.225),AM_,0,-.25,0);vp(p,vbox(.245,.175,.245),HD,0,-.5875,0);b.add(p);return p};
 const leg=s=>{const p=new T.Group();p.position.set(s*.1125,.675,0);vp(p,vbox(.225,.563,.225),LG,0,-.2815,0);vp(p,vbox(.245,.113,.3),FT,0,-.6185,.03);rt.add(p);return p};
 u.aL=arm(1);u.aR=arm(-1);u.lL=leg(1);u.lR=leg(-1);addGun(u.aR,u);return g}
// ---------- skin mítica: REI DOURADO (armadura + capa + luz nas bordas + partículas + aura) ----------
let KT;const kglow=()=>{if(KT)return KT;const k=document.createElement('canvas');k.width=k.height=128;const x=k.getContext('2d'),r=x.createRadialGradient(64,64,0,64,64,64);r.addColorStop(0,'rgba(255,240,170,1)');r.addColorStop(.3,'rgba(255,200,60,.55)');r.addColorStop(1,'rgba(255,160,20,0)');x.fillStyle=r;x.fillRect(0,0,128,128);return KT=new T.CanvasTexture(k)};
function buildKing(c){const g=new T.Group(),u=g.userData,rt=new T.Group(),b=new T.Group();g.add(rt);rt.add(b);b.position.y=.675;u.rt=rt;u.body=b;
 const gold=new T.MeshLambertMaterial({map:vtex('kgold',8,8,()=>0xf2b92e,.3),emissive:0x7a4a00}),dk=new T.MeshLambertMaterial({map:vtex('kdark',8,8,()=>0xc58a14,.3),emissive:0x4a2c00}),under=M(0x14182c),
  blue=new T.MeshBasicMaterial({color:0x6fe6ff,fog:false}),capeM=new T.MeshLambertMaterial({color:0xe0a622,emissive:0x5a3600,side:T.DoubleSide}),
  edge=new T.LineBasicMaterial({color:0xfff0a8,fog:false}),edgeB=new T.LineBasicMaterial({color:0x7fe9ff,fog:false});
 // cada cubo ganha uma linha brilhante nas bordas (luz dourada)
 const part=(p,geo,m,x,y,z,e=edge)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;o.add(new T.LineSegments(new T.EdgesGeometry(geo),e));p.add(o);return o};
 const bx=(p,w,h,d,m,x,y,z,e)=>part(p,vbox(w,h,d),m,x,y,z,e);
 bx(b,.47,.675,.245,gold,0,.3375,0);bx(b,.34,.26,.05,dk,0,.5,.14);bx(b,.06,.1,.02,blue,0,.51,.172,edgeB);bx(b,.49,.1,.26,dk,0,.04,0);
 // elmo cúbico com viseira azul, crista, chifres e pluma
 const hd=bx(b,.47,.47,.47,gold,0,.9,0);u.head=hd;bx(hd,.37,.08,.02,blue,0,.02,.236,edgeB);bx(hd,.1,.14,.1,gold,0,.3,0);bx(hd,.06,.12,.06,dk,0,.42,0);
 for(const s of[1,-1]){bx(hd,.08,.14,.08,gold,s*.2,.3,0);bx(hd,.06,.1,.06,dk,s*.23,.42,0);bx(hd,.06,.22,.3,dk,s*.26,-.08,0)}
 bx(hd,.08,.3,.1,gold,0,.26,-.24).rotation.x=-.4;
 // ombreiras em degraus
 for(const s of[1,-1]){bx(b,.28,.09,.3,gold,s*.42,.71,0);bx(b,.2,.08,.22,dk,s*.46,.78,0);bx(b,.08,.14,.08,gold,s*.5,.89,0)}
 const arm=s=>{const p=new T.Group();p.position.set(s*.3375,.645,0);bx(p,.225,.5,.225,under,0,-.25,0);bx(p,.26,.2,.26,gold,0,-.12,0);bx(p,.25,.16,.25,dk,0,-.4,0);bx(p,.26,.175,.26,gold,0,-.5875,0);b.add(p);return p};
 const leg=s=>{const p=new T.Group();p.position.set(s*.1125,.675,0);bx(p,.225,.563,.225,under,0,-.2815,0);bx(p,.25,.26,.25,gold,0,-.15,0);bx(p,.25,.24,.25,gold,0,-.42,0);bx(p,.26,.113,.32,dk,0,-.6185,.03);rt.add(p);return p};
 u.aL=arm(1);u.aR=arm(-1);u.lL=leg(1);u.lR=leg(-1);addGun(u.aR,u);
 // capa em dois blocos (balança ao andar)
 const cp=new T.Group();cp.position.set(0,.655,-.15);b.add(cp);part(cp,new T.BoxGeometry(.5,.65,.03),capeM,0,-.325,0,edgeB);
 const cp2=new T.Group();cp2.position.y=-.65;cp.add(cp2);part(cp2,new T.BoxGeometry(.46,.6,.03),capeM,0,-.3,0,edgeB);
// aura (brilho ao redor + disco no chão) e partículas flutuantes
 const tex=kglow(),spr=new T.Sprite(new T.SpriteMaterial({map:tex,color:0xffd45a,blending:T.AdditiveBlending,transparent:true,depthWrite:false,fog:false}));spr.position.y=1;g.add(spr);
 const gd=new T.Mesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial({map:tex,color:0xffc233,blending:T.AdditiveBlending,transparent:true,depthWrite:false,fog:false,side:T.DoubleSide}));gd.rotation.x=-Math.PI/2;gd.position.y=.04;g.add(gd);
 const N=48,pp=new Float32Array(N*3),pr=[];for(let i=0;i<N;i++)pr.push([Math.random()*6.28,.35+Math.random()*.6,Math.random()*2.6,.12+Math.random()*.3,Math.random()<.5?1:-1]);
 const pg=new T.BufferGeometry();pg.setAttribute('position',new T.BufferAttribute(pp,3));
 const pts=new T.Points(pg,new T.PointsMaterial({map:tex,color:0xffe27a,size:.16,transparent:true,depthWrite:false,blending:T.AdditiveBlending,sizeAttenuation:true,fog:false}));pts.frustumCulled=false;g.add(pts);
 u.lt=0;u.idle=0;
 u.fx=(t,sp,air)=>{const dt=Math.min(.1,Math.abs(t-u.lt));u.lt=t;
  if(sp<.1&&!air)u.idle=Math.min(4,u.idle+dt);else u.idle=Math.max(0,u.idle-dt*3);
  const k=u.idle/4,pu=Math.sin(t*3),s=(2.2+2.4*k)*(1+.05*pu),Rr=1+k*.7;
  spr.scale.set(s,s*1.15,1);spr.material.opacity=.4+.5*k;gd.scale.set(1.8+3.2*k,1.8+3.2*k,1);gd.material.opacity=.35+.45*k;
  gold.emissiveIntensity=.9+.3*pu+.8*k;dk.emissiveIntensity=.8+.25*pu+.6*k;
  for(let i=0;i<N;i++){const q=pr[i],y=(q[2]+t*q[3])%2.6,a=q[0]+t*.7*q[4];pp[i*3]=Math.cos(a)*q[1]*Rr;pp[i*3+1]=.1+y;pp[i*3+2]=Math.sin(a)*q[1]*Rr}
  pg.attributes.position.needsUpdate=true;pts.material.size=.14+.1*k;
  const v=Math.min(sp,7);cp.rotation.x=.06+v*.07+(air?.6:0)+Math.sin(t*2.2)*.035;cp2.rotation.x=.08+v*.05+Math.sin(t*2.2-1.2)*.08};
 return g}
// ---------- skin LENDÁRIA: SOMBRA REAL (jaqueta preta + roxo neon, aura, partículas, coroa de energia, rastro e explosão no pulo) ----------
const SOMBRA={n:'Sombra Real',d:'Conjunto lendário: jaqueta com capuz e coroa neon, calça estilizada, tênis, máscara, aura roxa, partículas, coroa de energia e rastro ao correr.',rar:'Lendária',sombra:1,sk:0xf0c8a0,h:0x0b0912,hs:0,sh:0x0f0c18,pa:0x0b0910,sw:0xffffff};
const SOMB={U:{k:{value:800}},N:110,NP:40,ci:0,pi:0,root:null,eg:{},tx:{},gt:null,z4:null,
 cs:n=>'#'+n.toString(16).padStart(6,'0'),
 // textura pixel-art: fn(i,j) devolve [corBase, brilho|null]; o brilho vira mapa emissivo (neon que "acende" no escuro)
 mat(k,w,h,fn,ei=1){if(SOMB.tx[k])return SOMB.tx[k];
  const a=document.createElement('canvas'),e=document.createElement('canvas');a.width=e.width=w;a.height=e.height=h;
  const x=a.getContext('2d'),y=e.getContext('2d');y.fillStyle='#000';y.fillRect(0,0,w,h);
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){const[c,l]=fn(i,j);x.fillStyle=vsh(c,.92+vhash(i,j,w*h+k.length)*.16);x.fillRect(i,j,1,1);if(l!=null){y.fillStyle=SOMB.cs(l);y.fillRect(i,j,1,1)}}
  const tx=c=>{const t=new T.CanvasTexture(c);t.magFilter=t.minFilter=T.NearestFilter;t.generateMipmaps=false;return t};
  const m=new T.MeshLambertMaterial({map:tx(a),emissive:0xffffff,emissiveMap:tx(e),emissiveIntensity:ei});m.userData.ei=ei;return SOMB.tx[k]=m},
 gtex(){return SOMB.gt||(SOMB.gt=(()=>{const k=document.createElement('canvas');k.width=k.height=64;const x=k.getContext('2d'),r=x.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.35,'rgba(255,255,255,.5)');r.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=r;x.fillRect(0,0,64,64);return new T.CanvasTexture(k)})())},
 // pontos de luz com tamanho e brilho individuais (1 chamada de desenho por sistema)
 pmat(){return new T.ShaderMaterial({uniforms:SOMB.U,transparent:true,depthWrite:false,blending:T.AdditiveBlending,fog:false,
  vertexShader:'attribute float aS;attribute vec3 aC;varying vec3 vC;uniform float k;void main(){vC=aC;vec4 mv=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*mv;gl_PointSize=max(1.,aS*k/max(.1,-mv.z));}',
  fragmentShader:'varying vec3 vC;void main(){float d=length(gl_PointCoord-.5)*2.;float a=clamp(1.-d,0.,1.);a*=a;gl_FragColor=vec4(vC,a);}'})},
 // sistema de partículas do mundo (rastro, explosão do pulo): pool fixo, sem alocar nada durante o jogo
 init(){if(SOMB.root){SOMB.root.visible=true;return}
  const N=SOMB.N,NP=SOMB.NP,g=new T.Group(),p=new Float32Array(N*3),c=new Float32Array(N*3),s=new Float32Array(N),geo=new T.BufferGeometry();
  geo.setAttribute('position',new T.BufferAttribute(p,3));geo.setAttribute('aC',new T.BufferAttribute(c,3));geo.setAttribute('aS',new T.BufferAttribute(s,1));
  const pts=new T.Points(geo,SOMB.pmat());pts.frustumCulled=false;g.add(pts);
  SOMB.z4=new T.Matrix4().makeScale(0,0,0);SOMB.o=new T.Object3D();SOMB.o.rotation.order='YXZ';SOMB.cl=new T.Color(0,0,0);
  const pm=new T.InstancedMesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial({map:SOMB.gtex(),transparent:true,blending:T.AdditiveBlending,depthWrite:false,fog:false}),NP);
  pm.frustumCulled=false;for(let i=0;i<NP;i++){pm.setMatrixAt(i,SOMB.z4);pm.setColorAt(i,SOMB.cl)}g.add(pm);sc.add(g);
  const pad=[];for(let i=0;i<NP;i++)pad.push({l:0,a:0,on:0,x:0,y:0,z:0,f:0,w0:1,h0:1,w1:1,h1:1,br:1});
  Object.assign(SOMB,{root:g,p,c,s,geo,pts,pm,pad,v:new Float32Array(N*3),l:new Float32Array(N),ml:new Float32Array(N),bs:new Float32Array(N),mx:new Float32Array(N)})},
 clear(){if(!SOMB.root)return;SOMB.root.visible=false;SOMB.l.fill(0);SOMB.s.fill(0);SOMB.c.fill(0);for(const d of SOMB.pad){d.l=0;d.on=0}for(let i=0;i<SOMB.NP;i++)SOMB.pm.setMatrixAt(i,SOMB.z4);SOMB.pm.instanceMatrix.needsUpdate=true;SOMB.geo.attributes.aS.needsUpdate=true},
 emit(x,y,z,vx,vy,vz,life,size,mx){const i=SOMB.ci=(SOMB.ci+1)%SOMB.N,p=SOMB.p,v=SOMB.v;p[i*3]=x;p[i*3+1]=y;p[i*3+2]=z;v[i*3]=vx;v[i*3+1]=vy;v[i*3+2]=vz;SOMB.l[i]=SOMB.ml[i]=life;SOMB.bs[i]=size;SOMB.mx[i]=mx||0},
 pad1(x,y,z,f,w0,h0,w1,h1,life,br){const d=SOMB.pad[SOMB.pi=(SOMB.pi+1)%SOMB.NP];Object.assign(d,{l:life,a:0,on:1,x,y,z,f,w0,h0,w1,h1,br,life})},
 burst(q){for(let i=0;i<30;i++){const a=Math.random()*6.283,sp=1+Math.random()*3.2;SOMB.emit(q.x+Math.cos(a)*.2,q.y+.15,q.z+Math.sin(a)*.2,Math.cos(a)*sp,1.5+Math.random()*3.5,Math.sin(a)*sp,.55+Math.random()*.5,.13+Math.random()*.14,Math.random()*.6)}
  for(let i=0;i<14;i++){const a=i/14*6.283;SOMB.emit(q.x,q.y+.08,q.z,Math.cos(a)*4.2,.25,Math.sin(a)*4.2,.4,.16,.8)}
  SOMB.pad1(q.x,q.y+.04,q.z,0,.6,.6,3.4,3.4,.55,1.2)},
 puff(q){for(let i=0;i<10;i++){const a=Math.random()*6.283,sp=1+Math.random()*1.6;SOMB.emit(q.x,q.y+.08,q.z,Math.cos(a)*sp,.6+Math.random()*1.2,Math.sin(a)*sp,.35+Math.random()*.3,.11+Math.random()*.08,.3)}SOMB.pad1(q.x,q.y+.04,q.z,0,.5,.5,2.2,2.2,.4,.8)},
 step(dt){if(!SOMB.root)return;const{p,c,s,v,l,ml,bs,mx,N,pad,pm,o,cl}=SOMB;
  for(let i=0;i<N;i++){if(l[i]<=0)continue;l[i]-=dt;if(l[i]<=0){s[i]=0;c[i*3]=c[i*3+1]=c[i*3+2]=0;continue}
   const k=1-dt*1.6;v[i*3]*=k;v[i*3+2]*=k;v[i*3+1]=v[i*3+1]*k-2.5*dt;p[i*3]+=v[i*3]*dt;p[i*3+1]=Math.max(.05,p[i*3+1]+v[i*3+1]*dt);p[i*3+2]+=v[i*3+2]*dt;
   const f=l[i]/ml[i],br=f*f*(3-2*f)*1.1,m=mx[i];c[i*3]=(.64+.3*m)*br;c[i*3+1]=(.24+.46*m)*br;c[i*3+2]=br;s[i]=bs[i]*(.45+.55*f)}
  let dirty=0;
  for(let i=0;i<SOMB.NP;i++){const d=pad[i];if(d.l>0){d.a+=dt;if(d.a>=d.l){d.l=0}}
   if(d.l>0){const k=d.a/d.l,b=Math.pow(1-k,1.6)*d.br,e=1-(1-k)*(1-k);o.position.set(d.x,d.y,d.z);o.rotation.set(-Math.PI/2,d.f,0);o.scale.set(d.w0+(d.w1-d.w0)*e,d.h0+(d.h1-d.h0)*e,1);o.updateMatrix();pm.setMatrixAt(i,o.matrix);cl.setRGB(.64*b,.24*b,b);pm.setColorAt(i,cl);d.on=1;dirty=1}
   else if(d.on){d.on=0;pm.setMatrixAt(i,SOMB.z4);dirty=1}}
  if(dirty){pm.instanceMatrix.needsUpdate=true;pm.instanceColor.needsUpdate=true}
  SOMB.geo.attributes.position.needsUpdate=SOMB.geo.attributes.aC.needsUpdate=SOMB.geo.attributes.aS.needsUpdate=true}};
function buildSombra(){const g=new T.Group(),u=g.userData,rt=new T.Group(),b=new T.Group();g.add(rt);rt.add(b);b.position.y=.675;u.rt=rt;u.body=b;SOMB.init();
 const J=0x0f0c18,JL=0x1c1730,PU=0x8a2bff,PL=0xc06bff,PW=0xf0d8ff,HR=0x0b0912,own=[],O=m=>(own.push(m),m);
 const glow=O(new T.MeshBasicMaterial({color:0xb24bff,fog:false})),glow2=O(new T.MeshBasicMaterial({color:0xe9c6ff,fog:false})),white=O(new T.MeshBasicMaterial({color:0xffffff,fog:false})),
  sole=O(new T.MeshLambertMaterial({color:0xf2f2f8,emissive:0x2a2a38})),edge=O(new T.LineBasicMaterial({color:0x8a2bff,fog:false})),edgeL=O(new T.LineBasicMaterial({color:0xc58bff,fog:false}));
 const tm=SOMB.mat,part=(p,geo,m,x,y,z,e)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;if(e){const id=geo.uuid;o.add(new T.LineSegments(SOMB.eg[id]||(SOMB.eg[id]=new T.EdgesGeometry(geo)),e))}p.add(o);return o},bx=(p,w,h,d,m,x,y,z,e)=>part(p,vbox(w,h,d),m,x,y,z,e);
 // ----- texturas (pixel art) -----
 const CRW=['#...#...#','##.###.##','#########','.#######.','#########'],crown=(i,j,x0,y0)=>{const cx=i-x0,cy=j-y0;return cx>=0&&cx<9&&cy>=0&&cy<5&&CRW[cy][cx]=='#'?(cy==4?PW:PL):0};
 const TF=tm('sbF',17,24,(i,j)=>{const q=crown(i,j,4,6);if(q)return[0x6a22b0,q];if((i==3||i==13)&&j>=3&&j<=19)return[PU,PU];if((i==3||i==13)&&(j==20||j==21))return[PL,PL];if(i==8)return[JL,null];if(j<2)return[0x07050c,null];return[J,null]},1.1),
  TB=tm('sbB',17,24,(i,j)=>{const q=crown(i,j,4,5);if(q)return[0x6a22b0,q];if((i==1||i==15)&&j>=3&&j<=21)return[PU,PU];if(i==8)return[JL,null];if(j<2)return[0x07050c,null];return[J,null]},1.1),
  TS=tm('sbS',9,24,(i,j)=>i==4&&j>=3&&j<=19?[PU,0x5a1ca0]:[J,null],.9),TT=tm('sbT',4,4,()=>[J,null],0),dkm=tm('sbDk',4,4,()=>[0x0c0914,null],0),
  hp=(i,j)=>vhash(i,j,3)>.86?0x34185e:HR,
  HF=tm('sbHF',8,8,(i,j)=>{if(j<2||(j==2&&i%3!=2)||((j==3||j==4)&&(i==0||i==7)))return[hp(i,j),null];if(j>=5)return[0x0a0810,null];if(j==4&&(i==1||i==2||i==5||i==6))return[0x2a1250,null];return[0xf0c8a0,null]},.8),
  HS=tm('sbHS',8,8,(i,j)=>{if(j>=5)return[0x0a0810,null];if(j<3||((i<=1||i>=6)&&j<5))return[hp(i,j),null];return[0xf0c8a0,null]},.8),
  HB=tm('sbHB',8,8,(i,j)=>j<6?[hp(i,j),null]:[0x0a0810,null],.8),HT=tm('sbHT',8,8,(i,j)=>[hp(i,j),vhash(i,j,12)>.9?0x4a1f90:null],1),HD=tm('sbHD',4,4,()=>[0x0a0810,null],0),
  hair=tm('sbHair',8,8,(i,j)=>[vhash(i,j,11)>.82?0x3a1a70:HR,vhash(i,j,12)>.9?0x5a2aa0:null],.8),
  TA=tm('sbA',4,12,(i,j)=>{if(j==3||j==10)return[PU,PU];if(j>=6&&j<=7&&(i==1||i==2))return[PU,PU];if(j==5)return[JL,null];return[J,null]},1),
  TG=tm('sbG',4,4,(i,j)=>j==1&&(i==1||i==2)?[PU,PU]:[0x090710,null],1),
  TL=tm('sbL',4,12,(i,j)=>{if(i==0&&j>=1&&j<=10)return[PU,PU];if(j==6)return[JL,null];if(i==2&&j>=8&&j<=9)return[JL,null];return[0x0b0910,null]},1),
  shoe=tm('sbShoe',4,4,(i,j)=>j==0?[0x1c1730,null]:[0x0a0810,null],0);
 // ----- tronco (jaqueta), cinto com corrente, gola e capuz -----
 bx(b,.47,.675,.245,[TS,TS,TT,TT,TF,TB],0,.3375,0,edge);
 bx(b,.49,.07,.26,dkm,0,.04,0,edge);bx(b,.1,.06,.02,glow2,0,.04,.136);bx(b,.05,.17,.02,glow,.16,-.06,.138);bx(b,.05,.11,.02,glow,-.17,-.03,.138);
 bx(b,.5,.09,.29,dkm,0,.7,0,edge);
 const hg=new T.Group();hg.position.set(0,.86,-.115);b.add(hg);bx(hg,.5,.36,.13,dkm,0,-.16,-.065,edge);bx(hg,.44,.03,.14,glow,0,-.34,-.065);u.hood=hg;
 // ----- cabeça: cabelo preto com brilho roxo, máscara e olhos que brilham -----
 const hd=bx(b,.45,.45,.45,[HS,HS,HT,HD,HF,HB],0,.9,0,edge);u.head=hd;
 bx(hd,.47,.1,.47,hair,0,.215,0,edgeL);bx(hd,.47,.4,.07,hair,0,.02,-.25);
 for(const[x,y,z,w,h,d]of[[-.15,.12,.235,.14,.12,.05],[.02,.15,.235,.12,.15,.05],[.17,.12,.235,.12,.1,.05]])bx(hd,w,h,d,hair,x,y,z);
 for(const[x,z,h,rz]of[[-.14,-.05,.14,.3],[0,.05,.18,-.1],[.13,-.08,.15,-.35],[-.05,-.15,.17,.2],[.1,.12,.11,.25]]){const o=bx(hd,.1,h,.1,hair,x,.27+h/2-.05,z,edgeL);o.rotation.z=rz}
 bx(hd,.47,.17,.47,dkm,0,-.14,0,edge);bx(hd,.475,.012,.475,glow,0,-.052,0);
 for(const s of[1,-1]){bx(hd,.1,.055,.012,glow2,s*.1,-.025,.2285);bx(hd,.045,.03,.014,white,s*.1,-.025,.2295);
  const sp=new T.Sprite(O(new T.SpriteMaterial({map:SOMB.gtex(),color:0xb24bff,blending:T.AdditiveBlending,transparent:true,depthWrite:false,fog:false,opacity:.85})));sp.scale.set(.26,.18,1);sp.position.set(s*.1,-.025,.26);hd.add(sp)}
 // ----- braços (mangas com faixas neon, luvas), pernas (listra roxa) e tênis preto/roxo com sola branca -----
 const arm=s=>{const p=new T.Group();p.position.set(s*.3375,.645,0);bx(p,.225,.5,.225,TA,0,-.25,0,edge);bx(p,.27,.08,.27,dkm,0,.015,0,edgeL);bx(p,.245,.175,.245,TG,0,-.5875,0,edge);b.add(p);return p};
 const leg=s=>{const p=new T.Group();p.position.set(s*.1125,.675,0);bx(p,.225,.563,.225,TL,0,-.2815,0,edge);bx(p,.245,.04,.245,glow,0,-.3,0);
  bx(p,.25,.09,.31,shoe,0,-.585,.03,edge);bx(p,.27,.045,.34,sole,0,-.6525,.035);bx(p,.2,.05,.06,glow,0,-.595,.19);bx(p,.1,.025,.1,glow2,0,-.538,.08);rt.add(p);return p};
 u.aL=arm(1);u.aR=arm(-1);u.lL=leg(1);u.lR=leg(-1);addGun(u.aR,u);
 // ----- coroa de energia flutuando sobre a cabeça -----
 const cr=new T.Group();cr.position.y=1.5;b.add(cr);const cm=O(new T.MeshBasicMaterial({color:0xc06bff,fog:false,transparent:true,opacity:.92})),cp=(w,h,d,x,y,z)=>bx(cr,w,h,d,cm,x,y,z,edgeL);
 cp(.34,.08,.34,0,0,0);for(const[x,z,h]of[[.14,.14,.17],[-.14,.14,.17],[.14,-.14,.17],[-.14,-.14,.17],[0,0,.25],[.14,0,.11],[-.14,0,.11],[0,.14,.11],[0,-.14,.11]])cp(.06,h,.06,x,.04+h/2,z);
 bx(cr,.06,.05,.02,white,0,0,.176);
 const halo=new T.Sprite(O(new T.SpriteMaterial({map:SOMB.gtex(),color:0x9b3cff,blending:T.AdditiveBlending,transparent:true,depthWrite:false,fog:false,opacity:.7})));halo.scale.set(.9,.9,1);halo.position.y=.1;cr.add(halo);
 // ----- aura (brilho + disco no chão) -----
 const spr=new T.Sprite(O(new T.SpriteMaterial({map:SOMB.gtex(),color:0x9b3cff,blending:T.AdditiveBlending,transparent:true,depthWrite:false,fog:false})));spr.position.y=1;g.add(spr);
 const gd=new T.Mesh(new T.PlaneGeometry(1,1),O(new T.MeshBasicMaterial({map:SOMB.gtex(),color:0x9b3cff,blending:T.AdditiveBlending,transparent:true,depthWrite:false,fog:false,side:T.DoubleSide})));gd.rotation.x=-Math.PI/2;gd.position.y=.04;g.add(gd);
 // ----- partículas do corpo: 20 orbitando, 24 saindo dos braços, 14 saindo das costas -----
 const N1=20,N2=24,NA=N1+N2+14,ap=new Float32Array(NA*3),ac=new Float32Array(NA*3),asz=new Float32Array(NA),ar=[];
 for(let i=0;i<NA;i++)ar.push({o:Math.random(),a:Math.random()*6.28,r:.4+Math.random()*.5,s:.12+Math.random()*.14,sp:.35+Math.random()*.4,x:Math.random()});
 const apg=new T.BufferGeometry();apg.setAttribute('position',new T.BufferAttribute(ap,3));apg.setAttribute('aC',new T.BufferAttribute(ac,3));apg.setAttribute('aS',new T.BufferAttribute(asz,1));
 const apm=SOMB.pmat(),apt=new T.Points(apg,apm);apt.frustumCulled=false;g.add(apt);
 u.lt=0;u.idle=0;u.wa=0;u.tf=0;u.ts=0;
 u.fx=(t,sp,air)=>{const dt=Math.min(.1,Math.abs(t-u.lt));u.lt=t;
  const gm=mode=='game',vis=gm&&cam.fov<50?.12:1,lq=+S.q<1,gnd=!air;
  // parado: a aura cresce e pulsa devagar; em movimento volta ao normal
  if(sp<.1&&gnd)u.idle=Math.min(3,u.idle+dt);else u.idle=Math.max(0,u.idle-dt*3);
  const k=u.idle/3,pu=.5+.5*Math.sin(t*1.5),gi=.85+.25*pu*(.4+k*.6);
  SOMB.U.k.value=R.domElement.height/(2*Math.tan(cam.fov*Math.PI/360));
  glow.color.setRGB(.7*gi,.3*gi,Math.min(1,gi));edge.color.setRGB(.55*gi,.2*gi,Math.min(1,gi));
  for(const q in SOMB.tx){const m=SOMB.tx[q];m.emissiveIntensity=m.userData.ei*(.85+.3*pu*k+.1*pu)}
  // aura discreta durante o jogo (não cobre a visão); mais forte no lobby/vitrine
  const ao=(gm?.2:.55)*vis,s1=1.8+.5*k*pu+(gm?0:.2);
  spr.scale.set(s1,s1*1.25,1);spr.material.opacity=ao*(.7+.3*k*pu+.15*k);gd.scale.setScalar(1.6+1.2*k*pu);gd.material.opacity=(gm?.4:.6)*vis*(.7+.3*k*pu);
  cr.visible=vis>.5;cr.position.y=1.5+Math.sin(t*2)*.04;cr.rotation.y=t*1.1;halo.material.opacity=.55+.25*pu;
  u.hood.rotation.x=.05+Math.min(sp,7)*.04+(air?.3:0)+Math.sin(t*2.2)*.03;
  // partículas do corpo (acompanham o braço que balança)
  const I=vis*(gm?.85:1);let n=0;
  for(let i=0;i<NA;i++){const q=ar[i],ph=(q.o+t*q.sp)%1;let x,y,z,br,sz,m=ph*.5;
   if(i<N1){const a=q.a+t*.8*(i%2?1:-1),Rr=q.r*(1+k*.5);x=Math.cos(a)*Rr;z=Math.sin(a)*Rr;y=.1+ph*2.1;br=Math.sin(ph*Math.PI);sz=q.s*.8}
   else if(i<N1+N2){const sd=i<N1+N2/2?1:-1,th=(sd>0?u.aL:u.aR).rotation.x,L=q.x*.62;x=sd*(.34+.08+ph*.14)+Math.sin(t*5+i)*.02;y=1.32-L*Math.cos(th)+ph*.7;z=-L*Math.sin(th)+Math.sin(t*4+i*2)*.03;br=Math.pow(1-ph,1.2)*(.75+.25*Math.sin(t*14+i));sz=q.s*(1.2-ph*.8)}
   else{x=(q.x-.5)*.5;y=.85+(q.r-.4)*1.4+ph*.45;z=-.22-ph*.45;br=Math.pow(1-ph,1.2);sz=q.s*(1.1-ph*.7)}
   ap[i*3]=x;ap[i*3+1]=y;ap[i*3+2]=z;br*=I;ac[i*3]=(.64+.3*m)*br;ac[i*3+1]=(.24+.46*m)*br;ac[i*3+2]=br;asz[i]=sz}
  apg.attributes.position.needsUpdate=apg.attributes.aC.needsUpdate=apg.attributes.aS.needsUpdate=true;
  // pulo: explosão de partículas roxas; pouso: pequena nuvem
  const aj=!!air&&gm&&(!G.ph||G.ph=='ground');if(aj&&!u.wa)SOMB.burst(g.position);else if(!aj&&u.wa)SOMB.puff(g.position);u.wa=aj;
  // correndo: rastro roxo no chão (pegadas de luz + faísca)
  if(gm&&gnd&&sp>5&&g.visible){u.tf-=dt;if(u.tf<=0){u.tf=lq?.09:.055;const f=g.rotation.y,sd=(u.ts^=1)?1:-1,fx=Math.sin(f),fz=Math.cos(f),X=g.position.x,Y=g.position.y,Z=g.position.z;
    SOMB.pad1(X-fx*.25+fz*sd*.13,Y+.04,Z-fz*.25-fx*sd*.13,f,.5,1.2,.9,1.7,.9,.9);
    if(u.ts&&!lq)SOMB.pad1(X-fx*.9,Y+.035,Z-fz*.9,f,.35,2.4,.3,3.2,.5,.7);
    SOMB.emit(X-fx*.3,Y+.1,Z-fz*.3,(Math.random()-.5)*.6,.5+Math.random()*.9,(Math.random()-.5)*.6,.5+Math.random()*.5,.1+Math.random()*.1,Math.random()*.5)}}
  SOMB.step(dt)};
 u.dispose=()=>{own.forEach(m=>m.dispose());apg.dispose();apm.dispose();SOMB.clear()};
 return g}
const sbThumb=()=>{const L='#8a2bff',P='#c06bff',D='#0b0910',J='#100c1a',st=`stroke='${L}' stroke-width=.8`;
 return `<defs><radialGradient id=sbg><stop offset=0 stop-color='#c06bff' stop-opacity=.9 /><stop offset=1 stop-color='#6a22e8' stop-opacity=0 /></radialGradient></defs><circle cx=50 cy=84 r=50 fill='url(#sbg)' />`
 +`<rect x=33 y=90 width=15 height=34 fill='${D}' ${st} /><rect x=52 y=90 width=15 height=34 fill='${D}' ${st} /><rect x=33.5 y=92 width=2.2 height=30 fill='${P}' /><rect x=64.3 y=92 width=2.2 height=30 fill='${P}' />`
 +`<rect x=31 y=122 width=18 height=6 fill='${D}' ${st} /><rect x=51 y=122 width=18 height=6 fill='${D}' ${st} /><rect x=30 y=127 width=20 height=3.5 fill='#fff' /><rect x=50 y=127 width=20 height=3.5 fill='#fff' /><rect x=30 y=123 width=5 height=3 fill='${P}' /><rect x=65 y=123 width=5 height=3 fill='${P}' />`
 +`<rect x=17 y=56 width=13 height=30 fill='${J}' ${st} /><rect x=70 y=56 width=13 height=30 fill='${J}' ${st} /><rect x=17 y=86 width=13 height=9 fill='${D}' ${st} /><rect x=70 y=86 width=13 height=9 fill='${D}' ${st} /><rect x=19 y=64 width=9 height=2.5 fill='${P}' /><rect x=72 y=64 width=9 height=2.5 fill='${P}' />`
 +`<rect x=30 y=54 width=40 height=40 fill='${J}' stroke='${L}' stroke-width=1 /><rect x=36 y=57 width=2.2 height=30 fill='${L}' /><rect x=61.8 y=57 width=2.2 height=30 fill='${L}' />`
 +`<polygon points='40,76 41,66 45,71 50,63 55,71 59,66 60,76' fill='${P}' stroke='#f0d8ff' stroke-width=.8 /><rect x=40 y=76 width=20 height=3 fill='#f0d8ff' /><rect x=30 y=90 width=40 height=4 fill='${D}' ${st} /><rect x=47 y=90 width=6 height=4 fill='${P}' />`
 +`<rect x=36 y=26 width=28 height=28 fill='#f0c8a0' /><rect x=35 y=21 width=30 height=11 fill='${D}' ${st} /><rect x=35 y=30 width=5 height=6 fill='${D}' /><rect x=60 y=30 width=5 height=6 fill='${D}' /><rect x=36 y=43 width=28 height=11 fill='${D}' ${st} /><rect x=40 y=35 width=7 height=3.5 fill='#e3b8ff' /><rect x=53 y=35 width=7 height=3.5 fill='#e3b8ff' />`
 +`<polygon points='38,14 39,6 44,10 50,3 56,10 61,6 62,14' fill='${P}' stroke='#f0d8ff' stroke-width=.8 />`
 +[[12,40],[88,52],[20,100],[82,96],[8,70],[92,80]].map(([x,y],i)=>`<rect x=${x} y=${y} width=${2+i%2*1.5} height=${2+i%2*1.5} fill='#d9a3ff' opacity=.85 />`).join('')};
const sombraItem=()=>`<div class='it sbr${S.set=='sombra'?' on':''}' data-s=sombra><svg class=pv viewBox='0 0 100 150' preserveAspectRatio='xMidYMax meet'>${sbThumb()}</svg><b class=sn>${SOMBRA.n}</b><em class=rar>${SOMBRA.rar.toUpperCase()}</em></div>`;
// animações: idle, andar, correr, pular, agachar, deitar, mirar/atirar, recarregar, morrer, emotes (tudo por rotação de blocos)
function anim(g,t,sp,air){const u=g.userData,rt=u.rt,b=u.body,dead=u.e?!u.e.a:!!u.pdead;
 const run=sp>5,mv=sp>.1,f=Math.sin(t*(run?14:9)),a=run?1:.6,ar=!!u.armed&&!dead&&!air,fi=ar&&t<u.sh,rl=ar&&!!u.rl,pr=!air&&!dead&&!!u.pr,cr=!air&&!dead&&!pr&&!!u.cr;
 let lL=0,lR=0,aL=0,aR=0,bx=0,by=0,ry=0,hd=0,rx=0,py=0;
 if(air){lL=-.7;lR=.3;aL=aR=-2.4}
 else if(mv){lL=f*a;lR=-f*a;aL=-f*a;aR=f*a;bx=run?.2:.05;by=Math.abs(f)*.04}
 else{const s=Math.sin(t*2);aL=s*.05;aR=-s*.05;by=s*.012;
  if(u.emote==1&&!ar){const d=Math.sin(t*6);aL=-2.6+d*.5;aR=-2.6-d*.5;lL=d*.35;lR=-d*.35;by=Math.abs(d)*.07;ry=d*.45;hd=-d*.3}
  else if(u.emote==2&&!ar)aR=-2.7+Math.sin(t*8)*.35}
 if(ar){aL=-1.35;aR=-1.5;if(fi){const k=(u.sh-t)/.18;aR+=.18*k;aL+=.12*k;bx-=.06*k}if(rl){aL=-.9+Math.sin(t*10)*.12;aR=-.7}}
 if(cr){py=-.08;bx=Math.max(bx,.4);lL=-.45+(mv?f*.3:0);lR=-.45-(mv?f*.3:0)}
 if(pr){rx=1.5708;py=.23;bx=0;by=0;lL=mv?f*.3:0;lR=-lL;aL=-3+(mv?f*.25:0);aR=-3-(mv?f*.25:0)}
 if(dead){if(!u.d0)u.d0=t||.001;const k=Math.min(1,(t-u.d0)/.45);rx=-1.5708*k;py=.115*k;lL=lR=0;aL=-.5*k;aR=-.35*k;bx=by=ry=hd=0}else u.d0=0;
 rt.rotation.x=rx;rt.position.y=py;u.lL.rotation.x=lL;u.lR.rotation.x=lR;u.aL.rotation.x=aL;u.aR.rotation.x=aR;b.rotation.x=bx;b.position.y=.675+by;b.rotation.y=ry;u.head.rotation.y=hd;
 if(u.gun){u.gun.visible=ar;u.gun.rotation.y=rl?1.1:0;u.mag.visible=!rl}
 if(u.fx)u.fx(t,sp,air)}
// ---------- cena ----------
const R=new T.WebGLRenderer({canvas:$('#c'),antialias:false});R.shadowMap.enabled=true;R.shadowMap.type=T.PCFSoftShadowMap;
const sc=new T.Scene(),cam=new T.PerspectiveCamera(60,1,.1,300);
const sun=new T.DirectionalLight(0xffffff,.85),hemi=new T.HemisphereLight(0xcfe8ff,0x4a5a3a,.85);sc.add(hemi,sun,sun.target);
Object.assign(sun.shadow.camera,{left:-25,right:25,top:25,bottom:-25,near:1,far:90});sun.shadow.camera.updateProjectionMatrix();
const FLT=['','brightness(1.18) contrast(1.05)','saturate(1.6) contrast(1.08)','hue-rotate(20deg) saturate(1.2) brightness(1.05)'],FN=['Clássico','Brilho','Vívido','Água'];
function applyF(){$('#c').style.filter=(+S.q<1?'blur(1.4px) ':'')+(FLT[S.flt]||'')}
function applyQ(){const q=+S.q,s=q>1?40:25;R.setPixelRatio(Math.min(S.hr?2.5:devicePixelRatio,[.5,1.25,2][q]*(S.hr?1.5:1)));sun.castShadow=!!S.sh;sun.shadow.mapSize.set(q>1?4096:1024,q>1?4096:1024);Object.assign(sun.shadow.camera,{left:-s,right:s,top:s,bottom:-s});sun.shadow.camera.updateProjectionMatrix();sun.shadow.bias=-.0004;sun.shadow.normalBias=.03;if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null}
 R.toneMapping=q>1?T.ACESFilmicToneMapping:T.NoToneMapping;R.toneMappingExposure=1.3;rim.visible=UL.visible=q>1;skyDome.visible=q>1&&mode=='game';applyF();size()}
function size(){R.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}
addEventListener('resize',size);
// lobby
const LB=new T.Group();sc.add(LB);
const plat=new T.Mesh(new T.CylinderGeometry(1.7,1.9,.15,36),M(0x1b2d5c));plat.position.y=.075;plat.receiveShadow=true;LB.add(plat);
const ring=new T.Mesh(new T.TorusGeometry(1.75,.04,8,48),new T.MeshBasicMaterial({color:0xffc233}));ring.rotation.x=Math.PI/2;ring.position.y=.16;LB.add(ring);
// mundo (campo de treino)
const W=new T.Group();sc.add(W);const solids=[],trees=[];let sd=7;const rnd=()=>(sd=(sd*16807)%2147483647)/2147483647;
const gr=new T.Mesh(new T.PlaneGeometry(300,300),M(0x5fae4d));gr.rotation.x=-Math.PI/2;gr.receiveShadow=true;W.add(gr);
const rd=new T.Mesh(new T.PlaneGeometry(8,300),M(0x5b5f66));rd.rotation.x=-Math.PI/2;rd.position.set(-14,.02,0);rd.receiveShadow=true;W.add(rd);
function house(x,z,w,d,c){const b=mk(w,3,d,c);b.position.set(x,1.5,z);b.receiveShadow=true;const r=new T.Mesh(new T.ConeGeometry(Math.max(w,d)*.75,1.8,4),M(0x8b3a2a));r.position.set(x,3.9,z);r.rotation.y=Math.PI/4;r.castShadow=true;
 const dr=mk(1.1,2,.1,0x3b2a1a);dr.position.set(x,1,z+d/2+.02);W.add(b,r,dr);solids.push({x,z,hw:w/2,hd:d/2,h:3})}
function crate(x,z,s){const b=mk(s,s,s,0xb08040);b.position.set(x,s/2,z);W.add(b);solids.push({x,z,hw:s/2,hd:s/2,h:s})}
[[12,-8,7,6,0xe9d8a6],[26,6,6,8,0xcfe1f2],[-4,-30,8,6,0xf2b5a0],[20,-28,6,6,0xd8e2a8],[-30,-10,7,7,0xe9d8a6],[34,-14,8,5,0xb5c4e8],[-26,20,6,6,0xf2b5a0],[8,30,7,6,0xcfe1f2]].forEach(a=>house(...a));
[[4,10,1],[5.2,10,1],[4.6,10,1.6],[-8,4,1.6],[-8,5.8,1],[16,18,1.6],[-18,-24,1]].forEach(a=>crate(...a));
const tw=mk(3,8,3,0x7a7f88);tw.position.set(-40,4,-32);W.add(tw);solids.push({x:-40,z:-32,hw:1.5,hd:1.5,h:8});
const N=90,tr=new T.InstancedMesh(new T.CylinderGeometry(.2,.28,1.6,6),M(0x6b4a2b),N),fo=new T.InstancedMesh(new T.ConeGeometry(1.3,3.2,7),M(0x2e7d32),N),mt=new T.Matrix4();
tr.castShadow=fo.castShadow=true;
for(let i=0,n=0;n<N&&i<999;i++){const x=(rnd()-.5)*140,z=(rnd()-.5)*140,s=.8+rnd()*.7;
 if(Math.hypot(x,z-12)<8||Math.abs(x+14)<6||solids.some(o=>Math.abs(x-o.x)<o.hw+3&&Math.abs(z-o.z)<o.hd+3))continue;
 mt.makeScale(s,s,s).setPosition(x,.8*s,z);tr.setMatrixAt(n,mt);mt.makeScale(s,s,s).setPosition(x,(1.6+1.6)*s,z);fo.setMatrixAt(n,mt);trees.push({x,z,r:.3*s+.1});n++}
W.add(tr,fo);
// ---------- ultra: grama, flores, pedras, nuvens e céu ----------
const UL=new T.Group();W.add(UL);const cc=new T.Color(),rim=new T.DirectionalLight(0x9fc8ff,.4);rim.position.set(-20,15,-25);sc.add(rim);
const free=(x,z,m)=>!(Math.abs(x+14)<5||solids.some(o=>Math.abs(x-o.x)<o.hw+m&&Math.abs(z-o.z)<o.hd+m));
const gm=new T.InstancedMesh(new T.ConeGeometry(.07,.55,3),new T.MeshLambertMaterial({color:0xffffff}),2600),fl=new T.InstancedMesh(new T.SphereGeometry(.09,5,4),new T.MeshBasicMaterial({color:0xffffff}),450);
for(let i=0,n=0;n<2600&&i<9e3;i++){const x=(rnd()-.5)*136,z=(rnd()-.5)*136;if(!free(x,z,1))continue;const s=.7+rnd()*.9;mt.makeScale(s,s*(.8+rnd()*.8),s).setPosition(x,.25*s,z);gm.setMatrixAt(n,mt);gm.setColorAt(n,cc.setHSL(.25+rnd()*.07,.55,.28+rnd()*.14));n++}
for(let i=0,n=0;n<450&&i<9e3;i++){const x=(rnd()-.5)*136,z=(rnd()-.5)*136;if(!free(x,z,1))continue;mt.makeTranslation(x,.14,z);fl.setMatrixAt(n,mt);fl.setColorAt(n,cc.set([0xffffff,0xffd23f,0xff7aa8,0xff4d5e,0xb388ff][n%5]));n++}
UL.add(gm,fl);
for(let i=0;i<26;i++){const x=(rnd()-.5)*130,z=(rnd()-.5)*130;if(!free(x,z,2))continue;const s=.5+rnd()*.9,r=new T.Mesh(new T.DodecahedronGeometry(.5,0),M(0x7d8590));r.scale.set(s*1.4,s,s*1.2);r.position.set(x,.3*s,z);r.rotation.y=rnd()*6;r.castShadow=true;UL.add(r)}
const CL=new T.Group(),cmat=new T.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.92,fog:false});
for(let i=0;i<16;i++){const g=new T.Group(),a=rnd()*6.28,r=60+rnd()*60;for(let j=0;j<4;j++){const m=new T.Mesh(new T.SphereGeometry(5+rnd()*5,8,6),cmat);m.scale.y=.45;m.position.set(j*6-9+rnd()*3,rnd()*2,rnd()*4);g.add(m)}g.position.set(Math.cos(a)*r,42+rnd()*18,Math.sin(a)*r);CL.add(g)}UL.add(CL);
const skyMat=new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,uniforms:{a:{value:new T.Color()},b:{value:new T.Color()}},vertexShader:'varying float h;void main(){h=normalize(position).y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'uniform vec3 a,b;varying float h;void main(){gl_FragColor=vec4(mix(b,a,pow(clamp(h,0.,1.),.55)),1.);}'}),skyDome=new T.Mesh(new T.SphereGeometry(200,24,12),skyMat),sunM=new T.Mesh(new T.SphereGeometry(9,12,8),new T.MeshBasicMaterial({color:0xfff2b0,fog:false}));
sunM.position.set(87,152,51);skyDome.add(sunM);skyDome.renderOrder=-1;skyDome.visible=false;sc.add(skyDome);
function ultraSky(k,m){const c=[[0x2b7fd8,0xbfe3ff],[0x3a3f8f,0xffb26b],[0x02040f,0x1a2550]][k];skyMat.uniforms.a.value.set(c[0]);skyMat.uniforms.b.value.set(c[1]);sunM.material.color.set(k==2?0xdde6ff:0xfff2b0);cmat.color.set([0xffffff,0xffd2b0,0x44557a][k]);skyDome.visible=+S.q>1&&m=='game';if(+S.q>1&&m=='game'){sc.fog=new T.Fog(c[1],50,170);sc.background=new T.Color(c[1])}}
// ---------- jogador ----------
let me,mode='lobby',t=0;const P={x:0,y:0,py:0,z:12,vy:0,gr:true,cr:false,yaw:0,pitch:.35,face:0},inp={jx:0,jy:0,jump:false},keys={};
function setChar(){if((S.set=='sombra'&&!(S.inv||[]).includes('Sombra Real'))||(S.set=='rei'&&!(S.inv||[]).includes('Rei Dourado'))){S.set='';save()}if(me){sc.remove(me);me.userData.dispose&&me.userData.dispose()}SOMB.clear();me=buildChar(S.set=='rei'?KING:S.set=='sombra'?SOMBRA:(CH[S.ch]||CH[0]));sc.add(me);if(mode=='lobby'){me.position.set(0,.15,0);me.rotation.y=.5}}
function setMode(m){if(m=='lobby')G.stop();mode=m;W.visible=m=='game';LB.visible=m=='lobby';$('#lobby').hidden=m!='lobby';$('#hud').hidden=m!='game';
 const k=m=='game'&&S.mode?S.sky:0,sky=m=='game'?[0x87ceeb,0xf4a261,0x0a1230][k]:0x0f1f45;hemi.intensity=[.85,.7,.3][k];sun.intensity=[.85,.6,.15][k];sc.background=new T.Color(sky);sc.fog=m=='game'?new T.Fog(sky,45,150):null;ultraSky(k,m);
 if(m=='lobby'){me.position.set(0,.15,0);me.rotation.y=.5;me.scale.y=1;Object.assign(me.userData,{armed:0,cr:0,pr:0,pdead:0,rl:0});cam.position.set(0,1.4,4.2);cam.lookAt(0,1.05,0);sun.position.set(3,8,5);sun.target.position.set(0,0,0)}
 else{P.x=0;P.z=12;P.y=0;P.vy=0;P.yaw=0;P.pitch=.35;P.cr=P.pr=P.run=false;document.querySelectorAll('#hud .act.on').forEach(b=>b.classList.remove('on'));cam.fov=60;cam.updateProjectionMatrix();AM.n=AM.max;AM.rl=0}}
function collide(p){const I=window.ISL&&ISL.on,stp=I?.6:.15;let gy=I?ISL.base(p.x,p.z):0;
 const tc=s=>{if(s.o)return;const y0=s.y0||0;if(I&&p.y+1.75<=y0)return;const dx=p.x-s.x,dz=p.z-s.z,ox=s.hw+.35-Math.abs(dx),oz=s.hd+.35-Math.abs(dz);
  if(ox>0&&oz>0){if(p.y>=s.h-stp||p.py>=s.h-.02)gy=Math.max(gy,s.h);else if(ox<oz)p.x+=Math.sign(dx||1)*ox;else p.z+=Math.sign(dz||1)*oz}};
 if(I)ISL.near(p.x,p.z,tc);
 for(const s of solids)tc(s);
 for(const k of trees){const dx=p.x-k.x,dz=p.z-k.z,d=Math.hypot(dx,dz),m=k.r+.35;if(d<m&&d>0){p.x+=dx/d*(m-d);p.z+=dz/d*(m-d)}}
 if(I)for(let n=0;n<80&&!ISL.land(p.x,p.z);n++){const r=Math.hypot(p.x,p.z)||1;p.x-=p.x/r*.5;p.z-=p.z/r*.5}
 return gy}
function update(dt){if(G.dead){inp.jx=inp.jy=0;inp.jump=false;for(const k in keys)keys[k]=false}
 if(G.ph&&G.ph!='ground'){G.air(dt);return}
 const jx=inp.jx+(keys.d||keys.ArrowRight?1:0)-(keys.a||keys.ArrowLeft?1:0);let jy=inp.jy+(keys.w||keys.ArrowUp?1:0)-(keys.s||keys.ArrowDown?1:0);const rn=P.run&&!P.pr&&!P.cr&&!G.dead;if(rn&&Math.hypot(jx,jy)<=.05)jy=1;const l=Math.hypot(jx,jy),mag=rn?1:Math.min(1,l);
 const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),rx=Math.cos(P.yaw),rz=-Math.sin(P.yaw);
 let sp=0;
 if(l>.05){const dx=rx*jx+fx*jy,dz=rz*jx+fz*jy,dl=Math.hypot(dx,dz);sp=(P.pr?1.2:P.cr?2.2:(mag>.8||keys.Shift||P.run)?7:3.6)*mag*(S.mode?S.spd:1);P.x+=dx/dl*sp*dt;P.z+=dz/dl*sp*dt;
  let a=Math.atan2(dx,dz)-P.face;a=Math.atan2(Math.sin(a),Math.cos(a));P.face+=a*Math.min(1,dt*12)}
 P.py=P.y;if(inp.jump&&P.gr){P.vy=8;P.gr=false;beep(520,.09)}inp.jump=false;
 P.vy-=22*(S.mode?S.grav:1)*dt;P.y+=P.vy*dt;P.x=Math.max(-G.lim,Math.min(G.lim,P.x));P.z=Math.max(-G.lim,Math.min(G.lim,P.z));
 const gy=collide(P);if(P.y<=gy){P.y=gy;P.vy=0;P.gr=true}else P.gr=false;
 me.position.set(P.x,P.y,P.z);me.rotation.y=P.face;me.scale.y=1;{const U=me.userData;U.cr=P.cr;U.pr=P.pr;U.armed=WLD.armed();U.rl=AM.rl>0;U.pdead=G.dead}
 anim(me,t,sp,!P.gr);
 const ty=P.y+(P.pr?.7:P.cr?1.1:1.5),d=4.2,cp=Math.cos(P.pitch);
 cam.position.set(P.x+Math.sin(P.yaw)*cp*d,Math.max(window.ISL&&ISL.on?P.y+.3:.3,ty+Math.sin(P.pitch)*d),P.z+Math.cos(P.yaw)*cp*d);cam.lookAt(P.x,ty+.2,P.z);
 if(window.ISL&&ISL.on){const kk=ISL.cam(P.x,ty+.2,P.z,cam.position.x,cam.position.y,cam.position.z);if(kk<1){cam.position.set(P.x+(cam.position.x-P.x)*kk,ty+.2+(cam.position.y-ty-.2)*kk,P.z+(cam.position.z-P.z)*kk);cam.lookAt(P.x,ty+.2,P.z)}}
 {const ad=cam.fov<50&&!G.dead,fp=ad&&!!window.__scoped;if(ad){const sy=Math.sin(P.yaw),cy=Math.cos(P.yaw),cq=Math.cos(P.pitch),eyY=P.y+(P.pr?.5:P.cr?1.05:1.62);
  if(fp)cam.position.set(P.x-sy*.35,eyY,P.z-cy*.35);else cam.position.set(P.x+cy*.55+sy*1.3,eyY+.1,P.z-sy*.55+cy*1.3);
  cam.lookAt(cam.position.x-sy*cq*20,cam.position.y-Math.sin(P.pitch)*20,cam.position.z-cy*cq*20)}
  if(fp&&!window.__fpv){me.visible=false;window.__fpv=1}else if(!fp&&window.__fpv){me.visible=true;window.__fpv=0}}
 skyDome.position.copy(cam.position);CL.rotation.y+=dt*.01;sun.position.set(P.x+20,P.y+35,P.z+12);sun.target.position.set(P.x,P.y,P.z)}
const mm=$('#mm').getContext('2d');
function minimap(){const k=.8;mm.clearRect(0,0,100,100);mm.save();mm.translate(50,50);mm.rotate(P.yaw);mm.translate(-P.x*k,-P.z*k);
 if(window.ISL&&ISL.on&&ISL.mc){mm.imageSmoothingEnabled=false;mm.drawImage(ISL.mc,-140*k,-140*k,280*k,280*k)}else{if(!G.city){mm.fillStyle='#5b5f66';mm.fillRect(-18*k,-80,8*k,160)}mm.fillStyle='#e9d8a6';solids.forEach(s=>mm.fillRect((s.x-s.hw)*k,(s.z-s.hd)*k,s.hw*2*k,s.hd*2*k));mm.fillStyle='#2e7d32';trees.forEach(o=>mm.fillRect(o.x*k-1,o.z*k-1,2,2))}mm.restore();
 mm.fillStyle='#ffc233';mm.beginPath();mm.moveTo(50,43);mm.lineTo(55,55);mm.lineTo(45,55);mm.fill()}
// ---------- entrada ----------
function drag(el,on,end){let id=null,lx,ly;el.addEventListener('pointerdown',e=>{id=e.pointerId;lx=e.clientX;ly=e.clientY;el.setPointerCapture(id);on(e,0,0,'s')});
 el.addEventListener('pointermove',e=>{if(e.pointerId!==id)return;on(e,e.clientX-lx,e.clientY-ly,'m');lx=e.clientX;ly=e.clientY});
 const up=e=>{if(e.pointerId===id){id=null;end&&end()}};el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up)}
let jo=[0,0];drag($('#zl'),(e,dx,dy,k)=>{const jb=$('#jb');if(k=='s'){jo=[e.clientX,e.clientY];jb.style.cssText=`display:block;left:${jo[0]-55}px;top:${jo[1]-55}px`}
 let x=e.clientX-jo[0],y=e.clientY-jo[1];const l=Math.hypot(x,y),m=Math.min(l,45);if(l>0){x*=m/l;y*=m/l}$('#jk').style.transform=`translate(${x}px,${y}px)`;inp.jx=x/45;inp.jy=-y/45},()=>{$('#jb').style.display='none';inp.jx=inp.jy=0});
drag($('#zr'),(e,dx,dy)=>{P.yaw-=dx*.005*S.sens/5;P.pitch=Math.max(-.4,Math.min(1.1,P.pitch+dy*.004*S.sens/5))});
drag($('#rz'),(e,dx)=>{me.rotation.y+=dx*.012});
const toggleCr=()=>{P.cr=!P.cr;if(P.cr){P.pr=false;$('#bp').classList.remove('on')}$('#bc').classList.toggle('on',P.cr);beep(300,.05)};
$('#bj').addEventListener('pointerdown',()=>inp.jump=true);$('#bc').addEventListener('pointerdown',toggleCr);$('#back').onclick=()=>{beep(300);setMode('lobby')};
addEventListener('keydown',e=>{keys[e.key.length==1?e.key.toLowerCase():e.key]=true;if(mode=='game'){if(e.code=='Space')inp.jump=true;if(e.key=='c'||e.key=='C')toggleCr()}});
addEventListener('keyup',e=>{keys[e.key.length==1?e.key.toLowerCase():e.key]=false});
// ---------- menus ----------
const refresh=()=>{$('#pn').textContent=S.name;$('#pid').textContent='ID '+S.id+' · Nível 1';$('#mn').textContent=GM[S.gm].n;$('#co').textContent=S.coins;$('#di').textContent=S.dia;$('#pet').textContent=''};
function modal(title,html,after){$('#mt').textContent=title;$('#mb').innerHTML=html;$('#modal').hidden=false;beep(660,.05);after&&after()}
$('#mx').onclick=()=>{if(G.over){G.over=0;setMode('lobby')}$('#modal').hidden=true;beep(330,.05);refresh()};
const hex=c=>'#'+c.toString(16).padStart(6,'0');
const MENU={
 mode(){const c=$('#gm'),card=k=>{const g=GM[k],p=g.r?S.rp[k]:0,[a,b]=g.c.split(',');return `<button class='mc${S.gm==k?' on':''}${g.r?' big':''}' data-k=${k} style='background:${a}'>${ART[k]()}${g.r?`<span class=mr>${rk(p)}<u><s style='width:${p>=1800?100:p%100}%'></s></u></span>`:''}<span class=mn>${g.n}</span><small>${g.d}</small></button>`};
  c.innerHTML=`<div class=cmt><h1>MODO DE JOGO</h1></div><div class=mcs>${Object.keys(GM).map(card).join('')}</div><button class=bv id=bv3>‹ VOLTAR</button>`;c.hidden=false;beep(660,.05);
  c.querySelectorAll('.mc').forEach(b=>b.onclick=()=>{S.gm=b.dataset.k;S.mode=S.gm=='pe'?1:0;save();refresh();c.hidden=true;beep(660,.06);if(S.gm=='pe')MENU.cust()});
  $('#bv3').onclick=()=>{c.hidden=true;beep(330,.05)}},
 char(){const c=$('#cm');c.innerHTML=`<div class=cmt><div class=prof><b id=cmn></b><small>ID ${S.id}</small></div><div class=cur><span>🪙 <b>${S.coins}</b></span><span>💎 <b>${S.dia}</b></span></div><h1>PERSONAGEM</h1></div><div class=cg>${'<div class=sl></div>'.repeat(10)}</div><button class=bv id=bv2>‹ VOLTAR</button><p class=cmh>Selecione seu personagem</p>`;$('#cmn').textContent=S.name;c.hidden=false;beep(660,.05);$('#bv2').onclick=()=>{c.hidden=true;beep(330,.05)}},
 cust(){const o=(a,b)=>`<option value='${a}'>${b}</option>`;modal('Modo de jogo',`<div class='grid' style='grid-template-columns:1fr 1fr'><button class='cc' id='m0'>Treinamento</button><button class='cc' id='m1'>Personalizado</button></div><p id='mdsc'></p><div id='mcf'></div>`,()=>{const draw=()=>{$('#m0').classList.toggle('on',!S.mode);$('#m1').classList.toggle('on',!!S.mode);$('#mn').textContent=GM[S.gm].n;$('#mdsc').textContent=S.mode?'Monte sua sala: escolha o horário do dia, a gravidade e a velocidade.':'Mapa livre para correr, pular e explorar sem pressão.';$('#mcf').innerHTML=S.mode?`<label>Horário<select id='c1'>${o(0,'Dia')}${o(1,'Pôr do sol')}${o(2,'Noite')}</select></label><label>Gravidade<select id='c2'>${o(1,'Normal')}${o(.5,'Baixa')}${o(.25,'Lunar')}</select></label><label>Velocidade<select id='c3'>${o(1,'Normal')}${o(1.5,'Rápida')}${o(.7,'Lenta')}</select></label>`:'';if(S.mode){$('#c1').value=S.sky;$('#c2').value=S.grav;$('#c3').value=S.spd;$('#c1').onchange=e=>{S.sky=+e.target.value;save()};$('#c2').onchange=e=>{S.grav=+e.target.value;save()};$('#c3').onchange=e=>{S.spd=+e.target.value;save()}}};$('#m0').onclick=()=>{S.mode=0;S.gm='tr';save();draw();beep(500,.06)};$('#m1').onclick=()=>{S.mode=1;S.gm='pe';save();draw();beep(500,.06)};draw()})},
 cofre(){const c=$('#cf'),L=$('#lobby'),hx=[0,1,0,1,0,1].map((v,i)=>`<i class=hx style='left:${v?'calc(var(--s)*.95)':0};top:calc(var(--s)*.72*${i})'></i>`).join('');
  c.innerHTML=`<div class=cmt><div class=prof><b id=cfn></b><small>ID ${S.id}</small></div><div class=cur><span>🪙 <b>${S.coins}</b></span><span>💎 <b>${S.dia}</b></span></div><h1>COFRE</h1></div><div class=hxs>${hx}</div><div class=z id=cz style='left:22%;width:34%'></div><div class=cfr><div class=ig id=ig></div><div class=tb>${['🧢','🕶️','👕','👖','👟','🧥'].map((e,i)=>`<button${i?'':' class=on'}>${e}</button>`).join('')}</div><div class=ct>${['MODA','CAIXA DE ITENS','PACOTE','Cartões','CONSUMÍVEIS'].map((e,i)=>`<button${i?'':' class=on'}>${e}</button>`).join('')}</div></div><button class=bv id=bv>‹ VOLTAR</button>`;
  $('#cfn').textContent=S.name;L.hidden=true;c.hidden=false;cam.position.set(2,1.4,4.4);cam.lookAt(2,1.05,0);beep(660,.05);
  drag($('#cz'),(e,dx)=>{me.rotation.y+=dx*.012});
  let tab=0;
  const fill=()=>{const g=$('#ig'),e='<i class=it></i>';g.innerHTML=tab==5?(LUCK.own('Rei Dourado')?`<div class='it myt${S.set=='rei'?' on':''}' data-s=rei><svg class=pv viewBox='0 0 100 150' preserveAspectRatio='xMidYMax meet'><defs><radialGradient id=kgc><stop offset=0 stop-color='#ffe9a0' stop-opacity=.9 /><stop offset=1 stop-color='#ffb300' stop-opacity=0 /></radialGradient></defs><circle cx=50 cy=84 r=48 fill='url(#kgc)'/><rect x=31 y=60 width=38 height=70 fill='#c58a14' opacity=.9 />${ch(KING,50,128,2.5)}</svg><b class=sn>${KING.n}</b><em class=rar>${KING.rar.toUpperCase()}</em></div>`:'')+(LUCK.own('Sombra Real')?sombraItem():'')+e.repeat(9-(LUCK.own('Rei Dourado')?1:0)-(LUCK.own('Sombra Real')?1:0)):e.repeat(9);
   g.querySelectorAll('[data-s]').forEach(x=>x.onclick=()=>{S.set=S.set==x.dataset.s?'':x.dataset.s;save();setChar();fill();beep(660,.06)})};
  fill();
  c.querySelectorAll('.tb button,.ct button').forEach(b=>b.onclick=()=>{b.parentNode.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x==b));if(b.parentNode.classList.contains('tb')){tab=[...b.parentNode.children].indexOf(b);fill()}beep(500,.05)});
  const close=()=>{c.hidden=true;L.hidden=false;cam.position.set(0,1.4,4.2);cam.lookAt(0,1.05,0);beep(330,.05)};
  $('#bv').onclick=close},
 set(){const c=$('#st');let tab='g';
  const sg=(k,o)=>`<div class=sg data-k=${k}>${o.map(([v,l])=>`<button data-v=${v}>${l}</button>`).join('')}</div>`;
  const GX={q:()=>+S.q,sh:()=>+!!S.sh,hr:()=>+!!S.hr,fps:()=>+S.fps,sf:()=>+!!S.showfps};
  const SX={q:v=>{S.q=v;S.sh=v>0?1:0;S.hr=0;applyQ()},sh:v=>{S.sh=v;applyQ()},hr:v=>{S.hr=v;applyQ()},fps:v=>{S.fps=v},sf:v=>{S.showfps=!!v}};
  const TAB={
   s:()=>`<h2 class=sth>SENSIBILIDADE</h2><div class=sr>Câmera<input type=range id=s1 min=1 max=10><b class=sv id=v1></b></div>`,
   g:()=>`<h2 class=sth>GRÁFICO <small>Usar gráficos em alta definição e filtros pode <b>afetar a performance.</b></small></h2>
    <div class=sr>Gráficos${sg('q',[[0,'Suave'],[1,'Padrão'],[2,'Ultra']])}</div>
    <div class=sr>Alta Resolução${sg('hr',[[0,'Normal'],[1,'Alto']])}</div>
    <div class=sr>Sombra${sg('sh',[[0,'Desligado'],[1,'Ligado']])}</div>
    <div class='sr sf'>Filtros<div class=sfl>${FN.map((n,i)=>`<button class=fb data-f=${i}><i class=fv style='filter:${FLT[i]||'none'}'></i>${n}</button>`).join('')}</div></div>
    <h2 class=sth style='margin-top:14px'>DESEMPENHO</h2>
    <div class=sr>Alto FPS${sg('fps',[[30,'Normal'],[60,'Alto']])}</div>
    <div class=sr>Mostrar FPS${sg('sf',[[0,'Desligado'],[1,'Ligado']])}</div>`,
   a:()=>`<h2 class=sth>SOM</h2><div class=sr>Volume<input type=range id=s2 min=0 max=10><b class=sv id=v2></b></div>`,
   c:()=>`<h2 class=sth>CONTA</h2><div class=sr style='display:block;line-height:1.4'>${S.id?`Jogador: <b>${esc(S.name)}</b><br>ID: <b>${S.id}</b><br><br><button class=x id=lgo style='float:none'>Sair da conta</button>`:'Você não está conectado.'}</div>`,
   h:()=>`<h2 class=sth>EDITAR HUD</h2><div class=sr style='display:block;line-height:1.35'>Mova e redimensione cada botão da tela para onde achar melhor. A posição fica salva neste aparelho.<br><br><button class=pri id=hed>ABRIR EDITOR</button> <button class=x id=hrs style='float:none'>Restaurar padrão</button></div>`};
  const sync=()=>{c.querySelectorAll('.sg button').forEach(b=>b.classList.toggle('on',GX[b.parentNode.dataset.k]()==+b.dataset.v));c.querySelectorAll('.fb').forEach(b=>b.classList.toggle('on',+b.dataset.f==+S.flt))};
  const draw=()=>{
   c.innerHTML=`<div class=stn><h1>CONFIGURAÇÃO</h1>${[['s','Sensibilidade'],['g','Gráfico'],['a','Som'],['h','Editar HUD'],['c','Conta']].map(([k,n])=>`<button data-t=${k}${k==tab?' class=on':''}>${n}</button>`).join('')}</div><div class=stc>${TAB[tab]()}</div><button class=stx id=stx>✕</button>`;
   c.querySelectorAll('.stn button').forEach(b=>b.onclick=()=>{tab=b.dataset.t;beep(500,.05);draw()});
   c.querySelectorAll('.sg button').forEach(b=>b.onclick=()=>{SX[b.parentNode.dataset.k](+b.dataset.v);save();sync();beep(500,.05)});
   c.querySelectorAll('.fb').forEach(b=>b.onclick=()=>{S.flt=+b.dataset.f;applyF();save();sync();beep(500,.05)});
   const s1=$('#s1'),s2=$('#s2');
   if(s1){s1.value=S.sens;$('#v1').textContent=S.sens;s1.oninput=e=>{S.sens=+e.target.value;$('#v1').textContent=S.sens;save()}}
   if(s2){s2.value=S.vol*10;$('#v2').textContent=Math.round(S.vol*10);s2.oninput=e=>{S.vol=e.target.value/10;$('#v2').textContent=e.target.value;save();beep(440,.06)}}
   $('#stx').onclick=()=>{c.hidden=true;beep(330,.05)};const lg_=$('#lgo');if(lg_)lg_.onclick=()=>AUTH.logout();const he_=$('#hed');if(he_)he_.onclick=()=>{if(mode!='lobby'){he_.textContent='Volte ao lobby para editar';return}c.hidden=true;HUDEDIT.open()};const hr_=$('#hrs');if(hr_)hr_.onclick=()=>{HUDEDIT.reset();beep(400,.05)};
   sync()};
  draw();c.hidden=false;beep(660,.05)}
};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SC=$('#sc'),today=()=>new Date().toISOString().slice(0,10);
function scr(title,body,cls,showChar){const L=$('#lobby');SC.className='ov '+cls;
 SC.innerHTML=`<div class=cmt><div class=prof><b id=scn></b><small>ID ${S.id}</small></div><div class=cur><span>🪙 <b id=scc>${S.coins}</b></span><span>💎 <b id=scd>${S.dia}</b></span></div><h1>${title}</h1></div>${body}<button class=bv id=bvs>‹ VOLTAR</button>`;
 $('#scn').textContent=S.name;L.hidden=true;SC.hidden=false;beep(660,.05);
 if(showChar){cam.position.set(2,1.4,4.4);cam.lookAt(2,1.05,0)}
 $('#bvs').onclick=()=>{SC.hidden=true;L.hidden=false;cam.position.set(0,1.4,4.2);cam.lookAt(0,1.05,0);beep(330,.05)}}
const cash=()=>{refresh();const a=$('#scc'),b=$('#scd');a&&(a.textContent=S.coins);b&&(b.textContent=S.dia)};
/*LUCK*/
const LUCK={RN:['#9fb4c8','#4aa8ff','#c06bff','#ffc233'],RT:['COMUM','RARO','ÉPICO','LENDÁRIO'],COST1:10,COST10:90,PITY:20,MAX:215,
 PZ:[['🪙','100 Moedas',0,'c',100],['🧢','Boné Neon',1,'i'],['💎','5 Diamantes',0,'d',5],['🔫','Fuzil Rosa',2,'i'],['🪙','250 Moedas',0,'c',250],['🎒','Mochila Azul',1,'i'],['🩹','Kit Médico',0,'i'],['💎','20 Diamantes',1,'d',20],['🪙','100 Moedas',0,'c',100],['🕺','Emote Robô',2,'i'],['💎','5 Diamantes',0,'d',5],['🥾','Bota Veloz',1,'i'],['💎','50 Diamantes',2,'d',50]],
 TOP:[['🕶️','Sombra Real',3,'i'],['👑','Rei Dourado',3,'i']],
 BN:[{n:'SOMBRA REAL',s:'CONJUNTO LENDÁRIO',top:0,art:()=>sbThumb()},{n:'REI DOURADO',s:'CONJUNTO MÍTICO',top:1,art:()=>`<circle cx=50 cy=84 r=48 fill='#ffb300' opacity=.2 />${ch(KING,50,128,2.5)}`},{n:'RELÂMPAGO'},{n:'NEON'},{n:'TEMPESTADE'}],
 own:n=>(S.inv||[]).includes(n),
 rar(b){const L=LUCK;S.lk=S.lk||{};S.pity=S.pity|0;const c=(S.lk[b]|0)+1;let r;if(c>=L.MAX)r=3;else if(S.pity>=L.PITY-1)r=2;else{const x=Math.random()*100;r=x<62?0:x<90?1:x<99.4?2:3}S.lk[b]=r==3?0:c;S.pity=r>=2?0:S.pity+1;return r},
 pick(b,r){const L=LUCK;if(r==3)return L.TOP[L.BN[b].top];const c=L.PZ.filter(p=>p[2]==r);return c[Math.random()*c.length|0]},
 grant(p){const o={p,dup:0,bonus:0};if(p[3]=='c')S.coins+=p[4];else if(p[3]=='d')S.dia+=p[4];else{S.inv=S.inv||[];if(S.inv.includes(p[1])){o.dup=1;o.bonus=[5,10,25,100][p[2]];S.dia+=o.bonus}else S.inv.push(p[1])}return o}};
/*LUCKEND*/
Object.assign(MENU,{
 loja(){const CAT=['Novo','Pacote','Personagem','Moda','Item','Coleção','Pet'],TABS=['Normal','Arsenal','Caixas','Presentes','Resgatar'];
  let tab=0,cat=3;
  scr('LOJA',`<div class=shp></div>`,'lj',true);
  const draw=()=>{
   SC.querySelector('.shp').innerHTML=`<div class=shtabs>${TABS.map((t,i)=>`<button class='${i==tab?'on':''}' data-t=${i}>${t.toUpperCase()}</button>`).join('')}</div><div class=shb><div class=shg>${'<div class=pd></div>'.repeat(6)}</div><div class=shc>${CAT.map((c,i)=>`<button class='${i==cat?'on':''}' data-c=${i}>${c}</button>`).join('')}</div></div>`;
   SC.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{tab=+b.dataset.t;beep(500,.05);draw()});
   SC.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{cat=+b.dataset.c;beep(500,.05);draw()})};
  draw()},
sorte(){
  if(!document.getElementById('lkcss')){const st=document.createElement('style');st.id='lkcss';st.textContent=`.lk{position:absolute;inset:0;pointer-events:none;--lw:clamp(120px,24vh,170px)}
.lkl{position:absolute;left:0;top:calc(62px + env(safe-area-inset-top));bottom:96px;width:var(--lw);display:flex;flex-direction:column;gap:6px;justify-content:center}
.lks{pointer-events:auto;text-align:left;padding:5px 8px;border:0;border-left:4px solid #7be9ff;background:linear-gradient(90deg,#3a0d52,rgba(40,10,70,.55));color:#fff;line-height:1.1;transform:skewY(-3deg)}
.lks b{display:block;font:italic 700 clamp(13px,3.6vh,19px) var(--f)}.lks small{font:600 clamp(9px,2.3vh,12px) system-ui,sans-serif;opacity:.85}
.lks.on{background:linear-gradient(90deg,#c0398a,#6a2cc9);border-left-color:#ffe27a;box-shadow:0 0 14px #ff3cc0}.lks.ds{filter:grayscale(.6) brightness(.8)}
.lkm{position:absolute;left:calc(var(--lw) + 4vw);top:calc(52px + env(safe-area-inset-top));bottom:70px;display:flex}
.mc{position:relative;height:100%;aspect-ratio:.9;display:flex;flex-direction:column;align-items:center}
.mt{margin:0;font:italic 800 clamp(26px,9vh,52px) var(--f);color:#ffe27a;text-shadow:0 2px 0 #7a4a00,0 0 16px #ff3cc0;letter-spacing:1px;line-height:1}
.mo{position:absolute;right:-8%;top:-3%;width:clamp(40px,11vh,60px);aspect-ratio:1;border-radius:50%;border:2px solid #ff7bd5;background:rgba(40,10,80,.85);font:700 clamp(9px,2.6vh,13px) var(--f);color:#7be9ff;display:flex;align-items:center;justify-content:center;text-align:center;font-style:normal;line-height:1;transform:rotate(14deg);box-shadow:0 0 12px #ff3cc0}
.mb{flex:1;min-height:0;width:100%;display:flex;gap:2%;padding:2.5%;border:3px solid #6a5a48;border-radius:8px 8px 4px 4px;background:linear-gradient(#8b7b66,#4a3f33);box-shadow:0 0 22px rgba(255,60,192,.5)}
.mp{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;border:2px solid #ffe27a;background:linear-gradient(#5a1a7a,#1a0638);overflow:hidden;box-shadow:inset 0 0 18px #000}
.mpr,.mpg{padding:0 8%;background:linear-gradient(90deg,#ff9d2e,#ffe27a,#ff9d2e);color:#2a1700;font:700 clamp(9px,2.5vh,13px) var(--f);transform:skewX(-8deg);white-space:nowrap}.mpr{margin-top:4%}.mpg{margin:3% 0 4%}
.mp svg{flex:1;min-height:0;width:80%}.mp b{font:italic 800 clamp(16px,5.4vh,28px) var(--f);color:#ff7bd5;text-shadow:0 0 10px #ff3cc0;line-height:1}
.ms{width:22%;display:flex;flex-direction:column;gap:8%;align-items:center}
.mq{pointer-events:auto;width:100%;aspect-ratio:1;border-radius:50%;border:2px solid #ff7bd5;background:rgba(30,6,60,.85);font-size:clamp(16px,5vh,26px);box-shadow:0 0 12px #ff3cc0}
.ml{width:100%;text-align:center;background:#06303a;border:2px solid #7be9ff;color:#fff;font:700 clamp(8px,2.2vh,11px) var(--f);line-height:1.1;padding:4% 0}.ml b{display:block;font-size:clamp(14px,4.4vh,22px);color:#7be9ff}
.mf{margin:2% auto 0;padding:1px 10px;background:rgba(0,0,0,.75);border:1px solid #ffe27a;color:#ffe27a;font:600 clamp(10px,2.8vh,14px) system-ui,sans-serif;white-space:nowrap}
.lkv{position:absolute;right:4vw;top:calc(52px + env(safe-area-inset-top));bottom:70px;width:30vw;display:flex;align-items:flex-end}.lkv svg{width:100%;height:100%;overflow:visible;filter:drop-shadow(0 0 18px rgba(192,107,255,.7))}
.lkb{position:absolute;left:calc(var(--lw) + 4vw);right:4vw;bottom:4px;display:flex;justify-content:center;gap:3vw}
.lkb button{pointer-events:auto;position:relative;min-width:clamp(100px,20vw,170px);padding:clamp(3px,1vh,7px) 0;border:2px solid #7be9ff;border-radius:6px 18px 6px 18px;background:linear-gradient(#0a7fb8,#0a3f78);color:#fff;font:700 clamp(16px,4.6vh,26px) var(--f);line-height:1.05;transform:skewX(-8deg)}
.lkb button+button{background:linear-gradient(#ff9d2e,#c25a00);border-color:#ffe27a}.lkb button:active{transform:skewX(-8deg) scale(.95)}.lkb button:disabled{filter:grayscale(.8) brightness(.7)}
.lkb small{display:block;font:600 clamp(8px,2.2vh,11px) system-ui,sans-serif}.lkb em{position:absolute;left:-6px;top:-12px;font:italic 800 clamp(11px,3.2vh,16px) var(--f);color:#ffe27a;text-shadow:0 1px 0 #7a4a00}
.lkf{position:absolute;left:calc(var(--lw) + 4vw);right:4vw;bottom:calc(clamp(40px,11vh,64px) + 6px);text-align:center;font:600 clamp(10px,2.6vh,13px) system-ui,sans-serif;color:#ffd9a0;text-shadow:0 1px 2px #000}
.lkn{position:absolute;left:10px;bottom:48px;width:calc(var(--lw) - 6px);display:flex;gap:6px;align-items:flex-start;pointer-events:auto;font:600 clamp(9px,2.4vh,12px) system-ui,sans-serif;line-height:1.15}
.lkr{position:absolute;inset:0;z-index:5;pointer-events:auto;background:rgba(8,2,28,.94);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;animation:lkin .2s ease-out}.lkr[hidden]{display:none}.lkr.gold{background:radial-gradient(circle,#6a4a00,#08021c 70%)}
@keyframes lkin{from{transform:scale(.9);opacity:0}}
.lkw{text-align:center;--rc:#fff}.lkw i{display:block;font-style:normal;font-size:clamp(50px,18vh,90px);filter:drop-shadow(0 0 20px var(--rc))}.lkw b{display:block;font:700 clamp(20px,6vh,30px) var(--f);color:var(--rc)}.lkw small{display:block;font:600 13px system-ui,sans-serif;opacity:.9}
.lk10{display:grid;grid-template-columns:repeat(6,1fr);gap:5px;width:94%}.lk10 div{--rc:#9fb4c8;border:2px solid var(--rc);border-radius:6px;padding:3px 0;background:rgba(255,255,255,.08);text-align:center;line-height:1}.lk10 i{font-style:normal;font-size:clamp(20px,7vh,32px)}.lk10 small{display:block;font:600 10px system-ui,sans-serif}`;document.head.appendChild(st)}
  const L=LUCK,{PZ,RN,RT,BN}=L;let b=0,busy=0;
  scr('SORTE ROYALE',`<div class=lk><div class=lkl>${BN.map((x,i)=>`<button class='lks${i>1?' ds':''}' data-k=${i}><b>${x.n}</b><small>${i>1?'EM BREVE':x.s}</small></button>`).join('')}</div><div class=lkm></div><div class=lkv></div><div class=lkf id=lkf></div><div class=lkb><button id=g1><span id=g1v></span><small>1 giro</small></button><button id=g10><em>10+1</em>💎 ${L.COST10}<small>11 giros</small></button></div><label class=lkn><input type=checkbox id=lkc ${S.lkn?'checked':''}>Enviar notificação quando as recompensas estiverem disponíveis</label><div class=lkr hidden></div></div>`,'neon');
  const R=SC.querySelector('.lkr'),
  tickS=q=>{if(!S.vol)return;const a=ac();if(a)SFX.tone(a,a.currentTime,500+q*700,500+q*700,.04,.12*S.vol,'square')},
  fan=r=>{if(!S.vol)return;const a=ac();if(!a)return;const t=a.currentTime;SFX.pick();if(r>=2)[523,659,784,1047].forEach((f,i)=>SFX.tone(a,t+.12+i*.09,f,f,.35,.2*S.vol,'triangle'));if(r==3)[1568,2093,2637].forEach((f,i)=>SFX.tone(a,t+.5+i*.1,f,f*1.01,.5,.12*S.vol,'sine'))},
  poor=c=>modal('Diamantes insuficientes',`<p>Você precisa de 💎 ${c}. Resgate a recompensa diária no lobby para ganhar mais diamantes.</p>`),
  ui=()=>{const q=$('#g1');if(!q)return;const free=S.fday!=today(),tk=(S.spins|0)>0;$('#g1v').textContent=free?'GRÁTIS':tk?'🎟️ 1':'💎 '+L.COST1;
   $('#lkf').textContent=`Item raro garantido em ${L.MAX} rodadas  ·  🎟️ ${S.spins|0}  ·  🏆 Épico em ${L.PITY-(S.pity|0)} giros`;const m=SC.querySelector('.ml b');m&&(m.textContent=(S.lk||{})[b]|0);cash()},
  tick=()=>{const e=$('#lkt');if(!e){clearInterval(window.__lkT);return}if(!(S.lke>Date.now())){S.lke=Date.now()+14*864e5;save()}const d=S.lke-Date.now(),p=n=>String(n).padStart(2,'0');e.textContent=`Finaliza em ${d/864e5|0}d${p(d/36e5%24|0)}:${p(d/6e4%60|0)}:${p(d/1e3%60|0)}`},
  draw=()=>{const x=BN[b],t=L.TOP[x.top];SC.querySelectorAll('.lks').forEach((e,i)=>e.classList.toggle('on',i==b));
   SC.querySelector('.lkm').innerHTML=`<div class=mc><h2 class=mt>MEGALUCK</h2><i class=mo>OPEN<br>24H</i><div class=mb><div class=mp><div class=mpr>PRÊMIO MÁXIMO</div><svg viewBox='0 0 100 150' preserveAspectRatio='xMidYMax meet'>${x.art()}</svg><b>${t[1]}</b><div class=mpg>${L.own(t[1])?'✔ JÁ OBTIDO':'GARANTIDO NO '+L.MAX+'º GIRO'}</div></div><div class=ms><button class=mq id=lkq>🔍</button><div class=ml>LUCKY<b>0</b></div></div></div><div class=mf id=lkt></div></div>`;
   SC.querySelector('.lkv').innerHTML=`<svg viewBox='0 0 100 150' preserveAspectRatio='xMidYMax meet'>${x.art()}</svg>`;
   $('#lkq').onclick=()=>{beep(560,.05);modal('Prêmios · '+x.n,`<p><b style='color:${RN[3]}'>LENDÁRIO 0,6%</b> — ${t[0]} ${t[1]} (garantido no ${L.MAX}º giro)</p><p><b style='color:${RN[2]}'>ÉPICO 9,4%</b> — ${PZ.filter(p=>p[2]==2).map(p=>p[0]+' '+p[1]).join(', ')}</p><p><b style='color:${RN[1]}'>RARO 28%</b> — ${PZ.filter(p=>p[2]==1).map(p=>p[0]+' '+p[1]).join(', ')}</p><p><b style='color:${RN[0]}'>COMUM 62%</b> — ${PZ.filter(p=>p[2]==0).map(p=>p[0]+' '+p[1]).join(', ')}</p><p>Repetidos viram 💎 de bônus.</p>`)};
   tick();clearInterval(window.__lkT);window.__lkT=setInterval(tick,1000);ui()},
  show=(res,n,mx)=>{fan(mx);R.classList.toggle('gold',mx==3);
   const card=o=>{const p=o.p;return `<i>${p[0]}</i><b>${p[1]}</b><small style='color:${RN[p[2]]}'>${RT[p[2]]}${o.dup?` · repetido → 💎 ${o.bonus}`:p[2]==3?' · equipe em Cofre › Moda':''}</small>`};
   R.innerHTML=(n==1?`<div class=lkw style='--rc:${RN[res[0].p[2]]}'>${card(res[0])}</div>`:`<div class=lk10>${res.map(o=>`<div style='--rc:${RN[o.p[2]]}'><i>${o.p[0]}</i><small>${o.p[1]}${o.dup?' ↺':''}</small></div>`).join('')}</div>`)+`<button class=pri id=lko>OK</button>`;
   $('#lko').onclick=()=>{R.hidden=true;busy=0;draw();beep(500,.05)}},
  roll=(res,n)=>{R.hidden=false;R.classList.remove('gold');R.innerHTML=`<div class=lkw><i id=lki>🎰</i><b>GIRANDO…</b></div>`;
   const ic=PZ.concat(L.TOP).map(p=>p[0]),mx=Math.max(...res.map(o=>o.p[2])),N=18;let k=0;
   const step=()=>{k++;const e=$('#lki');if(e)e.textContent=ic[Math.random()*ic.length|0];tickS(k/N);if(k<N)setTimeout(step,45+Math.pow(k/N,3)*220);else setTimeout(()=>show(res,n,mx),250)};step()},
  go=n=>{if(busy)return;
   if(n==1){if(S.fday!=today())S.fday=today();else if((S.spins|0)>0)S.spins--;else if(S.dia>=L.COST1)S.dia-=L.COST1;else return poor(L.COST1)}
   else{if(S.dia>=L.COST10)S.dia-=L.COST10;else return poor(L.COST10)}
   const res=[];for(let i=0;i<(n==1?1:11);i++)res.push(L.grant(L.pick(b,L.rar(b))));
   save();busy=1;beep(700,.06);ui();roll(res,n)};
  SC.querySelectorAll('.lks').forEach(e=>e.onclick=()=>{if(busy)return;const k=+e.dataset.k;if(k>1)return modal('Em breve!','<p>Esta grade ainda vai chegar ao Sorte Royale.</p>');beep(560,.05);b=k;draw()});
  $('#g1').onclick=()=>go(1);$('#g10').onclick=()=>go(10);$('#lkc').onchange=e=>{S.lkn=e.target.checked?1:0;save()};
  draw()},
 pet(){
  scr('PET',`<div class=pg>${'<div class=pcd></div>'.repeat(6)}</div>`,'dust')},
 cole(){const CT=['Fundo','Avatar','Mochilas','Caixa loot','Paraquedas','Pranchas','Arma','Veículo','Emote'];
  let cat='Mochilas';scr('COLEÇÃO',`<div class=cl></div>`,'dust');
  const draw=()=>{
   SC.querySelector('.cl').innerHTML=`<div class=clc>${CT.map(c=>`<button class='${c==cat?'on':''}' data-c="${c}">${c}</button>`).join('')}</div><div class="clg${cat=='Arma'?' wg':''}">${cat=='Arma'?WPN.map(WCARD).join(''):'<div class=it2></div>'.repeat(12)}</div>`;
   SC.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{if(b.dataset.c=='Arma'){WPM.open();return}cat=b.dataset.c;beep(500,.05);draw()});
   SC.querySelectorAll('.wc').forEach(e=>e.onclick=()=>{const w=WPN[+e.dataset.w];beep(700,.06);modal(w.n,WDETAIL(w))})};
  draw()}
});
/* WPN -> js/weapons.js */
;const WR={Comum:'#b8c0cc',Rara:'#4aa3ff',Épica:'#c06bff',Lendária:'#ffc233',Mítica:'#ff4fd8',Especial:'#ff4d4d'},WS=['Dano','Alcance','Cadência','Precisão'];
const WCARD=(w,i)=>`<div class=wc data-w=${i} data-r="${w.r}" style="--c:${w.c};--d:${(i%5)*.35}s"><img src="${w.i}" alt="${w.n}"><i class=sp1></i><i class=sp2></i><em class=wt>${w.t}</em><em class=wr style="color:${WR[w.r]}">★ ${w.r}</em><b class=wn>${w.n}</b></div>`;
const WDETAIL=w=>`<div class=wdt style="--c:${w.c}"><div class=wc style="cursor:default"><img src="${w.i}" alt=""><i class=sp1></i><i class=sp2></i><em class=wt>${w.t}</em><em class=wr style="color:${WR[w.r]}">★ ${w.r}</em></div>${w.s.map((v,k)=>`<div class=wb><span>${WS[k]}</span><u><s style="width:${Math.max(4,v)}%"></s></u><b>${v}</b></div>`).join('')}</div>`;
// ====================== MENU DE ARMAS (estilo loja de armas): categorias, lista, arma 3D girando 360°, grade de skins ======================
window.WPM=(()=>{
const CATS=[['RIFLES','Fuzil'],['SUBMETRALHADORA','SMG'],['ESPINGARDA','Escopeta'],['SNIPER','Sniper'],['PISTOLAS','Pistola'],['ARMAS DE CONTATO',null],['PUNHO',null]];
const DESC={'M4A1':'Fuzil de assalto versátil, equilibrado em dano e controle.','AK47':'Dano alto por tiro, ideal para curta e média distância. Recuo forte.','SCAR':'Fuzil estável e preciso, ótimo em médias distâncias.','FAMAS':'Rajadas rápidas e letais, ótimas para o combate próximo.','AUG':'Fuzil lendário com precisão excelente e longo alcance.','MP40':'Submetralhadora clássica, leve e rápida de manusear.','UMP':'Equilíbrio entre cadência e dano para duelos próximos.','P90':'Carregador enorme e disparos rapidíssimos.','VECTOR':'A maior cadência de tiro: derrete inimigos de perto.','M1014':'Escopeta devastadora em curtíssima distância.','AWM':'Sniper lendária: um tiro, dano altíssimo.','SVD':'Sniper semiautomática, boa para disparos em sequência.','KAR98K':'Rifle de ferrolho clássico, preciso e letal.','M82B':'Rifle anti-material de potência absurda.','CARABINA ELÉTRICA':'Arma mítica que dispara descargas energizadas.','DESERT EAGLE':'Pistola potente com enorme dano por disparo.','G18':'Pistola automática leve e muito rápida.','USP':'Pistola confiável e precisa para emergências.','M500':'Revólver de grosso calibre, dano devastador.','PISTOLA DE SINAL':'Arma especial que lança sinais luminosos.'};
let el,q,R2,sc2,cam2,root,pivot,mdl,ready=0,on=0,raf=0,cat=0,cur=-1,spin=0,tilt=.12,vs=0,idle=0,drag=0,lx=0,ly=0,zoom=1,zt=1,base=6,lt=0;
const css=`<style>
#wmn{position:fixed;inset:0;z-index:30;display:none;background:#0d0a18;color:#fff;font-family:var(--f);overflow:hidden;-webkit-user-select:none;user-select:none;touch-action:none;--g:rgba(120,90,220,.45)}
#wmn.on{display:block}
#wmn .bg{position:absolute;inset:0;background:radial-gradient(60% 70% at 62% 44%,var(--g),transparent 72%),radial-gradient(45% 55% at 18% 90%,rgba(110,40,170,.35),transparent 70%),linear-gradient(135deg,#0f0a1f,#1f1038 55%,#0c0716)}
#wmn .bg::after{content:'';position:absolute;inset:0;background:repeating-linear-gradient(115deg,transparent 0 46px,rgba(255,255,255,.025) 46px 48px)}
#wmn .cat{position:absolute;left:0;top:0;bottom:0;width:15.2%;min-width:98px;background:rgba(13,17,33,.94);display:flex;flex-direction:column;overflow-y:auto;scrollbar-width:none;padding-left:env(safe-area-inset-left,0px)}
#wmn .cat::-webkit-scrollbar,#wmn .lst::-webkit-scrollbar,#wmn .sk::-webkit-scrollbar{display:none}
#wmn .cat button{flex:none;display:flex;align-items:center;width:100%;height:12.6vh;text-align:left;padding:0 9%;font:700 clamp(10px,3.1vh,18px) var(--f);letter-spacing:.2px;color:#e8ebf6;background:none;border:0;overflow-wrap:anywhere;line-height:1.12;cursor:pointer}
#wmn .cat button.on{background:#f0b429;color:#1b1204}
#wmn .cat .bk{height:8vh;font-size:clamp(10px,2.8vh,16px);color:#f0b429;border-bottom:1px solid rgba(255,255,255,.1)}
#wmn .lst{position:absolute;left:calc(15.4% + 2px);top:1.2%;bottom:0;width:7.6%;min-width:64px;overflow-y:auto;scrollbar-width:none;padding-bottom:3vh}
#wmn .li{position:relative;width:100%;aspect-ratio:1/1.04;margin-bottom:.9vh;background:linear-gradient(160deg,rgba(40,44,74,.95),rgba(20,22,42,.95));border:2px solid rgba(255,255,255,.07);cursor:pointer;overflow:hidden}
#wmn .li.on{border-color:#f0b429;box-shadow:0 0 12px rgba(240,180,41,.45)}
#wmn .li img{position:absolute;inset:14% 4% 20% 4%;width:92%;height:66%;object-fit:contain;pointer-events:none}
#wmn .li b{position:absolute;left:5%;top:3%;font:700 clamp(8px,2.1vh,12px) var(--f);color:#fff}
#wmn .li em{position:absolute;right:7%;bottom:3%;font:700 clamp(9px,2.4vh,14px) var(--f);font-style:normal;color:#fff}
#wmn .mn{position:absolute;left:22.9%;right:0;top:0;bottom:0}
#wmn canvas{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none;cursor:grab}
#wmn .hd{position:absolute;left:3.2%;top:3.4%;width:44%;pointer-events:none}
#wmn .hd h2{margin:0;font:700 clamp(18px,7.2vh,40px) var(--f);text-transform:uppercase;letter-spacing:.2px;text-shadow:0 2px 10px #000a;display:flex;align-items:center;gap:1.4vh;padding-bottom:.8vh;border-bottom:1px solid rgba(255,255,255,.35);width:max-content;max-width:100%}
#wmn .hd h2 i{display:inline-block;width:4.6vh;height:4.6vh;flex:none;background:var(--rc,#fff);clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);opacity:.9;box-shadow:0 0 12px var(--rc,#fff)}
#wmn .hd .lv{margin-top:1.2vh;font:700 clamp(10px,3.1vh,17px) var(--f);color:var(--rc,#fff)}
#wmn .hd p{margin:1vh 0 0;font:500 clamp(9px,2.9vh,16px) var(--f);color:#c9cde2;line-height:1.25;max-width:78%;text-shadow:0 1px 6px #000a}
#wmn .ib{position:absolute;display:flex;align-items:center;justify-content:center;width:9vh;height:9vh;border-radius:50%;background:rgba(10,12,26,.78);border:1px solid rgba(255,255,255,.22);color:#fff;cursor:pointer;padding:0}
#wmn .ib svg{width:58%;height:58%}
#wmn .ib.sh{left:3.4%;top:30vh;width:6.4vh;height:6.4vh;border-radius:0;background:none;border:0}
#wmn .ib.zm{right:2.6%;top:50%;transform:translateY(-50%)}
#wmn .ib.ch{right:2.6%;top:calc(50% + 11vh);transform:translateY(-50%)}
#wmn .ib.zm.on{background:#f0b429;color:#1b1204}
#wmn .up{position:absolute;right:2.6%;top:4.6%;font:700 italic clamp(10px,3.1vh,17px) var(--f);color:#f0b429;text-decoration:underline;cursor:pointer;background:none;border:0;letter-spacing:.3px}
#wmn .ac{position:absolute;right:2%;bottom:19.5%;display:flex;align-items:center;gap:2.2vw}
#wmn .ac label{display:flex;align-items:center;gap:.9vh;font:600 clamp(9px,2.8vh,15px) var(--f);color:#e8ebf6;cursor:pointer;white-space:nowrap}
#wmn .ac input{appearance:none;-webkit-appearance:none;width:2.6vh;height:2.6vh;border:2px solid #f0b429;background:transparent;margin:0;position:relative;cursor:pointer}
#wmn .ac input:checked::after{content:'';position:absolute;inset:.35vh;background:#f0b429}
#wmn .eq{min-width:24vh;padding:1.7vh 3vh;font:700 clamp(10px,3.2vh,17px) var(--f);letter-spacing:.6px;color:rgba(255,236,170,.45);background:linear-gradient(#7a6128,#5f4a1a);border:1px solid rgba(240,180,41,.35);box-shadow:inset 0 0 14px rgba(240,180,41,.18);cursor:default}
#wmn .sk{position:absolute;left:1.4%;right:0;bottom:2.4%;height:15.6%;display:flex;gap:1.1%;overflow-x:auto;scrollbar-width:none;padding-top:1.2vh;border-top:1px solid rgba(255,255,255,.14)}
#wmn .sl{position:relative;flex:none;width:16.6%;height:100%;background:linear-gradient(180deg,#241236 0%,#2f1446 65%,#7c2a8f 100%);border:2px solid rgba(255,255,255,.06);overflow:hidden}
#wmn .sl.on{border-color:#f0b429;background:linear-gradient(180deg,#3a1220 0%,#5a1a2a 70%,#8a2a3a 100%)}
#wmn .sl img{position:absolute;inset:6% 6% 22% 6%;width:88%;height:72%;object-fit:contain;pointer-events:none}
#wmn .sl .ck{position:absolute;right:4%;bottom:6%;width:3.6vh;height:3.6vh;background:#f0b429;color:#1b1204;font:900 2.6vh/3.6vh var(--f);text-align:center;border-radius:.4vh}
#wmn .sl .lvb{position:absolute;left:5%;bottom:5%;font:700 clamp(8px,2.4vh,13px) var(--f);color:var(--rc,#fff)}
#wmn .hint{position:absolute;left:50%;bottom:35%;transform:translateX(-50%);font:600 clamp(9px,2.6vh,14px) var(--f);color:rgba(255,255,255,.55);letter-spacing:.5px;pointer-events:none;transition:opacity .6s;white-space:nowrap}
#wmn .em{position:absolute;left:50%;top:46%;transform:translate(-50%,-50%);font:700 clamp(12px,4vh,22px) var(--f);color:rgba(255,255,255,.6);text-align:center;pointer-events:none}
</style>`;
const html=`<div id=wmn><div class=bg></div><nav class=cat></nav><div class=lst></div><div class=mn><canvas></canvas>
<div class=hd><h2><span class=nm></span><i></i></h2><div class=lv></div><p class=ds></p></div>
<button class="ib sh" title="Compartilhar"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7"/><path d="M12 3v12M7 8l5-5 5 5" transform="translate(0 0)"/></svg></button>
<button class=up>ATUALIZAR »</button>
<button class="ib zm" title="Zoom"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M10.5 7.5v6M7.5 10.5h6"/></svg></button>
<button class="ib ch" title="Personagem"><svg viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="6" r="3.6"/><path d="M5 21c0-5 3-8 7-8s7 3 7 8z"/></svg></button>
<div class=hint>↔ ARRASTE PARA GIRAR A ARMA</div><div class=em></div>
<div class=ac><label><input type=checkbox class=mk>Mostrar no lobby</label><button class=eq>EQUIPADO</button></div>
<div class=sk></div></div></div>`;
const rcOf=w=>WR[w.r]||'#fff';
const init=()=>{if(ready)return;ready=1;document.head.insertAdjacentHTML('beforeend',css);document.body.insertAdjacentHTML('beforeend',html);el=$('#wmn');q=s=>el.querySelector(s);
 R2=new T.WebGLRenderer({canvas:q('canvas'),antialias:true,alpha:true});R2.setPixelRatio(Math.min(window.devicePixelRatio||1,2));R2.setClearColor(0,0);
 sc2=new T.Scene();cam2=new T.PerspectiveCamera(28,2,.05,60);
 sc2.add(new T.AmbientLight(0xffffff,.95));const d1=new T.DirectionalLight(0xffffff,.85);d1.position.set(-3,4,2);sc2.add(d1);const d2=new T.DirectionalLight(0x8fb0ff,.6);d2.position.set(3,1,-3);sc2.add(d2);const d3=new T.DirectionalLight(0xffc98a,.35);d3.position.set(-2,-3,4);sc2.add(d3);
 root=new T.Group();pivot=new T.Group();root.add(pivot);sc2.add(root);
 q('.cat').innerHTML=`<button class=bk>‹ VOLTAR</button>`+CATS.map((c,i)=>`<button data-c=${i}>${c[0]}</button>`).join('');
 q('.cat').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.classList.contains('bk'))return close();setCat(+b.dataset.c);beep(500,.05)};
 q('.lst').onclick=e=>{const b=e.target.closest('.li');if(b){select(+b.dataset.w);beep(640,.05)}};
 q('.zm').onclick=()=>{zt=zt>1?1:1.55;q('.zm').classList.toggle('on',zt>1);beep(520,.04)};
 const soon=()=>modal('Em breve!','<p>Esta função ainda vai chegar.</p>');q('.ch').onclick=soon;q('.up').onclick=soon;q('.sh').onclick=soon;
 q('.mk').onchange=e=>{if(cur<0)return;S.wsh=S.wsh||{};S.wsh[WPN[cur].n]=e.target.checked?1:0;save()};
 const cv=q('canvas');
 cv.addEventListener('pointerdown',e=>{drag=1;lx=e.clientX;ly=e.clientY;vs=0;idle=0;cv.setPointerCapture(e.pointerId);cv.style.cursor='grabbing';q('.hint').style.opacity=0});
 cv.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-lx,dy=e.clientY-ly;lx=e.clientX;ly=e.clientY;spin+=dx*.011;vs=dx*.011;tilt=Math.max(-.45,Math.min(.75,tilt+dy*.006));idle=0});
 const up=()=>{drag=0;cv.style.cursor='grab';idle=0};cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
 window.addEventListener('resize',()=>{if(on)resize()})};
const resize=()=>{const r=q('canvas').getBoundingClientRect();if(!r.width)return;R2.setSize(r.width,r.height,false);cam2.aspect=r.width/r.height;cam2.updateProjectionMatrix();fit()};
let box=null;
const fit=()=>{if(!box)return;const sz=box.getSize(new T.Vector3()),hf=2*Math.atan(Math.tan(cam2.fov*Math.PI/360)*cam2.aspect),dw=(sz.z/.74)/(2*Math.tan(hf/2)),dh=(Math.max(sz.y,sz.x)/.62)/(2*Math.tan(cam2.fov*Math.PI/360));base=Math.max(dw,dh)+sz.x*.5};
const setCat=i=>{cat=i;const t=CATS[i][1];q('.cat').querySelectorAll('[data-c]').forEach(b=>b.classList.toggle('on',+b.dataset.c==i));
 const ids=[];WPN.forEach((w,k)=>{if(t&&w.t==t)ids.push(k)});
 q('.lst').innerHTML=ids.map(k=>`<div class=li data-w=${k}><b>${WPN[k].n.length>9?WPN[k].n.slice(0,8)+'…':WPN[k].n}</b><img src="${WPN[k].i}" alt=""><em>1</em></div>`).join('');
 if(ids.length)select(ids[0]);else empty()};
const skins=w=>{q('.sk').innerHTML=Array.from({length:8},(_,i)=>i==0&&w?`<div class="sl on"><img src="${w.i}" alt=""><span class=lvb>★ ${w.r}</span><span class=ck>✓</span></div>`:'<div class=sl></div>').join('')};
const empty=()=>{cur=-1;if(mdl){pivot.remove(mdl);mdl=null}box=null;q('.nm').textContent=CATS[cat][0];q('.lv').textContent='';q('.ds').textContent='';q('.hd h2 i').style.display='none';q('.em').textContent='Nenhuma arma nesta categoria ainda';q('.eq').style.display=q('.ac label').style.display='none';q('.hint').style.opacity=0;skins(null);el.style.setProperty('--g','rgba(120,90,220,.3)')};
const select=i=>{cur=i;const w=WPN[i];q('.lst').querySelectorAll('.li').forEach(b=>b.classList.toggle('on',+b.dataset.w==i));
 const c=rcOf(w);el.style.setProperty('--rc',c);const m=c.match(/#(..)(..)(..)/);el.style.setProperty('--g',m?`rgba(${parseInt(m[1],16)},${parseInt(m[2],16)},${parseInt(m[3],16)},.38)`:'rgba(120,90,220,.4)');
 q('.nm').textContent=w.n;q('.hd h2 i').style.display='';q('.lv').textContent='★ '+w.r+' · '+w.t;q('.ds').textContent=DESC[w.n]||'';q('.em').textContent='';q('.eq').style.display=q('.ac label').style.display='';
 q('.mk').checked=!!(S.wsh&&S.wsh[w.n]);skins(w);
 if(mdl){pivot.remove(mdl);mdl=null}
 const m0=WLD.model(i,1);box=new T.Box3().setFromObject(m0);const ct=box.getCenter(new T.Vector3());m0.position.sub(ct);mdl=m0;pivot.add(m0);box=new T.Box3().setFromObject(m0);
 spin=0;vs=0;idle=0;zt=1;zoom=1;q('.zm').classList.remove('on');q('.hint').style.opacity=1;fit()};
const loop=t=>{if(!on)return;raf=requestAnimationFrame(loop);const dt=Math.min(.05,(t-lt)/1000||0);lt=t;
 if(!drag){idle+=dt;if(Math.abs(vs)>.0004){spin+=vs;vs*=.93}else if(idle>2.2)spin+=dt*.55}
 zoom+=(zt-zoom)*Math.min(1,dt*8);cam2.position.set(-base/zoom,base*.04,0);cam2.lookAt(0,0,0);
 pivot.rotation.y=spin;root.rotation.z=tilt;R2.render(sc2,cam2)};
const open=()=>{init();el.classList.add('on');on=1;lt=performance.now();setCat(cat);requestAnimationFrame(()=>{resize();if(cur>=0)select(cur)});cancelAnimationFrame(raf);raf=requestAnimationFrame(loop)};
const close=()=>{on=0;cancelAnimationFrame(raf);el.classList.remove('on');beep(330,.05)};
return{open,close}})();

document.head.insertAdjacentHTML('beforeend',`<style>
.clg.wg{grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:max-content;gap:10px}.clg.wg .wc{height:auto;min-height:0}
.wc{--c:#fff;position:relative;border:2px solid var(--c);background:#080a16;overflow:hidden;aspect-ratio:1.9/1;flex:none;cursor:pointer;animation:wpulse 2.6s ease-in-out infinite;animation-delay:var(--d,0s);box-shadow:0 0 10px var(--c),inset 0 0 16px rgba(0,0,0,.6)}
.wc:active{transform:scale(.97)}
.wc img{position:absolute;inset:0;display:block;width:100%;height:100%;object-fit:cover;animation:wzoom 4s ease-in-out infinite;animation-delay:var(--d,0s);image-rendering:pixelated}
.wc::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 50% 60%,transparent 40%,var(--c) 190%);opacity:.35;pointer-events:none;mix-blend-mode:screen}
.wc::after{content:'';position:absolute;top:0;bottom:0;left:0;width:45%;background:linear-gradient(105deg,transparent 30%,rgba(255,255,255,.4) 50%,transparent 70%);transform:translateX(-160%) skewX(-12deg);animation:wshine 3.6s linear infinite;animation-delay:var(--d,0s);pointer-events:none}
.wc .wn{position:absolute;left:0;right:0;bottom:0;padding:3px 4px 4px;text-align:center;font:700 clamp(13px,3.4vh,19px) var(--f);letter-spacing:.5px;color:#fff;background:linear-gradient(transparent,rgba(0,0,0,.88) 45%);text-shadow:0 0 6px var(--c),0 0 12px var(--c);border-bottom:3px solid var(--c)}
.wc .wt,.wc .wr{position:absolute;top:4px;font:600 11px var(--f);font-style:normal;padding:1px 6px;background:rgba(0,0,0,.65);border:1px solid rgba(255,255,255,.25);text-transform:uppercase;letter-spacing:.5px;z-index:1}
.wc .wt{left:4px;color:var(--c)}.wc .wr{right:4px}
.wc .sp1,.wc .sp2{position:absolute;width:5px;height:5px;background:#fff;border-radius:50%;box-shadow:0 0 8px 3px var(--c);animation:wtw 2s ease-in-out infinite;pointer-events:none}
.wc .sp1{left:22%;top:34%}.wc .sp2{right:18%;top:58%;animation-delay:1s}
.wdt{width:min(80vw,380px)}.wdt .wc{margin-bottom:10px}
.wb{display:grid;grid-template-columns:86px 1fr 34px;gap:8px;align-items:center;font:600 16px var(--f);margin:4px 0}.wb u{display:block;height:9px;background:rgba(255,255,255,.15);text-decoration:none}.wb s{display:block;height:100%;background:var(--c);box-shadow:0 0 8px var(--c);text-decoration:none}.wb b{text-align:right}
@keyframes wpulse{50%{box-shadow:0 0 20px var(--c),0 0 4px var(--c),inset 0 0 16px rgba(0,0,0,.6)}}
@keyframes wzoom{50%{transform:scale(1.07)}}
@keyframes wshine{0%,55%{transform:translateX(-160%) skewX(-12deg)}100%{transform:translateX(420%) skewX(-12deg)}}
@keyframes wtw{0%,100%{opacity:0;transform:scale(.4)}50%{opacity:1;transform:scale(1)}}
@media(prefers-reduced-motion:reduce){.wc,.wc img,.wc::after,.wc i{animation:none}}
</style>`);
const daily=()=>{if(S.dly==today()){modal('Recompensa diária','<p>Você já resgatou a recompensa de hoje. Volte amanhã!</p>');return}
 modal('Recompensa diária','<p>Entre todo dia e ganhe prêmios!</p><button class=pri id=dc>Resgatar +100 🪙 +30 💎</button>',()=>{$('#dc').onclick=()=>{S.coins+=100;S.dia+=30;S.dly=today();save();cash();$('#modal').hidden=true;beep(880,.12)}})};
const SOON={amigos:'Amigos',rank:'Ranking',msg:'Mensagens',pass:'Passe Rei',camp:'Fogueira',crate:'Caixa de suprimentos'};
document.querySelectorAll('[data-x]').forEach(b=>b.onclick=()=>{const k=b.dataset.x;if(k=='daily')daily();else modal(SOON[k],'<p>Em breve!</p>')});
setTimeout(()=>{if(S.dly!=today())daily()},800);
document.querySelectorAll('[data-m]').forEach(b=>b.onclick=()=>MENU[b.dataset.m]());
$('#md').onclick=()=>MENU.mode();$('#go').onclick=()=>{SFX.start();PM.start()};
$('#bf').addEventListener('pointerdown',()=>{if(ICE.ph){ICE.confirm();return}G.fire=1});['pointerup','pointerleave','pointercancel'].forEach(k=>$('#bf').addEventListener(k,()=>G.fire=0));
// ---------- modos de jogo, patentes e combate ----------
const RN=['Bronze','Prata','Ouro','Platina','Diamante','Mestre'],rk=p=>p>=1800?'Desafiante':RN[p/300|0]+' '+['I','II','III'][p%300/100|0];
const GM={br:{n:'BATTLE ROYALE RANQUEADA',d:'60 jogadores · cidade grande · zona fecha',c:'#7a1f3d,#d9531e',r:1,b:1},cs:{n:'CS RANQUEADO',d:'3x3 · melhor de 7 rodadas',c:'#10346b,#3a8fd9',r:1,b:1},dm:{n:'MATA-MATA',d:'Todos contra todos · 15 abates',c:'#3d1f6b,#c04fd1',b:1},gl:{n:'GLADIADORES 1X1',d:'Duelo · 5 abates vencem',c:'#5b3b0a,#e0a62d',b:1},tr:{n:'TREINAMENTO',d:'Mapa livre sem pressão',c:'#14502c,#4cc16a'},pe:{n:'PERSONALIZADO',d:'Horário, gravidade e velocidade',c:'#2a3342,#6c7a91'}};
const PL={isP:1,team:0,hp:100,a:1,k:0,x:0,z:0},rc=new T.Raycaster(),rr=a=>(Math.random()-.5)*2*a;
const zone=new T.Mesh(new T.CylinderGeometry(1,1,40,48,1,true),new T.MeshBasicMaterial({color:0xff4d5e,transparent:true,opacity:.22,side:T.DoubleSide,fog:false}));zone.position.y=20;zone.visible=false;sc.add(zone);
const los=(a,b,c,d)=>{for(let i=1;i<14;i++){const x=a+(c-a)*i/14,z=b+(d-b)*i/14;if(solids.some(s=>Math.abs(x-s.x)<s.hw&&Math.abs(z-s.z)<s.hd)||(window.ISL&&ISL.on&&ISL.hit(x,z)))return false}return true};
const rpos=()=>{const a=Math.random()*6.28,r=18+Math.random()*42;return[Math.cos(a)*r,Math.sin(a)*r]};
const wp=e=>{const m=G.m;if(m=='br'){if(window.ISL&&ISL.on){const q=ISL.rp(Math.max(10,G.z-6));e.wx=q[0];e.wz=q[1]}else{const r=Math.max(4,G.z-6)*Math.random(),a=Math.random()*6.28;e.wx=Math.cos(a)*r;e.wz=Math.sin(a)*r}}else if(m=='cs'){e.wx=rr(40);e.wz=(e.team?1:-1)*(10+Math.random()*40)}else{e.wx=PL.x+rr(15);e.wz=PL.z+rr(15)}};
function spawn(team,ci,x,z){const g=buildChar(CH[ci%6]);g.userData.armed=1;g.traverse(o=>{if(o.isMesh)o.castShadow=G.m!='br'});const e={g,team,hp:100,a:1,k:0,x,z,y:0,py:0,cd:1+Math.random(),wx:x,wz:z,fy:0,t:Math.random()*9};e.wk=SFX.kinds[Math.random()*4|0];g.userData.e=e;WLD.kit(e);g.position.set(x,0,z);sc.add(g);G.e.push(e)}
function hurt(t,d,by){if(!t.a||!G.on||t.air)return;if(t.isP&&window.ISL&&ISL.on)d*=ISL.dm();t.hp-=d;if(t.isP){G.fl=.2;if(d>=5)SFX.hit()}if(t.hp>0)return;t.hp=0;t.a=0;if(by)by.k++;if(t.isP)G.dead=1;else{ICE.drop(t.x,t.z);WLD.dropBot(t)}if(G.m=='dm')t.rs=t.isP?2.5:3;if(G.m=='gl'&&G.on)GLD.next();G.chk()}
function resp(o){const[x,z]=rpos();o.hp=100;o.a=1;if(o.isP){P.x=x;P.z=z;G.dead=0;me.visible=true}else{o.x=x;o.z=z;o.g.visible=true}}
function shoot(){const w=WLD.w();if(!w)return;SFX.shot(w.snd);me.userData.sh=t+.18;const sx=window.__scoped?0:.12,sp=w.sp*(window.__scoped?.3:1);
 for(let k=0;k<w.pel;k++){rc.setFromCamera({x:sx+(k||sp>.01?rr(sp):0),y:k||sp>.01?rr(sp):0},cam);const h=rc.intersectObjects(G.e.filter(e=>e.a).map(e=>e.g),true)[0];
  {const wh=ICE.ray(rc.ray);if(wh&&(!h||wh.d<h.distance)){ICE.dmg(wh.w,w.dmg*(w.pel>1?2:.8),wh.p);continue}}if(!h)continue;let o=h.object;while(o&&!o.userData.e)o=o.parent;const e=o&&o.userData.e;
  if(e&&e.team!=PL.team&&los(cam.position.x,cam.position.z,h.point.x,h.point.z)){const fall=w.k=='sg'?Math.max(.25,1-h.distance/22):1;hurt(e,(h.point.y>1.45?2:1)*w.dmg*fall,PL);$('#xh').style.color='#ff4d5e';SFX.tick();setTimeout(()=>$('#xh').style.color='',120)}}}
// ---------- cidade grande (só no BR), avião e paraquedas ----------
const CT=new T.Group(),CS=[];CT.visible=false;sc.add(CT);
const PLN=new T.Group();[[3,3,14,0xdfe6f2,0,0,0],[24,.5,4.5,0xffc233,0,0,0],[8,.5,3,0xdfe6f2,0,.6,6],[.5,4,3,0xff4d5e,0,2,6.5]].forEach(([w,h,d,c,x,y,z])=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),M(c));m.position.set(x,y,z);PLN.add(m)});PLN.rotation.y=-Math.PI/2;PLN.visible=false;sc.add(PLN);
const cano=new T.Mesh(new T.SphereGeometry(2.3,14,7,0,6.283,0,1.45),new T.MeshLambertMaterial({color:0xff4d5e,side:T.DoubleSide}));cano.visible=false;sc.add(cano);
// ====================== ARMAS 3D: modelos, loot no chão, mão, costas, inventário ======================
const WLD=(()=>{
const WM=new T.MeshLambertMaterial({vertexColors:true}),WGM=new T.MeshBasicMaterial({vertexColors:true});
// junta todas as caixas de uma arma em UMA geometria com cor por vértice (leve mesmo com 60 bots)
const merge=L=>{const pos=[],nor=[],col=[],idx=[],c=new T.Color(),m4=new T.Matrix4();let o=0;
 for(const[x,y,z,w,h,d,hex,rx]of L){const q=new T.BoxGeometry(w,h,d);if(rx)q.applyMatrix4(m4.makeRotationX(rx));q.translate(x,y,z);c.set(hex);const p=q.attributes.position,n=q.attributes.normal;
  for(let i=0;i<p.count;i++){pos.push(p.getX(i),p.getY(i),p.getZ(i));nor.push(n.getX(i),n.getY(i),n.getZ(i));col.push(c.r,c.g,c.b)}
  q.index.array.forEach(i=>idx.push(i+o));o+=p.count;q.dispose()}
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setAttribute('normal',new T.Float32BufferAttribute(nor,3));geo.setAttribute('color',new T.Float32BufferAttribute(col,3));geo.setIndex(idx);geo.computeBoundingSphere();return geo};
// eixo do modelo: +Z = cano, +Y = cima, +X = direita. Origem = empunhadura
const kids=g=>{while(g.children.length)g.remove(g.children[0])};
const sg=(b,z0,z1,y,w,h,cols)=>{const n=cols.length,l=(z1-z0)/n;cols.forEach((c,i)=>b(0,y,z0+l*(i+.5),w,h,l,c))};
const mag=(b,g,t,x,k,s,a)=>{ // carregadores
 if(t=='str'){b(0,-.14,x,.065,.2,.09,k);g(0,-.2,x,.07,.018,.095,a)}
 else if(t=='curve'){b(0,-.12,x-.01,.065,.14,.09,k);b(0,-.235,x+.03,.065,.13,.09,k,.35);g(0,-.19,x+.02,.07,.016,.095,a,.2)}
 else if(t=='ang'){b(0,-.14,x+.03,.065,.22,.09,k,.28);g(0,-.2,x+.05,.07,.016,.095,a,.28)}
 else if(t=='long'){b(0,-.17,x,.06,.3,.08,k);g(0,-.2,x,.065,.018,.085,a)}};
const optic=(b,g,t,k,a,z=.1)=>{
 if(t=='carry'){b(0,.19,z-.2,.045,.07,.035,k);b(0,.19,z+.12,.045,.07,.035,k);b(0,.235,z-.04,.05,.035,.34,k);g(0,.245,z+.14,.02,.02,.012,a)}
 else if(t=='scope'){b(0,.195,z-.08,.045,.06,.045,k);b(0,.195,z+.12,.045,.06,.045,k);b(0,.255,z+.02,.065,.065,.34,k);b(0,.255,z+.2,.085,.085,.07,k);b(0,.255,z-.17,.08,.08,.05,k);g(0,.255,z+.24,.055,.055,.012,a)}
 else if(t=='dot'){b(0,.19,z,.05,.07,.08,k);b(0,.235,z,.056,.025,.08,k);g(0,.232,z+.045,.025,.025,.01,a)}
 else if(t=='flip'){b(0,.19,z-.18,.03,.05,.03,k);b(0,.19,z+.3,.02,.07,.02,k)}};
const rifle=o=>(b,g)=>{const{m,s,k,a}=o,hg=o.hg??.24,bl=o.bl??.28,zb=.32+hg;
 if(o.bull){ // bullpup (coronha embutida)
  sg(b,-.42,.26,.075,.095,.17,o.pat||[m,s,m,s]);b(0,.172,-.05,.05,.022,.52,k);
  b(0,-.075,.07,.075,.2,.08,k,.25);b(0,-.01,.0,.03,.02,.12,k);b(0,-.1,-.17,.07,.2,.1,k,-.1);g(0,-.15,-.17,.075,.016,.105,a);
  b(0,.07,.31,.075,.085,.1,s);b(0,.075,.31+.05+bl/2,.045,.045,bl,k);b(0,.075,.36+bl+.03,.06,.06,.06,k);g(0,.075,.36+bl+.062,.064,.064,.012,a);
  g(.049,.075,-.08,.006,.022,.42,a);g(-.049,.075,-.08,.006,.022,.42,a);
  if(o.op=='scope')optic(b,g,'scope',k,a,-.05);else optic(b,g,o.op||'carry',k,a,-.05);
  b(0,-.04,-.44,.09,.19,.04,k);return}
 sg(b,-.18,.32,.075,.09,.15,o.pat||[m,s,m,k,m]);b(0,.16,.07,.05,.02,.42,k);
 b(0,-.07,-.12,.075,.2,.08,k,.28);b(0,-.02,-.04,.03,.02,.1,k);
 sg(b,.32,zb,.065,.105,.115,o.hpat||[s,m]);b(0,.075,zb+bl/2,.045,.045,bl,k);b(0,.075,zb+bl+.03,.06,.06,.06,k);g(0,.075,zb+bl+.062,.064,.064,.012,a);b(0,.125,zb+bl-.03,.02,.06,.02,k);
 g(.047,.075,.07,.006,.02,.4,a);g(-.047,.075,.07,.006,.02,.4,a);g(.054,.065,.32+hg/2,.006,.02,hg*.8,a);g(-.054,.065,.32+hg/2,.006,.02,hg*.8,a);
 if(o.st=='ak'){b(0,.03,-.36,.075,.15,.34,s,-.1);b(0,-.03,-.52,.08,.2,.06,k,-.1)}
 else if(o.st=='box'){b(0,.06,-.36,.07,.12,.34,m);b(0,.03,-.54,.08,.18,.06,s)}
 else{b(0,.075,-.3,.05,.05,.2,k);b(0,.04,-.45,.075,.18,.1,m);g(0,.0,-.5,.078,.012,.012,a)}
 mag(b,g,o.mg||'str',.07,k,s,a);optic(b,g,o.op||'rail',k,a);
 if(o.extra)o.extra(b,g)};
const smg=o=>(b,g)=>{const{m,s,k,a}=o,bl=o.bl??.14;
 sg(b,-.16,.3,.07,.09,.14,o.pat||[m,s,m]);b(0,.15,.07,.05,.02,.3,k);b(0,-.07,-.1,.075,.19,.08,k,.25);b(0,-.02,-.03,.03,.02,.1,k);
 sg(b,.3,.42,.06,.1,.1,[s,m]);b(0,.07,.42+bl/2,.04,.04,bl,k);b(0,.07,.44+bl,.056,.056,.06,k);g(0,.07,.475+bl,.06,.06,.012,a);
 g(.047,.07,.07,.006,.02,.38,a);g(-.047,.07,.07,.006,.02,.38,a);
 if(o.st=='wire'){b(.025,.075,-.3,.016,.016,.26,k);b(-.025,.075,-.3,.016,.016,.26,k);b(0,.04,-.43,.07,.15,.04,k)}else{b(0,.07,-.3,.05,.06,.22,k);b(0,.045,-.43,.07,.15,.06,m)}
 mag(b,g,o.mg||'long',.08,k,s,a);optic(b,g,o.op||'dot',k,a,.05);if(o.extra)o.extra(b,g)};
const pistol=o=>(b,g)=>{const{m,s,k,a}=o,L=o.len??.2;
 sg(b,-.07,-.07+L,.07,.075,.085,o.pat||[m,s,m]);b(0,.085,-.07+L/2,.06,.012,L*.9,k);
 b(0,-.012,.03+L*.35,.06,.05,L*.9,o.frame||k);b(0,.065,-.07+L+.07,.04,.04,.12,k);if(o.bl)b(0,.065,-.07+L+.13,.032,.032,.08,k);
 b(0,-.065,-.04,.07,.17,.075,k,.22);b(0,-.03,.04,.03,.016,.09,k);g(.039,.075,.02+L/2-.07,.006,.016,L*.8,a);g(-.039,.075,.02+L/2-.07,.006,.016,L*.8,a);
 g(0,.066,-.07+L+.135,.044,.044,.012,a);b(0,.1,-.05,.03,.03,.02,k);b(0,.1,-.07+L,.012,.03,.02,k);g(0,-.115,-.03,.072,.012,.078,a,.22);if(o.extra)o.extra(b,g)};
const sniper=o=>(b,g)=>{const{m,s,k,a}=o,bl=o.bl??.62;
 sg(b,-.18,.34,.075,.085,.14,o.pat||[s,m,s]);b(0,.155,.08,.045,.02,.36,k);
 b(0,-.07,-.1,.07,.19,.075,k,.25);b(0,-.02,-.03,.03,.02,.1,k);
 if(o.wood){b(0,.01,-.42,.075,.17,.5,m,-.04);b(0,.1,-.4,.07,.04,.2,s);b(0,.0,.3,.08,.08,.32,m);b(0,-.01,.1,.078,.1,.3,m)}
 else{b(0,.01,-.42,.075,.17,.5,m);b(0,.115,-.4,.07,.04,.22,s);b(0,.01,.34,.07,.07,.3,m)}
 b(0,.075,.64+bl/2-.1,.05,.05,bl+.1,k);b(0,.075,.64+bl+.08,.07,.07,.1,k);g(0,.075,.64+bl+.132,.074,.074,.012,a);
 g(.044,.075,.08,.006,.02,.34,a);g(-.044,.075,.08,.006,.02,.34,a);g(.04,.012,.35,.006,.02,.26,a);g(-.04,.012,.35,.006,.02,.26,a);
 b(.065,.09,.0,.06,.03,.03,k);b(.09,.09,.0,.03,.03,.03,k);mag(b,g,'str',.08,k,s,a);optic(b,g,'scope',k,a,.08);
 if(o.big){b(0,.255,.1,.09,.09,.1,k);b(.04,-.06,.62,.015,.12,.015,k,.25);b(-.04,-.06,.62,.015,.12,.015,k,-.25)}if(o.extra)o.extra(b,g)};
const shotgun=o=>(b,g)=>{const{m,s,k,a}=o;
 sg(b,-.18,.3,.075,.09,.14,[m,k,m]);b(0,.155,.06,.04,.018,.4,k);b(0,-.07,-.1,.075,.19,.08,k,.28);b(0,-.02,-.03,.03,.02,.1,k);
 b(0,.03,-.4,.075,.16,.4,m,-.07);b(0,-.04,-.6,.08,.2,.05,k,-.07);
 b(0,.08,.3+.35,.05,.05,.7,k);b(0,.025,.3+.3,.04,.04,.58,s);b(0,.02,.55,.075,.065,.2,s);g(0,.02,.55,.08,.012,.2,a);
 b(0,.08,.3+.72,.06,.06,.05,k);g(0,.08,.3+.75,.064,.064,.012,a);g(.047,.075,.06,.006,.02,.4,a);g(-.047,.075,.06,.006,.02,.4,a);
 b(0,.125,.3+.68,.02,.05,.02,k);optic(b,g,'flip',k,a)};
const revolver=o=>(b,g)=>{const{m,s,k,a}=o;
 b(0,.06,-.02,.07,.1,.16,m);b(0,.06,.14,.075,.1,.12,s);g(0,.06,.14,.08,.012,.12,a);b(0,.07,.26,.055,.055,.24,m);b(0,.105,.36,.02,.04,.04,k);b(0,.03,.3,.04,.03,.2,m);
 b(0,-.065,-.06,.075,.19,.08,k,.3);b(0,-.03,.04,.03,.016,.09,k);b(0,.125,-.05,.03,.03,.04,k);g(.04,.06,-.02,.006,.02,.14,a);g(-.04,.06,-.02,.006,.02,.14,a)};
const flare=o=>(b,g)=>{const{m,s,k,a}=o;
 sg(b,-.07,.2,.07,.085,.1,[m,s,m]);b(0,.07,.31,.1,.1,.16,m);b(0,.07,.4,.115,.115,.04,k);g(0,.07,.425,.09,.09,.012,a);
 b(0,-.065,-.04,.075,.17,.08,k,.22);b(0,-.03,.04,.03,.016,.09,k);g(.046,.07,.05,.006,.02,.2,a);g(-.046,.07,.05,.006,.02,.2,a);b(0,.135,.1,.03,.05,.03,k)};
// arcos de energia da Carabina Elétrica
const arcs=(b,g)=>{const a=0x3de0ff,w=0xffffff;[[.05,.12,.0],[-.05,.1,.2],[.05,.06,.38],[-.05,.14,.5],[.04,.04,.62]].forEach(([x,y,z],i)=>{g(x,y,z,.02,.045,.05,i%2?w:a);g(x*1.4,y+.03,z+.04,.016,.035,.04,a)});
 [.45,.55,.65,.75].forEach(z=>g(0,.075,z,.085,.085,.014,a))};
// ordem = mesma da grade da COLEÇÃO
const DEF=[
 rifle({m:0x2f333c,s:0xd8dce6,k:0x15171c,a:0x7fb8ff,op:'carry',hg:.26,bl:.3,pat:[0x2f333c,0xd8dce6,0x2f333c,0xaab0bd,0x2f333c]}),
 rifle({m:0x1b1b1f,s:0xe02a22,k:0x101012,a:0xff3b30,st:'ak',mg:'curve',op:'flip',hg:.26,bl:.28,pat:[0xe02a22,0x1b1b1f,0xe02a22,0x1b1b1f,0xe02a22],hpat:[0xe02a22,0x1b1b1f]}),
 rifle({m:0x2a62d8,s:0xcfe3ff,k:0x151a28,a:0x4aa3ff,st:'box',mg:'ang',op:'dot',hg:.22,bl:.26,pat:[0x2a62d8,0xcfe3ff,0x2a62d8,0xcfe3ff,0x2a62d8]}),
 rifle({bull:1,m:0x7a2ee0,s:0xb07cff,k:0x1a1030,a:0xc07bff,op:'carry',bl:.16,pat:[0x7a2ee0,0xb07cff,0x7a2ee0,0xb07cff,0x7a2ee0]}),
 rifle({bull:1,m:0xe0a41e,s:0xffd35a,k:0x2a2008,a:0xffe27a,op:'scope',bl:.3,pat:[0xe0a41e,0xffd35a,0xe0a41e,0xffd35a]}),
 smg({m:0x1fbfd8,s:0x7ff0ff,k:0x10222a,a:0x29e0ff,st:'wire',mg:'long',op:'dot',bl:.14}),
 smg({m:0x2a2440,s:0x8a5cff,k:0x120f20,a:0xa87cff,mg:'str',op:'dot',bl:.16,pat:[0x2a2440,0x8a5cff,0x2a2440,0x8a5cff]}),
 (b,g)=>{const m=0x39d63a,s=0x8cff6a,k=0x0f2a10,a=0x4cff3a; // P90: carregador horizontal em cima
  sg(b,-.36,.24,.04,.1,.16,[m,s,m,s]);b(0,.15,-.04,.08,.06,.46,k);g(0,.185,-.04,.07,.012,.44,a);b(0,.22,.0,.03,.05,.1,k);
  b(0,-.07,.04,.075,.2,.08,k,.25);b(0,-.015,-.03,.03,.02,.12,k);b(0,.04,.34,.07,.08,.14,s);b(0,.045,.46,.04,.04,.08,k);g(0,.045,.5,.044,.044,.012,a);
  g(.052,.04,-.06,.006,.03,.5,a);g(-.052,.04,-.06,.006,.03,.5,a);b(0,-.03,-.4,.09,.2,.04,k)},
 smg({m:0xf0f0f0,s:0xe0243c,k:0x1a1a1f,a:0xff3b5c,st:'wire',mg:'ang',op:'dot',bl:.1,pat:[0xf0f0f0,0xe0243c,0xf0f0f0,0xe0243c]}),
 shotgun({m:0x3b3326,s:0xff9a1f,k:0x1a1710,a:0xffb13d}),
 sniper({m:0x3d6b10,s:0x8fd422,k:0x15200a,a:0x6bff3a,bl:.64,pat:[0x8fd422,0x3d6b10,0x8fd422]}),
 sniper({m:0x2f68e0,s:0xf2f6ff,k:0x10182a,a:0x4aa3ff,bl:.55,pat:[0xf2f6ff,0x2f68e0,0xf2f6ff]}),
 sniper({wood:1,m:0xb8742e,s:0xe39a4a,k:0x2a1a0c,a:0xffa040,bl:.6,pat:[0xb8742e,0xe39a4a,0xb8742e]}),
 sniper({big:1,m:0x2a2438,s:0x8a3fe0,k:0x120f1e,a:0xb04dff,bl:.7,pat:[0x8a3fe0,0x2a2438,0x8a3fe0]}),
 rifle({m:0x2a78ff,s:0x9fd8ff,k:0x0e1a3a,a:0x3de0ff,op:'dot',hg:.24,bl:.28,pat:[0x2a78ff,0x9fd8ff,0x2a78ff,0x9fd8ff,0x2a78ff],extra:arcs}),
 pistol({m:0xe8ecf2,s:0xa8b0bd,k:0x1a1d24,a:0xffe27a,len:.26,bl:1,pat:[0xe8ecf2,0xa8b0bd,0xe8ecf2]}),
 pistol({m:0x1f2a4a,s:0x2f56d8,k:0x0c0f18,a:0x3d6bff,len:.2,pat:[0x1f2a4a,0x2f56d8]}),
 pistol({m:0x20232c,s:0x29b6ff,k:0x0c0e14,a:0x29b6ff,len:.22,bl:1,pat:[0x20232c,0x20232c,0x29b6ff]}),
 revolver({m:0xc8ccd6,s:0xff9a2a,k:0x1b1c20,a:0xffa040}),
 flare({m:0xe5222a,s:0xff6a5a,k:0x2a0a0c,a:0xff2d2d})];
// atributos de jogo: k=tipo, dmg, cd (tempo entre tiros), mag, rl (recarga), snd, auto, pel (balas), sp (dispersão), sc (tamanho na mão), w (chance no chão)
const mkS=(k,dmg,cd,mg,rl,snd,auto,sc,w,x={})=>Object.assign({k,dmg,cd,mag:mg,rl,snd,auto,sc,w,sp:.012,pel:1},x);
const WS=[mkS('ar',24,.13,30,1.6,'rifle',1,1.15,4),mkS('ar',30,.15,30,1.9,'rifle',1,1.15,3),mkS('ar',28,.14,30,1.7,'rifle',1,1.15,3),mkS('ar',22,.09,25,1.6,'rifle',1,1.2,2),mkS('ar',25,.12,30,1.7,'rifle',1,1.2,1.2),
 mkS('sm',18,.09,32,1.3,'smg',1,1.0,4,{sp:.018}),mkS('sm',20,.1,30,1.4,'smg',1,1.0,3,{sp:.018}),mkS('sm',15,.065,50,1.9,'smg',1,1.05,2,{sp:.02}),mkS('sm',14,.055,33,1.5,'smg',1,.95,2,{sp:.022}),
 mkS('sg',11,.65,8,2.2,'shotgun',0,1.15,2.5,{pel:8,sp:.06}),
 mkS('sn',100,1.3,5,2.6,'sniper',0,1.3,.8,{sp:.002}),mkS('sn',62,.45,10,2.2,'sniper',0,1.3,2,{sp:.004}),mkS('sn',80,1.1,5,2.4,'sniper',0,1.35,3,{sp:.002}),mkS('sn',90,.8,8,3,'sniper',0,1.35,.8,{sp:.003}),
 mkS('ar',26,.1,35,1.5,'rifle',1,1.15,.4),
 mkS('pi',45,.35,7,1.5,'pistol',0,1.5,2.5),mkS('pi',14,.06,20,1.2,'pistol',1,1.45,4,{sp:.02}),mkS('pi',22,.2,12,1.2,'pistol',0,1.45,4),mkS('pi',70,.75,6,2,'pistol',0,1.5,2.5),mkS('pi',12,1.2,1,2.5,'pistol',0,1.5,1)];
WS.forEach((w,i)=>w.i=i);
const GEO=[];const geo=i=>GEO[i]||(GEO[i]=(()=>{const B=[],Gl=[];DEF[i]((...a)=>B.push([...a.slice(0,7),a[7]||0]),(...a)=>Gl.push([...a.slice(0,7),a[7]||0]));return{b:merge(B),g:Gl.length?merge(Gl):null}})());
const model=(i,k=1)=>{const d=geo(i),gr=new T.Group(),m=new T.Mesh(d.b,WM);gr.add(m);if(d.g){const q=new T.Mesh(d.g,WGM);gr.add(q)}gr.scale.setScalar(WS[i].sc*k);return gr};
// ---- como a arma fica na mão e nas costas
const holder=i=>{const w=new T.Group(),m=model(i);w.add(m);w.rotation.x=Math.PI/2;w.position.set(0,-.6,0);return w};
const backHold=(i,n)=>{const h=new T.Group();h.add(model(i,.85));
 if(WS[i].k=='pi'){h.rotation.set(0,Math.PI/2*(n?-1:1),0);h.position.set(n?-.17:.17,.03,-.15)}
 else{h.rotation.set(-Math.PI/2,0,n?-.55:.55,'ZYX');h.position.set(n?-.05:.05,.36,-.12-.02*n)}return h};
const dress=(g,hand,back)=>{const u=g.userData;if(!u.gun||!u.bk)return;const hk=hand==null?'-':hand,bk=back.join(',');
 if(u._hk!==hk){u._hk=hk;kids(u.gun);if(hand!=null)u.gun.add(holder(hand))}
 if(u._bk!==bk){u._bk=bk;kids(u.bk);back.forEach((id,n)=>u.bk.add(backHold(id,n)))}};
// ---- loot no chão
const NM={},CM={};
const label=i=>{if(NM[i])return NM[i];const w=WPN[i],cv=document.createElement('canvas');cv.width=320;cv.height=96;const x=cv.getContext('2d');
 x.fillStyle='rgba(6,8,18,.78)';x.fillRect(0,18,320,70);x.strokeStyle=w.c;x.lineWidth=4;x.strokeRect(2,20,316,66);
 x.textAlign='center';x.font='700 38px "Arial Narrow",Arial,sans-serif';x.fillStyle='#fff';x.shadowColor=w.c;x.shadowBlur=12;x.fillText(w.n,160,62);
 x.shadowBlur=0;x.font='700 17px Arial,sans-serif';x.fillStyle=w.c;x.fillText(w.t.toUpperCase()+' · '+w.r.toUpperCase(),160,82);
 const tx=new T.CanvasTexture(cv);return NM[i]=new T.SpriteMaterial({map:tx,transparent:true,depthWrite:false})};
const BEAM=new T.CylinderGeometry(.1,.16,3.2,8,1,true),RING=new T.RingGeometry(.55,.8,28);RING.rotateX(-Math.PI/2);
const cmat=c=>CM[c]||(CM[c]={beam:new T.MeshBasicMaterial({color:c,transparent:true,opacity:.3,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}),ring:new T.MeshBasicMaterial({color:c,transparent:true,opacity:.7,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide})});
let pkEl=null;
const L={inv:[null,null],am:[0,0],cur:2,held:false,gnd:[],near:null,lt:'',
 S:WS,
 w(){const id=L.cur<2?L.inv[L.cur]:null;return id==null?null:WS[id]},
 armed(){return L.w()!=null},
 name(){const w=L.w();return w?WPN[w.i].n:'Punho'},
 rt(){const w=L.w();return w?w.rl:1.1},
 cd(){const w=L.w();return w?w.cd:.5},
 scope(){const w=L.w();return !!w&&w.k!='pi'},
 zoom(){const w=L.w();return !w||w.k=='pi'?35:w.k=='sn'?12:26},
 ok(){const w=L.w();if(!w)return false;if(!w.auto){if(L.held)return false}L.held=true;return true},
 model,dress,
 addGround(id,x,z,cool,y){if(L.gnd.length>170)L.remove(L.gnd[0]);
  const g=new T.Group(),w=WPN[id],c=new T.Color(w.c).getHex(),cm=cmat(c),inner=new T.Group(),m=model(id,1.55);inner.add(m);inner.rotation.z=.25;
  const fl=new T.Group();fl.add(inner);g.add(fl);
  const beam=new T.Mesh(BEAM,cm.beam);beam.position.y=1.6;g.add(beam);const ring=new T.Mesh(RING,cm.ring);ring.position.y=.05;g.add(ring);
  const sp=new T.Sprite(label(id));sp.scale.set(2.3,.69,1);sp.position.y=2.1;g.add(sp);
  g.position.set(x,y||0,z);sc.add(g);const it={id,x,z,y:y||0,g,fl,sp,ring,ph:Math.random()*6,cool:cool||0};L.gnd.push(it);return it},
 remove(it){const i=L.gnd.indexOf(it);if(i>=0)L.gnd.splice(i,1);sc.remove(it.g)},
 clearGround(){L.gnd.forEach(it=>sc.remove(it.g));L.gnd=[];L.near=null;if(pkEl)pkEl.style.display='none'},
 pick(){let t=0,r=Math.random()*WS.reduce((a,w)=>a+w.w,0);for(let i=0;i<WS.length;i++){r-=WS[i].w;if(r<=0){t=i;break}}return t},
 scatter(n=110){L.clearGround();if(window.ISL&&ISL.on){ISL.loot();return}const lim=G.lim-8;for(let i=0;i<n;i++)for(let k=0;k<25;k++){const x=rr(lim),z=rr(lim);if(ICE.free(x,z,.6,.6,0)&&Math.hypot(x-P.x,z-P.z)>5){L.addGround(L.pick(),x,z);break}}},
 dropBot(e){if(G.m!='br'||e.wid==null)return;L.addGround(e.wid,e.x+rr(.8),e.z+rr(.8));if(e.bid!=null&&Math.random()<.6)L.addGround(e.bid,e.x+rr(1.6),e.z+rr(1.6))},
 // armas dos bots (mão + costas)
 kit(e){const nonPi=()=>{let id;do id=L.pick();while(WS[id].k=='pi');return id};const a=nonPi(),b=Math.random()<.5?[15,16,17,18][Math.random()*4|0]:nonPi();
  e.wid=a;e.bid=b;e.wk=WS[a].snd;dress(e.g,a,[b])},
 // inventário
 equip(i){if(L.cur<2)L.am[L.cur]=AM.n;L.cur=i;const w=L.w();AM.max=w?w.mag:0;AM.n=w?L.am[i]:0;AM.rl=0;AM.ui();L.ui()},
 sel(i){if(mode!='game'||i==L.cur)return;L.equip(i);beep(600,.04)},
 give(slot,id){L.inv[slot]=id;L.am[slot]=WS[id].mag},
 reset(){L.inv=[5,16];L.am=[WS[5].mag,WS[16].mag];L.cur=0;L.held=false;L.clearGround();L.equip0()},
 equip0(){const w=L.w();AM.max=w?w.mag:0;AM.n=w?L.am[L.cur]:0;AM.rl=0;AM.ui();L.ui()},
 start(m){L.clearGround();if(m=='br'){L.inv=[null,null];L.am=[0,0];L.cur=2;L.equip0();L.scatter()}else{L.reset()}},
 take(){const it=L.near;if(!it||mode!='game'||!PL.a)return;const s=L.cur<2?L.cur:0,old=L.inv[s];
  if(old!=null){const f=-P.yaw;L.addGround(old,P.x-Math.sin(P.yaw)*2.5,P.z-Math.cos(P.yaw)*2.5,1.2,P.y)}
  L.remove(it);L.give(s,it.id);L.near=null;if(pkEl)pkEl.style.display='none';L.equip(s);ICE.toast('Trocou por '+WPN[it.id].n,WPN[it.id].c);beep(800,.07)},
 ui(){const w=L.w(),k=L.cur+'|'+L.inv.join(',');
  if(k!=L.uk){L.uk=k;$('#wi').innerHTML=w?`<img src="${WPN[w.i].i}" style="border-color:${WPN[w.i].c};box-shadow:0 0 10px ${WPN[w.i].c}">`:'<b style="font-size:5vh">✊</b>';
   document.querySelectorAll('#sl2 button').forEach((b,j)=>{b.classList.toggle('on',j==L.cur);const id=j<2?L.inv[j]:null;
    b.innerHTML=j==2?'<span>∞</span><b class=fi>✊</b>':id==null?'<span>—</span>':`<span>0</span><img src="${WPN[id].i}" style="border-color:${WPN[id].c}">`})}
  document.querySelectorAll('#sl2 button').forEach((b,j)=>{const sp=b.querySelector('span');if(sp&&j<2&&L.inv[j]!=null)sp.textContent=j==L.cur?AM.n:L.am[j]})},
 tick(dt){const lob=mode!='game';
  if(lob||!G.on){}else{}
  const inGame=mode=='game',u=me.userData;
  if(inGame){const air=!!PL.air||(G.ph&&G.ph!='ground'),hand=PL.a&&!air?(L.cur<2?L.inv[L.cur]:null):null;
   const back=[];L.inv.forEach((id,s)=>{if(id!=null&&!(hand!=null&&s==L.cur))back.push(id)});dress(me,hand,back);u.bk.visible=true}
  if(!(G.on&&G.m=='br')){if(pkEl)pkEl.style.display='none';L.near=null;return}
  // brilho pulsando das armas
  WGM.color.setScalar(.8+.2*Math.sin(t*4));
  const canPick=PL.a&&(!G.ph||G.ph=='ground'),dim=9999;let best=null,bd=1.9;
  for(const it of L.gnd){const d=Math.hypot(it.x-P.x,it.z-P.z),v=d<80;if(it.g.visible!=v)it.g.visible=v;if(!v)continue;
   it.fl.rotation.y+=dt*1.5;it.fl.position.y=.95+Math.sin(t*2.2+it.ph)*.12;it.sp.visible=d<18;it.ring.rotation.y+=dt;it.ring.scale.setScalar(1+.08*Math.sin(t*3+it.ph));if(it.cool>0)it.cool-=dt;
   if(canPick&&it.cool<=0&&d<bd&&Math.abs(it.y-P.y)<2.5){bd=d;best=it}}
  if(!best){L.near=null;if(pkEl)pkEl.style.display='none';return}
  const s=L.inv[0]==null?0:L.inv[1]==null?1:-1;
  if(s>=0){L.remove(best);L.give(s,best.id);if(L.cur==2||L.inv[L.cur]==null)L.equip(s);else L.ui();ICE.toast('+ '+WPN[best.id].n,WPN[best.id].c);beep(900,.07);L.near=null;if(pkEl)pkEl.style.display='none'}
  else{L.near=best;const k=best.id+'|'+L.cur;if(pkEl&&L.lt!=k){L.lt=k;pkEl.innerHTML=`<img src="${WPN[best.id].i}"><span>PEGAR<b>${WPN[best.id].n}</b></span><em>E</em>`;pkEl.style.setProperty('--c',WPN[best.id].c)}if(pkEl)pkEl.style.display='flex'}}};
// elementos de interface
document.head.insertAdjacentHTML('beforeend',`<style>
#wpk{--c:#fff;position:absolute;left:50%;bottom:calc(26% + env(safe-area-inset-bottom));transform:translateX(-50%);display:none;align-items:center;gap:10px;padding:5px 12px 5px 5px;background:rgba(8,10,22,.9);border:2px solid var(--c);box-shadow:0 0 16px var(--c);color:#fff;font:700 clamp(15px,3.6vh,22px) var(--f);pointer-events:auto;z-index:9;animation:wpkp 1.2s ease-in-out infinite}
#wpk img{height:clamp(34px,8vh,52px);width:auto;border:1px solid var(--c)}#wpk span{display:flex;flex-direction:column;line-height:1;text-align:left;font-size:.7em;letter-spacing:1px;opacity:.9}#wpk b{font-size:1.45em;color:var(--c);text-shadow:0 0 8px var(--c)}
#wpk em{font-style:normal;border:2px solid #fff;border-radius:4px;padding:0 8px;font-size:1em;background:rgba(255,255,255,.12)}
@keyframes wpkp{50%{box-shadow:0 0 6px var(--c)}}
#wi img{width:100%;height:100%;object-fit:cover;border:2px solid #fff}#sl2 button img{position:absolute;inset:3px;width:calc(100% - 6px);height:calc(100% - 6px);object-fit:cover;border:1px solid #fff;opacity:.9}
#sl2 button span{z-index:1;text-shadow:0 0 4px #000,0 0 4px #000}#sl2 button .fi{position:absolute;left:0;right:0;top:12%;font-size:4.5vh}
</style>`);
{const h=document.getElementById('hud');if(h){h.insertAdjacentHTML('beforeend','<button id=wpk></button>');pkEl=document.getElementById('wpk');pkEl.addEventListener('pointerdown',e=>{e.stopPropagation();L.take()})}}
addEventListener('keydown',e=>{if(mode=='game'&&e.key.toLowerCase()=='e')L.take()});
addEventListener('pointerup',()=>{});
return L})();
// ====================== GLADIADORES: arena, quadrado vermelho, loja de armas (10 s) ======================
const GLD=(()=>{
const A=new T.Group();A.visible=false;sc.add(A);
const price={Comum:300,Rara:1200,'Épica':2200,'Lendária':3300,'Mítica':4000,Especial:100},PR=i=>price[WPN[i].r]||1000,CASH=5000;
const wallS=[],arenaS=[],S0=22,H=6,WALL=new T.MeshBasicMaterial({color:0xff2a2a,transparent:true,opacity:.26,side:T.DoubleSide,depthWrite:false}),EDGE=new T.LineBasicMaterial({color:0xff7a7a});
const SQ=new T.Group();A.add(SQ);
let built=false,sel=0,money=CASH,cartEl,panel,timerEl;
const build=()=>{if(built)return;built=true;
 const fl=new T.Mesh(new T.PlaneGeometry(76,76),M(0x6b6f79));fl.rotation.x=-Math.PI/2;fl.receiveShadow=true;A.add(fl);
 for(let i=-3;i<=3;i++){for(const[w,d,x,z]of[[.25,70,i*10,0],[70,.25,0,i*10]]){const l=new T.Mesh(new T.PlaneGeometry(w,d),M(0x4e525c));l.rotation.x=-Math.PI/2;l.position.set(x,.02,z);A.add(l)}}
 const wall=(x,z,w,d,h,c)=>{const b=mk(w,h,d,c);b.position.set(x,h/2,z);A.add(b);arenaS.push({x,z,hw:w/2,hd:d/2,h})};
 // paredes externas + containers de cobertura
 [[0,33,70,2,5,0x2a2f3a],[0,-33,70,2,5,0x2a2f3a],[33,0,2,70,5,0x2a2f3a],[-33,0,2,70,5,0x2a2f3a]].forEach(a=>wall(...a));
 [[-13,2,9,3,3,0xd04a3a],[13,-2,9,3,3,0x3a7ad0],[0,0,3,9,3,0xe0b040],[-20,-9,3,8,3,0x3a9a5a],[20,9,3,8,3,0x9a4aa0],[-7,10,3,3,1.6,0xb08040],[7,-10,3,3,1.6,0xb08040],[-24,10,4,4,2.2,0x8a8f99],[24,-10,4,4,2.2,0x8a8f99]].forEach(a=>wall(...a));
 // quadrados vermelhos (um para cada jogador)
 for(const cz of[S0,-S0]){const fl2=new T.Mesh(new T.PlaneGeometry(12,12),new T.MeshBasicMaterial({color:0xff2a2a,transparent:true,opacity:.35,depthWrite:false}));fl2.rotation.x=-Math.PI/2;fl2.position.set(0,.05,cz);SQ.add(fl2);
  for(const[x,z,w,d]of[[-6,cz,.2,12],[6,cz,.2,12],[0,cz-6,12,.2],[0,cz+6,12,.2]]){const g=new T.BoxGeometry(w,3.6,d),m=new T.Mesh(g,WALL);m.position.set(x,1.8,z);SQ.add(m);const e=new T.LineSegments(new T.EdgesGeometry(g),EDGE);e.position.copy(m.position);SQ.add(e)}}
 document.head.insertAdjacentHTML('beforeend',`<style>
#glt{position:absolute;left:50%;top:calc(max(10px,env(safe-area-inset-top)) + 4px);transform:translateX(-50%);display:none;padding:2px 22px;background:rgba(120,10,16,.88);border:2px solid #ff6a6a;box-shadow:0 0 14px #ff2a2a;font:700 clamp(16px,4.2vh,26px) var(--f);color:#fff;letter-spacing:1px;pointer-events:none;z-index:10;white-space:nowrap}#glt b{font-size:1.3em;color:#ffd24a;margin-left:6px}
#gls{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(92vw,620px);max-height:78vh;display:none;flex-direction:column;background:rgba(8,10,18,.94);border:2px solid #6a6f7c;pointer-events:auto;z-index:11;color:#fff;font:700 clamp(10px,2.5vh,14px) var(--f)}
#gls .gh{display:flex;align-items:center;justify-content:center;position:relative;padding:3px 10px;border-bottom:1px solid #444}#gls .gh b{font-size:1.2em;letter-spacing:2px}
#gls .gm{position:absolute;left:10px;font-style:normal;color:#ffd24a}#gls #gx{position:absolute;right:6px;top:0;background:none;border:0;color:#ff6a3a;font-size:2em;line-height:1}
#gls .gt{padding:2px 10px;background:#1b1e29;border-bottom:1px solid #333;letter-spacing:1px}
#gls .gg{display:grid;grid-template-columns:repeat(6,1fr);gap:3px;padding:4px;overflow:auto;touch-action:pan-y;min-height:0;flex:1}
#gls .gc{--c:#888;position:relative;background:#22252f;border:2px solid #3d4150;padding:1px;cursor:pointer;display:flex;flex-direction:column;align-items:center;min-height:0}
#gls .gc img{width:100%;aspect-ratio:1.9/1;object-fit:cover;display:block}#gls .gc b{font-size:.7em;margin-top:1px;text-align:center;line-height:1.05;text-shadow:0 0 6px var(--c)}#gls .gc small{color:#ffd24a;font-size:.72em}
#gls .gc.on{border-color:#ffd24a;box-shadow:0 0 12px #ffd24a,inset 0 0 0 1px #ffd24a;background:#33311f}#gls .gc.ow::after{content:'✔';position:absolute;top:1px;right:4px;color:#58ff9a;font-size:1.2em}
#gls #gsel{align-self:flex-end;margin:4px 8px 6px;padding:1px 20px;background:#ffc233;color:#2a1c00;border:2px solid #fff3c4;font:700 1.1em var(--f);letter-spacing:1px}
#gcart{position:absolute;left:14%;top:46%;display:none;flex-direction:column;align-items:center;background:rgba(8,10,18,.8);border:2px solid #fff;color:#fff;font:700 clamp(11px,2.6vh,15px) var(--f);padding:3px 8px;pointer-events:auto;z-index:10}#gcart i{font-style:normal;font-size:2.4em;line-height:1}
</style>`);
 const h=document.getElementById('hud');
 h.insertAdjacentHTML('beforeend',`<div id=glt>FASE DE COMPRA<b id=gln>10</b></div><div id=gls><div class=gh><i class=gm>💰 <span id=gmo>${CASH}</span></i><b>LOJA</b><button id=gx>✕</button></div><div class=gt>ARMA</div><div class=gg id=ggr></div><button id=gsel>SELECIONAR</button></div><button id=gcart><i>🛒</i>COMPRAR</button>`);
 panel=document.getElementById('gls');cartEl=document.getElementById('gcart');timerEl=document.getElementById('gln');
 const gg=document.getElementById('ggr');
 gg.innerHTML=WPN.map((w,i)=>`<div class=gc data-i=${i} style="--c:${w.c}"><img src="${w.i}" alt=""><b>${w.n}</b><small>$${PR(i)}</small></div>`).join('');
 gg.addEventListener('click',e=>{const c=e.target.closest('.gc');if(!c)return;sel=+c.dataset.i;beep(600,.04);mark()});
 document.getElementById('gsel').onclick=buy;document.getElementById('gx').onclick=()=>{panel.style.display='none';cartEl.style.display=L2.lock()?'flex':'none'};
 cartEl.onclick=()=>{panel.style.display='flex';cartEl.style.display='none'};
 panel.addEventListener('pointerdown',e=>e.stopPropagation());cartEl.addEventListener('pointerdown',e=>e.stopPropagation())};
const mark=()=>{if(!panel)return;document.getElementById('gmo').textContent=money;panel.querySelectorAll('.gc').forEach(c=>{const i=+c.dataset.i;c.classList.toggle('on',i==sel);c.classList.toggle('ow',WLD.inv.includes(i))})};
const buy=()=>{if(!L2.lock())return;const p=PR(sel);if(WLD.inv.includes(sel))return ICE.deny('Você já tem essa arma');if(money<p)return ICE.deny('Dinheiro insuficiente');
 money-=p;const slot=WLD.S[sel].k=='pi'?1:0;WLD.give(slot,sel);WLD.equip(slot);ICE.toast('Comprou '+WPN[sel].n,WPN[sel].c);beep(900,.08);mark()};
const setWalls=on=>{while(wallS.length){const i=solids.indexOf(wallS.pop());if(i>=0)solids.splice(i,1)}
 if(on)for(const cz of[S0,-S0])for(const[x,z,hw,hd]of[[-6.1,cz,.15,6.15],[6.1,cz,.15,6.15],[0,cz-6.1,6.15,.15],[0,cz+6.1,6.15,.15]]){const s={x,z,hw,hd,h:H};wallS.push(s);solids.push(s)}
 SQ.visible=on};
const L2={on:0,gls:0,nt:0,sv:null,tv:null,lock(){return L2.gls>0},
 enter(){build();if(L2.on)return;L2.on=1;L2.sv=solids.splice(0);L2.tv=trees.splice(0);solids.push(...arenaS);W.visible=false;A.visible=true;G.lim=30},
 exit(){if(!L2.on)return;L2.on=0;setWalls(false);solids.splice(0);solids.push(...L2.sv);trees.splice(0);trees.push(...L2.tv);W.visible=true;A.visible=false;G.lim=70;L2.gls=0;L2.nt=0;
  if(panel){panel.style.display='none';cartEl.style.display='none';document.getElementById('glt').style.display='none'}},
 round(){const e=G.e[0];L2.nt=0;PL.hp=100;PL.a=1;G.dead=0;PL.air=0;me.visible=true;P.x=0;P.z=S0;P.y=0;P.vy=0;P.yaw=0;P.face=Math.PI;P.cr=P.pr=P.run=false;document.querySelectorAll('#hud .act.on').forEach(b=>b.classList.remove('on'));
  if(e){e.hp=100;e.a=1;e.x=0;e.z=-S0;e.fy=0;e.cd=1.5+Math.random();e.g.visible=true;e.g.position.set(0,0,-S0);e.g.rotation.y=0;e.g.userData.d0=0;WLD.kit(e)}
  WLD.inv=[null,16];WLD.am=[0,WLD.S[16].mag];WLD.cur=1;WLD.held=false;WLD.equip0();money=CASH;sel=0;
  setWalls(true);L2.gls=10;build();mark();panel.style.display='flex';cartEl.style.display='none';document.getElementById('glt').style.display='block';ICE.toast('Compre sua arma!','#ffd24a')},
 next(){L2.nt=2.5},
 tick(dt){if(!L2.on||!G.on)return;
  if(L2.nt>0&&(L2.nt-=dt)<=0)L2.round();
  if(L2.gls>0){L2.gls-=dt;timerEl.textContent=Math.max(0,Math.ceil(L2.gls));if(L2.gls<=0){L2.gls=0;setWalls(false);panel.style.display='none';cartEl.style.display='none';document.getElementById('glt').style.display='none';ICE.toast('LUTEM!','#ff4d5e');beep(300,.2)}}}};
return L2})();
// ====================== ILHA VIOXAR: mapa 3D explorável do Battle Royale (8 regiões) ======================
const ISL=window.ISL=(()=>{
const FH0=4,TS=4,NT=70,OR=-140,TH=.5;
let sd=20261123;const rn=()=>(sd=(sd*16807)%2147483647)/2147483647,rb=(a,b)=>a+rn()*(b-a),pk=a=>a[rn()*a.length|0];
const SL=[],GR=new Map(),DR=[],LOOT=[],TRS=[],ROADS=[],WAT=[],ISD=[],PIER=[],PIT=[],BRG=[],XL=[],ITM=[],ACC=new Map(),CHK=[],TCOL=[],TILEY=[];
let built=false,on=0,LM=null,grp=null,mc=null,lastReg=null,tk=0;
const arm={vest:0,helm:0},KEEP=[],BL=[];
const inR=(r,x,z)=>x>=r[0]&&x<=r[2]&&z>=r[1]&&z<=r[3],rc=(cx,cz,w,d)=>[cx-w/2,cz-d/2,cx+w/2,cz+d/2];
// ---------- colisão: grade de células de 8 m (só a ilha; paredes dinâmicas continuam em `solids`) ----------
const cl=v=>Math.floor((v+160)/8);
const gadd=s=>{const m=.45,x0=cl(s.x-s.hw-m),x1=cl(s.x+s.hw+m),z0=cl(s.z-s.hd-m),z1=cl(s.z+s.hd+m);for(let i=x0;i<=x1;i++)for(let j=z0;j<=z1;j++){const k=i*100+j;let a=GR.get(k);if(!a)GR.set(k,a=[]);a.push(s)}};
const sol=(x0,z0,x1,z1,y0,y1,f)=>{const s={x:(x0+x1)/2,z:(z0+z1)/2,hw:(x1-x0)/2,hd:(z1-z0)/2,y0,h:y1};if(f)Object.assign(s,f);SL.push(s);gadd(s);return s};
const near=(x,z,fn)=>{const a=GR.get(cl(x)*100+cl(z));if(a)for(let i=0;i<a.length;i++)fn(a[i])};
// ---------- geometria: caixas mescladas por pedaço de 36 m (camada A = estrutura, camada D = detalhe) ----------
const ac=(x,z,d)=>{const cx=Math.floor((x+144)/36),cz=Math.floor((z+144)/36),k=cx*100+cz+(d?.5:0);let a=ACC.get(k);if(!a)ACC.set(k,a={p:[],n:[],c:[],i:[],d:!!d,cx,cz});return a};
const rgb=h=>[(h>>16&255)/255,(h>>8&255)/255,(h&255)/255];
const qd=(a,v,n,c,sh)=>{const o=a.p.length/3;for(let k=0;k<4;k++){a.p.push(v[k*3],v[k*3+1],v[k*3+2]);a.n.push(n[0],n[1],n[2]);a.c.push(c[0]*sh,c[1]*sh,c[2]*sh)}a.i.push(o,o+1,o+2,o,o+2,o+3)};
const vb=(x0,y0,z0,x1,y1,z1,col,d)=>{const a=ac((x0+x1)/2,(z0+z1)/2,d),j=.94+rn()*.12,c=rgb(col).map(v=>Math.min(1,v*j));
 qd(a,[x0,y1,z1,x1,y1,z1,x1,y1,z0,x0,y1,z0],[0,1,0],c,1);
 qd(a,[x1,y0,z1,x1,y0,z0,x1,y1,z0,x1,y1,z1],[1,0,0],c,.86);
 qd(a,[x0,y0,z0,x0,y0,z1,x0,y1,z1,x0,y1,z0],[-1,0,0],c,.86);
 qd(a,[x0,y0,z1,x1,y0,z1,x1,y1,z1,x0,y1,z1],[0,0,1],c,.93);
 qd(a,[x1,y0,z0,x0,y0,z0,x0,y1,z0,x1,y1,z0],[0,0,-1],c,.93);
 if(y0>.05||y0<-.05)qd(a,[x0,y0,z0,x1,y0,z0,x1,y0,z1,x0,y0,z1],[0,-1,0],c,.6)};
const top=(x0,z0,x1,z1,y,col)=>{const a=ac((x0+x1)/2,(z0+z1)/2,0),j=.93+rn()*.14,c=rgb(col).map(v=>Math.min(1,v*j));qd(a,[x0,y,z1,x1,y,z1,x1,y,z0,x0,y,z0],[0,1,0],c,1)};
const B=(x0,y0,z0,x1,y1,z1,col,s,dt)=>{vb(x0,y0,z0,x1,y1,z1,col,dt);if(s)return sol(x0,z0,x1,z1,y0,y1)};
const bx=(cx,cz,w,d,y0,h,col,s,dt)=>B(cx-w/2,y0,cz-d/2,cx+w/2,y0+h,cz+d/2,col,s,dt);
// ---------- mundo: estradas, água, regiões ----------
const road=(cx,cz,w,d)=>ROADS.push(rc(cx,cz,w,d)),isRoad=(x,z)=>ROADS.some(r=>inR(r,x,z));
const inBrg=(x,z)=>BRG.some(r=>inR(r,x,z));
const isWat=(x,z)=>!inBrg(x,z)&&WAT.some(r=>inR(r,x,z))&&!ISD.some(r=>inR(r,x,z));
const base=(x,z)=>{for(const r of PIT)if(inR(r,x,z))return-4;return isWat(x,z)?-.3:0};
const RG=[['TORRE DE COMUNICAÇÃO',[48,-124,86,-78],'#ffd24a'],['MONTANHA GELADA',[-44,-132,44,-60],'#9fe3ff'],['BASE MILITAR',[-92,-100,-48,-56],'#8fd16a'],['ZONA INDUSTRIAL',[60,-48,118,14],'#ff6a5a'],['FAZENDA',[-118,-54,-62,4],'#ffb84d'],['PORTO',[-112,34,-50,90],'#6aa9ff'],['LAGO AZUL',[-42,62,42,112],'#5ad1ff'],['DESERTO QUENTE',[48,24,118,92],'#ffcf6a'],['CIDADE CENTRAL',[-53,-60,53,46],'#c79bff']];
const regionAt=(x,z)=>{for(const r of RG)if(inR(r[1],x,z))return r;return null};
const R0=a=>100+8*Math.sin(3*a)+5*Math.sin(5*a+1);
const land0=(x,z)=>{const r=Math.hypot(x,z);if(r>137)return false;if(r<R0(Math.atan2(z,x)))return true;for(const g of RG)if(inR(g[1],x,z))return true;return false};
const land=(x,z)=>{const i=Math.floor((x-OR)/TS),j=Math.floor((z-OR)/TS);return i>=0&&j>=0&&i<NT&&j<NT&&LM[i][j]};
const solidAt=(x,z,r)=>{let b=false;near(x,z,s=>{if(!b&&s.y0<=.6&&s.h>.3&&Math.abs(x-s.x)<s.hw+r&&Math.abs(z-s.z)<s.hd+r)b=true});return b};
const inPit=(x,z)=>PIT.some(r=>inR(r,x,z)),inPitM=(x,z)=>PIT.some(r=>inR([r[0]-3,r[1]-3,r[2]+3,r[3]+3],x,z));
const freeAt=(x,z,r)=>land(x,z)&&!isRoad(x,z)&&!isWat(x,z)&&!inPitM(x,z)&&!KEEP.some(q=>inR(q,x,z))&&!solidAt(x,z,r);
// ---------- construção: prédios com portas, janelas, andares, escadas, quartos e telhado ----------
const bld=o=>{
 const x=o.x,z=o.z,w=o.w,d=o.d,f=o.f||1,fh=o.fh||FH0,gy=o.y||0,c=o.c||0xd9d2c0,tc=o.tc||0x5b606b,fc=o.fc||0xb9ab92,fr=o.fr||'s',ruin=o.ruin,
  flat=o.flat!==undefined?o.flat:f>1,stair=f>1,part=o.part!==undefined?o.part:(d>=14&&w>=12),shop=o.shop,pc=o.pc||0x8b3a2a;
 const x0=x-w/2,x1=x+w/2,z0=z-d/2,z1=z+d/2,hasDoor=o.door!==0;
 const wall=(ax,cc,a,b,ya,yb,col,gaps)=>{const seg=(u0,u1,y0,y1)=>{if(u1-u0<.05||y1-y0<.05)return;ax=='x'?B(u0,y0,cc-TH/2,u1,y1,cc+TH/2,col,1):B(cc-TH/2,y0,u0,cc+TH/2,y1,u1,col,1)};
  let p=a;for(const g of(gaps||[]).sort((m,n)=>m[0]-n[0])){seg(p,g[0],ya,yb);seg(g[0],g[1],ya+3,yb);p=g[1]}seg(p,b,ya,yb)};
 const run=4.8,xl=x0+TH+.3,zs=z0+TH+.3,CW=2,col=[xl,xl+CW+.3];
 const slab=(y0,y1,hole,cc)=>{if(!hole){B(x0,y0,z0,x1,y1,z1,cc,1);return}const[h0,h1,h2,h3]=hole;B(x0,y0,z0,h0,y1,z1,cc,1);B(h2,y0,z0,x1,y1,z1,cc,1);B(h0,y0,z0,h2,y1,h1,cc,1);B(h0,y0,h3,h2,y1,z1,cc,1)};
 const dd=[];BL.push({x,z,w,d,f,fr,flat,ruin,gy,fh,stair,part,x0,z0,x1,z1,zs,run,col,CW});
 vb(x0+TH,gy,z0+TH,x1-TH,gy+.04,z1-TH,fc,0);
 for(let k=0;k<f;k++){
  const yb=gy+k*fh,yt=yb+fh,last=k==f-1,rt=ruin&&last?yb+fh*rb(.55,.95):yt;
  const sides=[['x',z1-TH/2,x0,x1,'s'],['x',z0+TH/2,x0,x1,'n'],['z',x0+TH/2,z0+TH,z1-TH,'w'],['z',x1-TH/2,z0+TH,z1-TH,'e']];
  for(const[ax,cc,a,b,sdn]of sides){
   const dr=k==0&&hasDoor&&(sdn==fr||(o.d2&&((fr=='s'&&sdn=='n')||(fr=='n'&&sdn=='s'))));
   wall(ax,cc,a,b,yb,rt,c,dr?[[x-1.3,x+1.3]]:[]);
   if(dr)dd.push([cc,sdn]);
   if(o.win===0)continue;
   const ww=shop&&k==0&&sdn==fr?3:1.4,y0=shop&&k==0&&sdn==fr?yb+.6:yb+1.1,y1=shop&&k==0&&sdn==fr?yb+2.6:yb+2.7,sp=shop&&k==0&&sdn==fr?5:3.8;
   for(let u=a+2.2;u<b-1.6;u+=sp){if(dr&&Math.abs(u-x)<2.4)continue;if(y1>rt)continue;const g=0x78c2e6;
    if(sdn=='s')vb(u-ww/2,y0,z1,u+ww/2,y1,z1+.08,g,1);else if(sdn=='n')vb(u-ww/2,y0,z0-.08,u+ww/2,y1,z0,g,1);else if(sdn=='w')vb(x0-.08,y0,u-ww/2,x0,y1,u+ww/2,g,1);else vb(x1,y0,u-ww/2,x1+.08,y1,u+ww/2,g,1)}}
  if(part&&!ruin){const pz=z0+d*.55;wall('x',pz,x0+TH,x1-TH,yb,yt-.4,0xcfc6b4,[[x-1.2,x+1.2]])}
  if(!ruin||!last){
   const up=stair&&(k<f-1||flat);
   if(last&&flat){slab(yt-.4,yt,up?[col[k%2]-.05,zs-.05,col[k%2]+CW+.05,zs+run+.05]:0,tc);
    B(x0-.2,yt,z0-.2,x1+.2,yt+.25,z1+.2,tc,0,1);
    const pw=.3,ph=.9;B(x0,yt,z0,x1,yt+ph,z0+pw,tc,1);B(x0,yt,z1-pw,x1,yt+ph,z1,tc,1);B(x0,yt,z0+pw,x0+pw,yt+ph,z1-pw,tc,1);B(x1-pw,yt,z0+pw,x1,yt+ph,z1-pw,tc,1);
    if(f>1)LOOT.push({x:rb(x0+4,x1-3),z:rb(z0+Math.min(6.5,d-3),z1-1.5),y:yt+.03,ch:1});
    B(x1-4,yt,z0+2,x1-2,yt+1.2,z0+3.6,0x9aa0a8,1,1)}
   else if(last){slab(yt-.4,yt,0,tc);
    const n=3,ins=Math.min(1.6,(Math.min(w,d)/2-1)/n);for(let l=0;l<n;l++)B(x0+l*ins-.3,yt+l*1.1,z0+l*ins-.3,x1-l*ins+.3,yt+(l+1)*1.1,z1-l*ins+.3,pc,1)}
   else slab(yt-.4,yt,up?[col[k%2]-.05,zs-.05,col[k%2]+CW+.05,zs+run+.05]:0,fc)}
  if(stair&&(k<f-1||(flat&&!ruin))){const cx0=col[k%2],upz=k%2==0;for(let i=1;i<=8;i++){const za=upz?zs+(i-1)*.6:zs+run-i*.6;B(cx0,yb,za,cx0+CW,yb+.5*i,za+.6,0x9a8f7d,1)}}
  // móveis e pontos de loot do andar
  if(!(ruin&&last&&false)){const fz=part?z0+d*.55+1.6:(stair?zs+run+1.2:z0+TH+1.2),bz=z1-TH-1.2;
   B(x0+TH+1,yb,z1-TH-2.8,x0+TH+3.2,yb+.9,z1-TH-1.6,0x7a5a3a,1,1);
   if(w>=12)B(x1-TH-3.4,yb,z1-TH-2.2,x1-TH-1,yb+1.1,z1-TH-1.2,0x8a6a4a,1,1);
   LOOT.push({x:rb(x0+3,x1-3),z:rb(Math.min(fz,bz-1),bz),y:yb+.03,ch:k==f-1&&f>1?0:rn()<.3});
   if(w>=12&&d>=12)LOOT.push({x:rb(xl+5.5,x1-2),z:rb(z0+TH+1,z0+TH+3.5),y:yb+.03,ch:0})}
 }
 // portas que abrem sozinhas
 for(const[cc,sdn]of dd){const g=new T.Group(),m=new T.Mesh(new T.BoxGeometry(2.5,3,.18),new T.MeshLambertMaterial({color:o.dc||0x6b4a2b}));m.geometry.translate(1.25,1.5,0);g.add(m);g.position.set(x-1.25,gy,cc);g.visible=false;
  const s=sol(x-1.3,cc-.2,x+1.3,cc+.2,gy,gy+3,{door:1});DR.push({g,s,cx:x,cz:cc,gy,sg:sdn=='s'?1:-1,t:0});KEEP.push([x-3.2,cc-5,x+3.2,cc+5])}
 return{x0,x1,z0,z1}
};
// ---------- peças prontas ----------
const car=(x,z,ax,cl_)=>{const w=ax=='x'?4.2:1.9,d=ax=='x'?1.9:4.2;bx(x,z,w,d,.35,.85,cl_,1);bx(x,z,ax=='x'?2.2:1.7,ax=='x'?1.7:2.2,1.2,.7,0x9ccbe0,0,1);for(const a of[-1,1])for(const b of[-1,1])bx(x+(ax=='x'?a*1.3:b*.9),z+(ax=='x'?b*.9:a*1.3),.7,.7,0,.7,0x1a1a1f,0,1)};
const lamp=(x,z)=>{bx(x,z,.3,.3,0,4.6,0x3a3f48,0,1);bx(x,z,.9,.5,4.6,.3,0xfff1b0,0,1)};
const cont=(x,z,ax,cl_,lv)=>{const w=ax=='x'?6:2.5,d=ax=='x'?2.5:6;bx(x,z,w,d,lv*2.6,2.55,cl_,1)};
const fence=(x0,z0,x1,z1,gate,col,h)=>{const t=.6,hh=h||3.2;
 B(x0,0,z0,x1,hh,z0+t,col,1);B(x0,0,z1-t,x1,hh,z1,col,1);B(x0,0,z0+t,x0+t,hh,z1-t,col,1);B(x1-t,0,z0+t,x1,hh,z1-t,col,1)};
const fenceG=(x0,z0,x1,z1,gx0,gx1,col,h)=>{const t=.6,hh=h||3.2;B(x0,0,z0,x1,hh,z0+t,col,1);B(x0,0,z1-t,gx0,hh,z1,col,1);B(gx1,0,z1-t,x1,hh,z1,col,1);B(x0,0,z0+t,x0+t,hh,z1-t,col,1);B(x1-t,0,z0+t,x1,hh,z1-t,col,1)};
const tree=(x,z,type,y)=>{y=y||0;TRS.push({x,z,y,t:type,s:.85+rn()*.5,g:pk([0x3f8f3a,0x4a9a3f,0x357d33,0x58a845])});sol(x-.45,z-.45,x+.45,z+.45,y,y+3.2)};
const cactus=(x,z)=>{const g=0x3f8a3a;B(x-.5,0,z-.5,x+.5,3.6,z+.5,g,1);B(x+.5,1.3,z-.35,x+1.6,2.0,z+.35,g,0,1);B(x+1.0,2.0,z-.35,x+1.6,3.0,z+.35,g,0,1);B(x-1.6,1.8,z-.35,x-.5,2.5,z+.35,g,0,1);B(x-1.6,2.5,z-.35,x-1.0,3.3,z+.35,g,0,1)};
const rock=(x,z,s,cc)=>{const w=s*rb(1,1.6),d=s*rb(1,1.6),h=s*rb(.7,1.3);B(x-w/2,0,z-d/2,x+w/2,h,z+d/2,cc,1);if(s>2)B(x-w/4,h,z-d/4,x+w/4,h+s*.5,z+d/4,cc,1)};
const bridge=(cx,cz,len,wd)=>{const r=[cx-len/2,cz-wd/2,cx+len/2,cz+wd/2];BRG.push(r);B(r[0],-.3,r[1],r[2],.35,r[3],0x8a6a45,1);B(r[0],.35,r[1],r[2],1.2,r[1]+.25,0x6b4a2b,1);B(r[0],.35,r[3]-.25,r[2],1.2,r[3],0x6b4a2b,1)};
const stairsX=(x,z,dirx,y0,n,wd,col)=>{for(let i=1;i<=n;i++){const a=x+dirx*(i-1)*.7,b=x+dirx*i*.7;B(Math.min(a,b),y0,z-wd/2,Math.max(a,b),y0+.5*i,z+wd/2,col||0x9a9488,1)}};
const stairsZ=(x,z,dirz,y0,n,wd,col)=>{for(let i=1;i<=n;i++){const a=z+dirz*(i-1)*.7,b=z+dirz*i*.7;B(x-wd/2,y0,Math.min(a,b),x+wd/2,y0+.5*i,Math.max(a,b),col||0x9a9488,1)}};
const ptower=(x,z)=>{const sx=x<-70?-1:1,dz=z<-78?-1:1;const y=8;for(const a of[-2.4,2.4])for(const b of[-2.4,2.4])B(x+a-.4,0,z+b-.4,x+a+.4,y,z+b+.4,0x5a4a3a,1);
 B(x-3,y-.4,z-3,x+3,y,z+3,0x6b5a46,1);const ph=1;B(x-3,y,z-3,x+3,y+ph,z-2.7,0x6b5a46,1);B(x-3,y,z+2.7,x+3,y+ph,z+3,0x6b5a46,1);B(x-3,y,z-2.7,x-2.7,y+ph,z+2.7,0x6b5a46,1);
 B(x-3.5,y+2.8,z-3.5,x+3.5,y+3.2,z+3.5,0x40382d,0,1);for(const a of[-3,3])for(const b of[-3,3])B(x+a-.15,y,z+b-.15,x+a+.15,y+2.8,z+b+.15,0x40382d,0,1);
 stairsZ(x+sx*4.2,z-dz*12,dz,0,16,2,0x7a6a55);LOOT.push({x,z,y:y+.03,ch:1})};
// ---------- REGIÃO 1: CIDADE CENTRAL ----------
const city=()=>{
 const pal=[0xd9d2c0,0xb9c6d6,0xe2b9a0,0xa9b8a0,0xc9a9b8,0x9fb2c8,0xe0d08a];
 const L=[[-31.5,-39,4,19,19,'s',0],[0,-39,6,15,15,'s',0x8fa6bd],[31.5,-39,4,19,19,'s',0],[-31.5,-8,2,19,19,'s',-1],[31.5,-8,3,19,19,'s',-2],[-31.5,23,3,19,19,'n',0],[0,23,2,19,19,'n',-1],[31.5,23,2,19,19,'n',-1]];
 for(const[x,z,f,w,d,fr,k]of L){bld({x,z,f,w,d,fr,c:k>0?k:pk(pal),shop:k==-1,tc:k>0?0x3f4a5c:0x5b606b,win:1});
  if(k==-2){const y=f*FH0+1,cx=x;vb(cx-1,y,z+d/2-.2,cx+1,y+3,z+d/2+.1,0xe03030,1);vb(cx-2,y+1,z+d/2-.2,cx+2,y+2,z+d/2+.1,0xe03030,1);vb(x-5,FH0*1.5,z+d/2,x+5,FH0*1.5+1.2,z+d/2+.12,0xffffff,1)}}
 // praça central com chafariz quadrado
 bx(0,-8,10,10,0,.6,0xbfc5cc,1);vb(-4.4,.6,-12.4,4.4,.62,-3.6,0x4fa8e8,0);bx(0,-8,1.4,1.4,.6,2.6,0xdfe3ea,1);bx(0,-8,3,3,3.2,.4,0xbfc5cc,0,1);
 for(const[a,b]of[[-9,-8],[9,-8],[0,-17],[0,1]])bx(a,b,3,.8,0,.5,0x8a6a4a,1);
 for(const[a,b]of[[-8,-15],[8,-15],[-8,-1],[8,-1]]){tree(a,b,'oak')}
 for(let i=-45;i<=45;i+=15){lamp(i,-27.4);lamp(i,2.6);lamp(i,-18.6);lamp(i,11.4)}
 const cc=[0xd23c3c,0x3c6ed2,0xe0c030,0x3ca85a,0xeeeeee,0x222831];
 for(let i=0;i<16;i++){const ax=i%2?'x':'z';if(ax=='x')car(pk([-40,-30,-5,5,30,40]),pk([-23,7]),'x',pk(cc));else car(pk([-15.5,15.5]),pk([-45,-30,-8,15,28,35]),'z',pk(cc))}
 // posto de gasolina
 ROADS.push(rc(16,52,20,14));for(const a of[-6,6])for(const b of[-3,3])bx(14+a,52+b,.8,.8,0,4.4,0xdfe3ea,1);bx(14,52,15,8,4.4,.5,0xe8403a,1);
 for(const a of[-4,0,4])bx(14+a,52,.9,.7,0,1.3,0xe8e8f0,1);
 bld({x:31,z:52,w:10,d:9,f:1,fr:'s',c:0xe9e2d0,pc:0xe8403a,shop:1,part:false,win:1});
 for(const[a,b]of[[8,48],[22,56]])car(a,b,'x',pk(cc))};
// ---------- REGIÃO 2: BASE MILITAR (com bunker subterrâneo) ----------
const baseMil=()=>{
 const cn=0x9aa0a8;
 fenceG(-86,-96,-54,-60,-72,-64,0x7b8270,3.2);
 bld({x:-79,z:-88,w:10,d:14,f:1,fh:7,fr:'s',c:0x7a8068,pc:0x5f654f,win:0,dc:0x4a4f3f});
 bld({x:-77,z:-69,w:14,d:14,f:2,fr:'n',c:0x80876f,tc:0x5f654f,dc:0x4a4f3f});
 bld({x:-58,z:-65.5,w:8,d:10,f:2,fr:'n',c:0x6f7766,tc:0x5f654f,dc:0x4a4f3f});
 PIT.push([-70,-94,-56,-84],[-64,-84,-60,-74]);
 // trincheira de escada (desce 4 m)
 for(let i=1;i<=8;i++){const za=-74-(i-1)*1.25,zb=za-1.25;B(-64,-4,zb,-60,-.5*i,za,0x8a9098,1)}
 B(-64.6,-4,-84,-64,.7,-74,cn,1);B(-60,-4,-84,-59.4,.7,-74,cn,1);
 // salas do bunker
 vb(-70,-4.3,-94,-56,-4,-84,0x6b7078,0);
 B(-70.6,-4,-94.6,-69.9,-.5,-83.4,cn,1);B(-56.1,-4,-94.6,-55.4,-.5,-83.4,cn,1);B(-70,-4,-94.6,-56,-.5,-94,cn,1);
 B(-70,-4,-84.6,-65,-.5,-84,cn,1);B(-59,-4,-84.6,-56,-.5,-84,cn,1);
 B(-70,-.5,-94,-56,0,-84,0x7d838c,1);
 B(-70,-4,-90.3,-64.6,-.5,-89.8,0xb6bcc4,1);B(-61.6,-4,-90.3,-56,-.5,-89.8,0xb6bcc4,1);
 B(-63.3,-4,-94,-62.8,-.5,-90.3,0xb6bcc4,1);
 for(const[x,z]of[[-67,-92],[-59,-92],[-67,-86.5],[-58,-87],[-63,-92.5]])LOOT.push({x,z,y:-3.97,ch:1});
 for(const[x,z]of[[-86,-96],[-54,-96],[-86,-60],[-54,-60]])ptower(x,z);
 for(const[x,z,ax,k,l]of[[-57,-78,'z',0x5a6b46,0],[-72,-80,'z',0x5a6b46,0]])cont(x,z,ax,k,l);
 car(-68,-76,'z',0x4e5b40)};
// ---------- REGIÃO 3: MONTANHA GELADA ----------
const mont=()=>{
 const H=[30,25,20,15,10,5];H.forEach((h,i)=>B(-h,0,-92-h,h,1.2*(i+1),-92+h,i%2?0xdcecf7:0xf2f9fd,1));
 B(-1,7.2,-93,1,10,-91,0x7a5a3a,0,1);B(1,9,-93,3.5,10,-91.6,0xd23c3c,0,1);
 for(const[x,z]of[[-44,-78],[44,-78],[-36,-100],[36,-100]]){if(!land(x-7,z-7)||!land(x+7,z+7))continue;bld({x,z,w:12,d:12,f:1,fr:'s',c:0xbfd9ea,pc:0xeef6fb,part:false,win:1})}};
// ---------- REGIÃO 4: ZONA INDUSTRIAL ----------
const indus=()=>{
 bld({x:78,z:-34,w:20,d:16,f:2,fr:'s',c:0x8a6a5a,tc:0x4a4e57,dc:0x3a3f48});
 bld({x:102,z:-34,w:18,d:16,f:2,fr:'s',c:0x7a8088,tc:0x4a4e57,dc:0x3a3f48});
 bld({x:76,z:0,w:24,d:12,f:1,fh:6,fr:'n',c:0x9aa0a8,pc:0x5a606b,part:false,d2:1});
 bld({x:104,z:0,w:20,d:12,f:1,fh:6,fr:'n',c:0xa8625a,pc:0x5a606b,part:false,d2:1});
 const ct=(x,z)=>{[[12,0],[10.5,3.2],[9.5,6.4],[9,9.6],[9.5,12.8],[10.5,16]].forEach(([s,y])=>B(x-s/2,y,z-s/2,x+s/2,y+3.2,z+s/2,0xc9c4bb,1))};
 ct(70,-16);ct(112,-16);
 for(const x of[90,98]){B(x-1.5,0,-46+1.5-3,x+1.5,26,-43,0xc9402e,1);B(x-1.55,8,-48.1,x+1.55,10,-42.9,0xffffff,0,1);B(x-1.55,16,-48.1,x+1.55,18,-42.9,0xffffff,0,1)}
 const cc=[0xd23c3c,0x3c6ed2,0xe0a030,0x3ca85a,0xe0e0e0,0xa85a2a,0x7a3ca8];
 for(let i=0;i<14;i++){const x=rb(66,112),z=rb(-24,-12);if(!freeAt(x,z,3.2))continue;cont(x,z,rn()<.5?'x':'z',pk(cc),rn()<.3?1:0)}
 for(const x of[66,114]){for(const a of[-1.5,1.5]){B(x+a-.3,0,-6,x+a+.3,16,-5.4,0x8a8f99,1);B(x+a-.3,0,-4.6,x+a+.3,16,-4,0x8a8f99,1)}B(x-3,16,-6,x+3,16.4,-4,0x8a8f99,0,1)}
 for(const[x,z]of[[84,-18],[92,-12]])bx(x,z,3,3,0,2.4,0x8a8f99,1);
 lamp(70,-10);lamp(110,-10)};
// ---------- REGIÃO 5: DESERTO QUENTE ----------
const desert=()=>{
 const sa=0xc9a56a;
 B(88,0,30,100,7,35.5,0xb59061,1);B(88,0,42.5,100,7,50,0xb59061,1);B(88,4.6,35.5,100,7,42.5,0xa88655,1);
 for(const x of[89,99]){B(x-.4,0,35.2,x+.4,4.6,35.6,0x8a6a45,0,1)}
 [[0,0],[1,1]].forEach(([i,j])=>B(94-14+j*3,0,64-14+j*3,94+14-j*3,1.2*(i+1),64+14-j*3,i?0xd4b27a:0xc79c63,1));
 stairsX(80,64,1,0,2,6,0xb89060);
 for(const[x,z,w,d]of[[62,52,12,12],[70,78,12,12],[92,84,10,10],[62,70,10,10]]){if(!land(x-w/2,z-d/2)||!land(x+w/2,z+d/2))continue;bld({x,z,w,d,f:1,fr:rn()<.5?'s':'n',c:sa,ruin:1,part:false,win:1,pc:0x8a6a45})}
 bld({x:108,z:46,w:12,d:12,f:2,fr:'s',c:0xc4a165,tc:0x8a6a45,ruin:1,win:1,dc:0x6b4a2b});
 for(let i=0;i<46;i++){const x=rb(50,116),z=rb(26,90);if(freeAt(x,z,2.5)&&!inR([86,28,102,52],x,z))cactus(x,z)}
 for(let i=0;i<14;i++){const x=rb(50,116),z=rb(26,90);if(freeAt(x,z,3))rock(x,z,rb(1.5,3.2),pk([0xa9784a,0x8a6a4a,0x9a8a7a]))}};
// ---------- REGIÃO 6: PORTO ----------
const port=()=>{
 bld({x:-62,z:50,w:22,d:14,f:1,fh:6,fr:'n',c:0xa8625a,pc:0x4a4e57,part:false,d2:1});
 bld({x:-98,z:50,w:20,d:14,f:1,fh:6,fr:'n',c:0x7a8aa0,pc:0x4a4e57,part:false,d2:1});
 bld({x:-80,z:45,w:14,d:14,f:2,fr:'n',c:0xd9d2c0,tc:0x4a4e57,dc:0x3a3f48});
 const cc=[0xd23c3c,0x3c6ed2,0xe0a030,0x3ca85a,0xe0e0e0,0xa85a2a,0x7a3ca8,0x2a8a9a];
 for(let i=0;i<26;i++){const x=rb(-108,-62),z=rb(58,76);if(!freeAt(x,z,3.2))continue;cont(x,z,rn()<.5?'x':'z',pk(cc),rn()<.35?1:0)}
 const pr=(bx_,bz_)=>{let z=bz_;while(land0(bx_,z)&&z<150)z+=4;const e=z+22;PIER.push([bx_-4,bz_,bx_+4,e]);return{x:bx_,e}};
 const p1=pr(-70,72),p2=pr(-94,66);
 // navio atracado com rampa e cabine
 const sx=p1.x+4,sz=p1.e-20;XL.push([sx,sz-17,sx+10,sz+17]);
 B(sx,-1.4,sz-17,sx+10,.4,sz+17,0x7a1f1f,1);B(sx,.4,sz-17,sx+10,2.2,sz+17,0xdfe3ea,1);
 B(sx,2.2,sz-17,sx+10,3.1,sz-16.7,0xdfe3ea,1);B(sx,2.2,sz+16.7,sx+10,3.1,sz+17,0xdfe3ea,1);B(sx+9.7,2.2,sz-16.7,sx+10,3.1,sz+16.7,0xdfe3ea,1);B(sx,2.2,sz-16.7,sx+.3,3.1,sz-3,0xdfe3ea,1);B(sx,2.2,sz+0,sx+.3,3.1,sz+16.7,0xdfe3ea,1);
 bld({x:sx+5,z:sz-9,w:8,d:9,f:1,fr:'s',c:0xf0f0f4,pc:0xc9402e,part:false,y:2.2,win:1});
 bx(sx+5,sz+8,4,4,2.2,2,0xd23c3c,1);
 for(let i=1;i<=5;i++)B(p1.x+(i-1)*.8-.0,0,sz-2,p1.x+i*.8,.44*i,sz,0x9a9488,1);
 LOOT.push({x:sx+5,z:sz+13,y:2.23,ch:1});
 // guindastes
 for(const[x,z]of[[-86,80],[-76,66]]){for(const a of[-5,5])for(const b of[-3,3])B(x+a-.4,0,z+b-.4,x+a+.4,14,z+b+.4,0xe08a2a,1);B(x-6,14,z-4,x+6,15,z+4,0xe08a2a,0,1);B(x-1,14,z-14,x+1,15,z+4,0xe08a2a,0,1);B(x-.3,10,z-14,x+.3,14,z-13.6,0x444,0,1)}
 for(let i=0;i<6;i++){const x=rb(-108,-58),z=rb(38,48);if(freeAt(x,z,1))lamp(x,z)}};
// ---------- REGIÃO 7: FAZENDA ----------
const farm=()=>{
 bld({x:-100,z:-10,w:16,d:20,f:2,fr:'s',c:0xa83a2c,tc:0x6b2a20,flat:false,pc:0x6b2a20,dc:0x4a3020});
 bld({x:-78,z:-8,w:14,d:14,f:2,fr:'s',c:0xe9dfc9,tc:0x7a4a30,flat:false,pc:0x9a4a30,dc:0x6b4a2b});
 bld({x:-70,z:-34,w:12,d:12,f:1,fr:'s',c:0xc9b08a,pc:0x7a4a30,part:false});
 for(const x of[-92,-86]){B(x-2.5,0,-26.5,x+2.5,13,-21.5,0xc9ccd2,1);B(x-3,13,-27,x+3,14,-21,0x8a8f99,1,0);B(x-2,14,-26,x+2,15.2,-22,0x8a8f99,0,1)}
 // moinho de vento
 [[4,0],[3.4,3],[2.8,6],[2.2,9]].forEach(([s,y],i)=>B(-72-s/2,y,-46-s/2+0,-72+s/2,y+3,-46+s/2,0xe9dfc9,1));B(-72-.3,9.6,-47.2,-72+.3,12.6,-46.8,0x7a4a30,0,1);B(-77,10.5,-47.4,-67,10.9,-47,0xf2e6c8,0,1);B(-72.2,5.5,-47.4,-71.8,15.5,-47,0xf2e6c8,0,1);
 // cercas, feno e animais
 for(let x=-112;x<=-76;x+=3){B(x,0,-50.2,x+.3,1.2,-49.9,0x8a6a45,0,1);B(x,0,-19.8,x+.3,1.2,-19.5,0x8a6a45,0,1)}B(-112,.9,-50.3,-76,1.05,-50,0x8a6a45,0,1);B(-112,.9,-19.9,-76,1.05,-19.6,0x8a6a45,0,1);
 for(let i=0;i<8;i++){const x=rb(-96,-64),z=rb(-4,0);if(freeAt(x,z,1.5))bx(x,z,1.4,1.4,0,1.2,0xd8b94a,1)}
 const an=(x,z,cl_,sp)=>{bx(x,z,2*sp,.9*sp,.5*sp,.9*sp,cl_,0,1);bx(x+1.1*sp,z,.6*sp,.6*sp,.9*sp,.6*sp,cl_,0,1);for(const a of[-.7,.7])for(const b of[-.3,.3])bx(x+a*sp,z+b*sp,.25*sp,.25*sp,0,.5*sp,0x3a2a1a,0,1)};
 for(let i=0;i<5;i++)an(rb(-100,-66),rb(-17,-3),0xf2f2f2,1);for(let i=0;i<3;i++)an(rb(-100,-66),rb(-17,-3),0xf0a0a8,.7)};
// ---------- REGIÃO 8: LAGO AZUL ----------
const lago=()=>{
 bld({x:-8,z:86,w:8,d:6,f:1,fr:'s',c:0xc9b08a,pc:0x7a4a30,part:false,y:0,door:1});
 bridge(0,75,4,10);B(-2,-.3,66,2,.35,70,0x8a6a45,1);
 for(const x of[-2,2])B(x-.15,.35,66,x+.15,1.1,70,0x6b4a2b,1);
 bx(12,88,.5,.5,0,5,0x7a5a3a,0,1);
 for(let i=0;i<5;i++){const x=rb(-24,24),z=rb(66,70);lamp(x,z)}};
// ---------- TORRE DE COMUNICAÇÃO ----------
const tower=()=>{
 bld({x:66,z:-86,w:14,d:12,f:1,fr:'s',c:0xc9ccd2,pc:0x4a4e57,part:false,win:1});
 const x=66,zz=-100;
 for(let l=0;l<4;l++){const y=l*9,s=5-l*1.1;for(const a of[-1,1])for(const b of[-1,1])B(x+a*s/2-.35,y,zz+b*s/2-.35,x+a*s/2+.35,y+9,zz+b*s/2+.35,0xd23c3c,l==0);
  B(x-s/2,y+4,zz-s/2,x+s/2,y+4.3,zz+s/2,0xe9e9ee,0,1);B(x-s/2,y+8.6,zz-s/2,x+s/2,y+9,zz+s/2,0xe9e9ee,0,1)}
 B(x-.4,36,zz-.4,x+.4,44,zz+.4,0xe9e9ee,0,1);B(x-.7,44,zz-.7,x+.7,45,zz+.7,0xff3030,0,1);
 for(let i=0;i<4;i++)lamp(54+i*4,-80)};
// ---------- geração geral ----------
const gcol=(x,z)=>{if(isRoad(x,z))return 0x4b4f57;const r=regionAt(x,z),n=r&&r[0];
 if(n=='MONTANHA GELADA')return rn()<.15?0xcfe6f3:0xeef6fb;if(n=='CIDADE CENTRAL')return 0x8d9199;if(n=='ZONA INDUSTRIAL')return 0x6f7279;
 if(n=='DESERTO QUENTE')return 0xe0c785;if(n=='PORTO')return 0x8a8e96;if(n=='BASE MILITAR')return 0x657256;
 if(n=='FAZENDA'){if(x>-112&&x<-76&&z>-50&&z<-20){const k=(Math.floor((x+120)/12)+Math.floor((z+60)/12))%3;return[0x5c9a35,0xc9a63a,0x6b4a2b][k]}return 0x6fae50}
 if(n=='LAGO AZUL'){return Math.hypot(Math.max(0,Math.abs(x)-24),Math.max(0,Math.abs(z-84)-14))<3?0xd8c98b:0x4f9a45}
 if(n=='TORRE DE COMUNICAÇÃO')return 0x6a8a5a;
 return rn()<.12?0x56a046:0x5fae4d};
const build=()=>{if(built)return;built=true;
 grp=new T.Group();CT.add(grp);
 // estradas, água, ilhotas
 const rd=road;
 rd(-15.5,-8,9,104);rd(15.5,-8,9,104);rd(0,-23,104,8);rd(0,7,104,8);rd(-47,-8,8,104);rd(47,-8,8,104);rd(0,-55,104,8);rd(0,39,104,8);
 rd(-63,-55,24,8);rd(-70,-66.5,8,23);rd(58.5,-55,15,8);rd(66,-73.5,8,37);rd(72,-8,42,8);rd(-68,-8,34,8);rd(-85,-19,8,22);rd(0,56.5,8,27);rd(75.5,39,49,8);rd(82,55,8,32);rd(-68,39,34,8);rd(-80,49,8,20);
 WAT.push(rc(57,-10,6,136),rc(40,55,40,6),rc(21,66,6,28),rc(0,84,48,28));ISD.push(rc(-8,86,12,8),rc(12,88,8,8));
 // máscara de terra + píeres
 LM=[];for(let i=0;i<NT;i++){LM[i]=[];for(let j=0;j<NT;j++)LM[i][j]=land0(OR+i*TS+2,OR+j*TS+2)}
 const finishLand=()=>{for(let i=0;i<NT;i++)for(let j=0;j<NT;j++){const x=OR+i*TS+2,z=OR+j*TS+2;if(PIER.some(r=>inR(r,x,z))||XL.some(r=>inR(r,x,z)))LM[i][j]=true}};
 // regiões
 city();baseMil();mont();indus();desert();port();farm();lago();tower();
 bridge(57,-8,10,8);bridge(57,-55,10,8);bridge(57,39,10,8);
 finishLand();
 // píeres: guarda de bordas e postes
 for(const r of PIER){for(let z=r[1]+4;z<r[3];z+=6){B(r[0]-.1,0,z,r[0]+.4,1.3,z+.4,0x6b4a2b,1,1);B(r[2]-.4,0,z,r[2]+.1,1.3,z+.4,0x6b4a2b,1,1)}}
 // árvores
 const sc_=(n,rect,types,ok)=>{let c=0;for(let t=0;t<n*10&&c<n;t++){const x=rb(rect[0],rect[2]),z=rb(rect[1],rect[3]);if(!freeAt(x,z,1.6)||(ok&&!ok(x,z)))continue;tree(x,z,pk(types));c++}};
 sc_(120,[-130,-130,130,130],['oak','oak','pine'],(x,z)=>{const r=regionAt(x,z);return !r||r[0]=='FAZENDA'||r[0]=='TORRE DE COMUNICAÇÃO'||r[0]=='MONTANHA GELADA'});
 sc_(160,[-42,66,42,112],['oak','oak','pine'],(x,z)=>Math.hypot(Math.max(0,Math.abs(x)-26),Math.max(0,Math.abs(z-84)-16))>1);
 sc_(60,[-48,-130,48,-60],['spine','spine'],null);
 sc_(50,[-112,-54,-62,4],['oak'],(x,z)=>!(x>-114&&x<-74&&z>-52&&z<-18));
 sc_(50,[-130,-130,130,130],['oak','pine'],(x,z)=>{const r=regionAt(x,z);return !r||r[0]=='CIDADE CENTRAL'&&(Math.abs(x)>44||z<-52)});
 // lootspots (preenchido pelos prédios) + itens extras; ladrilhos do chão
 const cv=document.createElement('canvas');cv.width=cv.height=NT*8;const cx=cv.getContext('2d');cx.fillStyle='#1f5fa8';cx.fillRect(0,0,cv.width,cv.height);
 for(let i=0;i<NT;i++){TCOL[i]=[];for(let j=0;j<NT;j++){if(!LM[i][j])continue;const x0=OR+i*TS,z0=OR+j*TS,x1=x0+TS,z1=z0+TS,mx=x0+2,mz=z0+2;
  if(inPit(mx,mz)||XL.some(r=>inR(r,mx,mz)))continue;
  const w=isWat(mx,mz),y=w?-.3:0,col=w?(rn()<.5?0x3d8fd6:0x4a9de4):gcol(mx,mz),pier=PIER.some(r=>inR(r,mx,mz))&&!land0(mx,mz);
  const cc2=pier?0x8a6a45:col;top(x0,z0,x1,z1,y,cc2);TCOL[i][j]=cc2;
  const edge=!(i>0&&LM[i-1][j]&&i<NT-1&&LM[i+1][j]&&j>0&&LM[i][j-1]&&j<NT-1&&LM[i][j+1]);
  if(edge&&!pier)vb(x0,-3,z0,x1,-.03,z1,0x8a7a64,0);
  cx.fillStyle='#'+cc2.toString(16).padStart(6,'0');cx.fillRect(i*8,j*8,8,8)}}
 for(const s of SL){if(s.y0<=.1&&s.h>=2.5&&!s.door){cx.fillStyle='#d9c9a0';cx.fillRect((s.x-s.hw-OR)*2,(s.z-s.hd-OR)*2,s.hw*4,s.hd*4)}}
 for(const r of PIT){cx.fillStyle='#555';cx.fillRect((r[0]-OR)*2,(r[1]-OR)*2,(r[2]-r[0])*2,(r[3]-r[1])*2)}
 mc=cv;
 // mar
 const sea=new T.Mesh(new T.PlaneGeometry(1200,1200),new T.MeshLambertMaterial({color:0x2c7fd1}));sea.rotation.x=-Math.PI/2;sea.position.y=-1;sea.receiveShadow=true;grp.add(sea);
 // pedaços mesclados
 const mat=new T.MeshLambertMaterial({vertexColors:true});
 for(const a of ACC.values()){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(a.p,3));g.setAttribute('normal',new T.Float32BufferAttribute(a.n,3));g.setAttribute('color',new T.Float32BufferAttribute(a.c,3));g.setIndex(a.i);g.computeBoundingSphere();
  const m=new T.Mesh(g,mat);m.castShadow=m.receiveShadow=true;m.userData={d:a.d,x:(a.cx+.5)*36-144,z:(a.cz+.5)*36-144};grp.add(m);CHK.push(m)}
 // árvores em instâncias (um único desenho)
 const parts=[];for(const t of TRS){const s=t.s,y=t.y;
  if(t.t=='oak'){parts.push([t.x,y,t.z,.9*s,3.2*s,.9*s,0x6b4a2b],[t.x,y+2.4*s,t.z,4.4*s,2.2*s,4.4*s,t.g],[t.x,y+4.6*s,t.z,3*s,1.6*s,3*s,t.g])}
  else if(t.t=='pine'){parts.push([t.x,y,t.z,.8*s,2.2*s,.8*s,0x5a3d22],[t.x,y+1.6*s,t.z,3.8*s,1.7*s,3.8*s,0x2f6b3a],[t.x,y+3.3*s,t.z,2.9*s,1.7*s,2.9*s,0x2f6b3a],[t.x,y+5*s,t.z,1.9*s,1.8*s,1.9*s,0x2f6b3a])}
  else parts.push([t.x,y,t.z,.8*s,2.2*s,.8*s,0x5a3d22],[t.x,y+1.6*s,t.z,3.8*s,1.7*s,3.8*s,0xeaf4f0],[t.x,y+3.3*s,t.z,2.9*s,1.7*s,2.9*s,0xe0eef0],[t.x,y+5*s,t.z,1.9*s,1.8*s,1.9*s,0xf4fbff])}
 const im=new T.InstancedMesh(new T.BoxGeometry(1,1,1),new T.MeshLambertMaterial({color:0xffffff}),parts.length),m4=new T.Matrix4(),c3=new T.Color();
 parts.forEach((p,i)=>{m4.makeScale(p[3],p[4],p[5]).setPosition(p[0],p[1]+p[4]/2,p[2]);im.setMatrixAt(i,m4);im.setColorAt(i,c3.set(p[6]))});im.frustumCulled=false;im.receiveShadow=true;grp.add(im);
 for(const d of DR)grp.add(d.g);
};
// ---------- loot espalhado (diferente a cada partida) ----------
const itemMesh=t=>{const g=new T.Group(),bm=(w,h,d,x,y,z,c)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshLambertMaterial({color:c}));m.position.set(x,y,z);g.add(m)};
 if(t=='med'){bm(.7,.5,.5,0,.6,0,0xf4f4f4);bm(.5,.12,.1,0,.6,.26,0xe03030);bm(.12,.4,.1,0,.6,.26,0xe03030)}
 else if(t=='gren'){bm(.4,.5,.4,0,.55,0,0x3a5a2a);bm(.15,.15,.15,0,.9,0,0xcccccc)}
 else if(t=='ammo'){bm(.8,.4,.5,0,.5,0,0xc9a030);bm(.6,.1,.3,0,.75,0,0x6b4a2b)}
 else if(t=='vest'){bm(.8,.9,.4,0,.7,0,0x2a5ec9);bm(.6,.3,.45,0,.8,0,0x1a3a8a)}
 else if(t=='helm'){bm(.7,.45,.7,0,.6,0,0x6b7280);bm(.5,.2,.72,0,.45,0,0x3a3f48)}
 else{bm(.8,.9,.5,0,.7,0,0xe08a2a);bm(.5,.35,.2,0,.55,.3,0xb06a1a)}
 const r=new T.Mesh(new T.PlaneGeometry(1.4,1.4),new T.MeshBasicMaterial({color:0xffe27a,transparent:true,opacity:.45,depthWrite:false}));r.rotation.x=-Math.PI/2;r.position.y=.05;g.add(r);return g};
const NM={med:'Kit médico',gren:'Granada',ammo:'Munição',vest:'Colete',helm:'Capacete',bag:'Mochila'};
const clearItems=()=>{for(const i of ITM)sc.remove(i.g);ITM.length=0};
const addItem=(t,x,z,y)=>{const g=itemMesh(t);g.position.set(x,y||0,z);g.visible=false;sc.add(g);ITM.push({t,x,z,y:y||0,g})};
const loot=()=>{WLD.clearGround();clearItems();arm.vest=arm.helm=0;
 const sp=LOOT.slice().sort(()=>Math.random()-.5);let n=0;const put=(x,z,y,ch)=>{if(n>118)return;if(ch){for(let k=0;k<2;k++)WLD.addGround(WLD.pick(),x+(k?.9:-.9),z,0,y);n+=2;addItem(pk(['med','vest','helm','bag','gren']),x,z+1,y)}else{WLD.addGround(WLD.pick(),x,z,0,y);n++}};
 for(let i=0;i<sp.length&&n<96;i++){const s=sp[i];if(Math.random()<.78)put(s.x,s.z,s.y,s.ch)}
 for(let i=0;i<30&&n<118;i++){const q=rp(130);if(q)put(q[0],q[1],0,0)}
 for(let i=0;i<sp.length;i++){const s=sp[i];if(Math.random()<.5)addItem(pk(['med','med','gren','ammo','ammo','vest','helm','bag']),s.x+rb(-.8,.8),s.z+rb(-.8,.8),s.y)}
 for(let i=0;i<22;i++){const q=rp(130);if(q)addItem(pk(['med','ammo','gren','vest','helm','bag']),q[0],q[1],0)}};
const rp=R_=>{R_=R_||132;for(let i=0;i<60;i++){const a=Math.random()*6.283,r=Math.sqrt(Math.random())*R_,x=Math.cos(a)*r,z=Math.sin(a)*r;if(freeAt(x,z,1.2))return[x,z]}return[0,-8]};
// ---------- tick: portas, itens, regiões, pedaços visíveis ----------
setInterval(()=>{if(!on||mode!='game')return;tk++;
 const px=P.x,pz=P.z;
 for(const d of DR){const dx=d.cx-px,dz=d.cz-pz,dist=dx*dx+dz*dz;if(dist>8100){if(d.g.visible&&d.t<=0)d.g.visible=false;if(d.t==0)continue}
  let want=Math.abs(P.y-d.gy)<2.5&&dist<6.5;if(!want&&tk%3==0)for(const e of G.e)if(e.a&&Math.abs(e.x-d.cx)<2.6&&Math.abs(e.z-d.cz)<2.6){want=true;break}
  if(want&&!d.w){d.w=1;beep(260,.04)}else if(!want)d.w=0;
  d.g.visible=dist<8100;d.t+=want?.34:-.34;d.t=Math.max(0,Math.min(1,d.t));d.g.rotation.y=d.sg*d.t*Math.PI/2;d.s.o=d.t>.5}
 if(tk%3==0){for(const m of CHK){const dist=Math.hypot(m.userData.x-px,m.userData.z-pz);m.visible=m.userData.d?dist<95:dist<210}
  const r=regionAt(px,pz);if(r!=lastReg){lastReg=r;if(r&&G.on&&G.m=='br'&&(!G.ph||G.ph=='ground'))ICE.toast('📍 '+r[0],r[2])}}
 const air=!!PL.air||(G.ph&&G.ph!='ground');
 for(let i=ITM.length-1;i>=0;i--){const it=ITM[i],dx=it.x-px,dz=it.z-pz,d2=dx*dx+dz*dz,v=d2<3600;if(it.g.visible!=v)it.g.visible=v;if(!v)continue;it.g.rotation.y+=.2;
  if(!air&&PL.a&&d2<2.6&&Math.abs(it.y-P.y)<2.3){let ok=1;
   if(it.t=='med')window.__inv.med(1);else if(it.t=='gren')window.__inv.gr(1);else if(it.t=='bag'){window.__inv.med(2);window.__inv.gr(1)}
   else if(it.t=='ammo'){if(AM.max&&AM.n<AM.max){AM.n=AM.max;AM.rl=0;AM.ui()}else ok=0}
   else if(it.t=='vest'){if(arm.vest)ok=0;else arm.vest=1}else if(it.t=='helm'){if(arm.helm)ok=0;else arm.helm=1}
   if(ok){sc.remove(it.g);ITM.splice(i,1);ICE.toast('+ '+NM[it.t]+(it.t=='vest'?' (−25% dano)':it.t=='helm'?' (−15% dano)':''),'#9ff0b0');beep(900,.06)}}}
},90);
return{get on(){return on},get mc(){return mc},arm,regionAt,land,base,freeAt,rp,loot,build,SL,GR,DR,LOOT,PIT,RG,TRS,ROADS,WAT,
 enter(){build();on=1;lastReg=null;arm.vest=arm.helm=0;for(const d of DR){d.t=0;d.s.o=false;d.g.rotation.y=0}},
 exit(){on=0;clearItems()},
 near,BL,
 hit(x,z){let b=false;near(x,z,s=>{if(!b&&!s.o&&s.y0<=.6&&s.h>1.5&&Math.abs(x-s.x)<s.hw&&Math.abs(z-s.z)<s.hd)b=true});return b},
 blocked(x,z,hw,hd,y){if(!land(x,z))return true;let b=false;near(x,z,s=>{if(!b&&!s.o&&Math.abs(x-s.x)<hw+s.hw+.05&&Math.abs(z-s.z)<hd+s.hd+.05&&y<s.h-.15&&y+1.8>s.y0)b=true});return b},
 cam(tx,ty,tz,cx,cy,cz){let k=1;for(let i=1;i<=14&&k==1;i++){const t=i/14,x=tx+(cx-tx)*t,y=ty+(cy-ty)*t,z=tz+(cz-tz)*t;let h=false;near(x,z,s=>{if(!h&&!s.o&&Math.abs(x-s.x)<s.hw+.2&&Math.abs(z-s.z)<s.hd+.2&&y<s.h+.2&&y>s.y0-.2)h=true});if(h)k=Math.max(.12,(i-1.6)/14)}return k},
 dm(){return(arm.vest?.75:1)*(arm.helm?.85:1)},
 info(){return{verts:[...ACC.values()].reduce((n,a)=>n+a.p.length/3,0),solids:SL.length,doors:DR.length,loot:LOOT.length,trees:TRS.length,chunks:CHK.length}}}
})();

const G={ph:'',zt:0,lim:70,city:0,sv:null,tv:null,ft:0,e:[],on:0,over:0,dead:0,fire:0,fcd:0,t:0,u:0,z:70,m:'',rd:0,sc:[0,0],wait:0,fl:0,
 hud(v){['#gi','#xh','#bf'].forEach(q=>$(q).style.display=v?'':'none')},
 clear(k){ICE.reset();WLD.clearGround();GLD.exit();G.e.forEach(e=>sc.remove(e.g));G.e=[];if(!k){G.unCity();zone.visible=false;G.on=0;G.fire=0;G.dead=0;PL.hp=100;PL.a=1;me.visible=true;G.hud(0)}},
 unCity(){if(!G.city)return;G.city=0;ISL.exit();solids.splice(0);solids.push(...G.sv);trees.splice(0);trees.push(...G.tv);G.lim=70;CT.visible=false;PLN.visible=false;cano.visible=false;G.ph='';PL.air=0;$('#bj').textContent='Pular'},
 stop(){PM.off();if(G.on&&GM[G.m].r){S.rp[G.m]=Math.max(0,S.rp[G.m]-10);save()}G.clear()},
 begin(){G.clear();const m=S.gm;G.m=m;if(!GM[m].b)return;G.on=1;G.t=0;G.zt=0;G.wait=0;PL.k=0;PL.hp=100;PL.a=1;G.dead=0;G.hud(1);
  if(m=='br'){G.city=1;G.sv=solids.splice(0);G.tv=trees.splice(0);solids.push(...CS);ISL.enter();G.lim=140;W.visible=false;CT.visible=true;if(sc.fog){sc.fog.near=140;sc.fog.far=420}zone.visible=true;G.z=140;for(let i=0;i<59;i++){const q=ISL.rp();spawn(i+1,i,q[0],q[1])}PLN.position.set(-150,128,rr(80));PLN.visible=true;G.ph='plane';PL.air=1;me.visible=false;$('#bj').textContent='PULAR';P.x=-150;P.z=PLN.position.z;P.y=128}
  else if(m=='cs'){G.sc=[0,0];G.rd=0;G.round()}
  else for(let i=0;i<(m=='dm'?5:1);i++){const[x,z]=rpos();spawn(i+1,i,x,z)}
  WLD.start(m);if(m=='gl')GLD.enter(),GLD.round();
  G.fm()},
 round(){G.rd++;G.clear(1);PL.hp=100;PL.a=1;G.dead=0;me.visible=true;P.x=rr(5);P.z=44;P.yaw=0;spawn(0,1,-6,44);spawn(0,2,6,46);spawn(1,3,-8,-44);spawn(1,4,0,-46);spawn(1,5,8,-44)},
 chk(){const m=G.m,b=G.e;
  if(m=='br'){const n=b.filter(e=>e.a).length;if(!PL.a)G.end(0,n+1);else if(!n)G.end(1,1)}
  else if(m=='cs'){if(G.wait>0)return;const a=PL.a||b.some(e=>e.a&&!e.team),c=b.some(e=>e.a&&e.team);if(a&&c)return;const w=a?0:1;G.sc[w]++;G.wait=2.5;if(G.sc[w]>=4)G.end(w==0)}
  else{const L=m=='dm'?15:5;if(PL.k>=L)G.end(1);else if(b.some(e=>e.k>=L))G.end(0)}},
 end(w,pl){if(!G.on)return;G.on=0;G.over=1;const m=G.m;let h='';if(m=='br')w=pl==1;
  if(GM[m].r){const o=S.rp[m],d=m=='br'?(pl==1?40:pl<=3?25:pl<=10?10:pl<=30?0:-10)+3*PL.k:(w?25:-12);S.rp[m]=Math.max(0,o+d);h=`<p>Patente: <b>${rk(o)}</b> → <b>${rk(S.rp[m])}</b> (${d>=0?'+':''}${d} pts)</p>`+(m=='br'?`<p>Posição: <b>#${pl}</b> de 60</p>`:`<p>Placar: <b>${G.sc[0]} x ${G.sc[1]}</b></p>`)}
  const cn=w?60:20;S.coins+=cn;save();refresh();modal(w?'VITÓRIA':'DERROTA',h+`<p>Abates: <b>${PL.k}</b> · +${cn} moedas</p>`)},
 fm(){const m=G.m,h='❤ '+Math.ceil(PL.hp);$('#gi').textContent=m=='br'?`${{plane:'AVIÃO · toque em PULAR',fall:'QUEDA · PULAR abre o paraquedas',chute:'PLANANDO'}[G.ph]||'ZONA '+(G.z|0)+'m'} · RESTAM ${G.e.filter(e=>e.a).length+PL.a} · ABATES ${PL.k} · ${h}`:m=='cs'?`${G.sc[0]} x ${G.sc[1]} · RODADA ${G.rd} · ${h}`:`ABATES ${PL.k}/${m=='dm'?15:5} · ${h}`},
 air(dt){const jx=inp.jx+(keys.d?1:0)-(keys.a?1:0),jy=inp.jy+(keys.w?1:0)-(keys.s?1:0),j=inp.jump||keys[' '],cp=Math.cos(P.pitch),d=6.5;inp.jump=false;keys[' ']=false;
  if(G.ph=='plane'){PLN.position.x+=32*dt;P.x=PLN.position.x;P.z=PLN.position.z;P.y=128;cam.position.set(P.x-20,P.y+7,P.z+13);cam.lookAt(P.x+6,P.y-1,P.z);skyDome.position.copy(cam.position);
   if(j||P.x>146){G.ph='fall';P.vy=0;G.ft=0;PLN.visible=false;me.visible=true;$('#bj').textContent='PARAQUEDAS'}return}
  G.ft+=dt;if(G.ph=='fall'){P.vy=Math.max(-32,P.vy-30*dt);if((j&&G.ft>.6)||P.y<38){G.ph='chute';cano.visible=true}}else P.vy=-7;
  const sp=G.ph=='fall'?14:10,fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),rx=Math.cos(P.yaw),rz=-Math.sin(P.yaw);
  P.x=Math.max(-G.lim,Math.min(G.lim,P.x+(rx*jx+fx*jy)*sp*dt));P.z=Math.max(-G.lim,Math.min(G.lim,P.z+(rz*jx+fz*jy)*sp*dt));
  P.py=P.y;P.y+=P.vy*dt;const gy=collide(P);if(P.y<=gy){P.y=gy;P.vy=0;P.gr=true;P.face=P.yaw+Math.PI;G.ph='ground';PL.air=0;cano.visible=false;$('#bj').textContent='Pular';beep(250,.1)}
  me.position.set(P.x,P.y,P.z);me.rotation.y=P.yaw+Math.PI;anim(me,t,0,true);cano.position.set(P.x,P.y+3.4,P.z);
  cam.position.set(P.x+Math.sin(P.yaw)*cp*d,Math.max(.5,P.y+1.5+Math.sin(P.pitch)*d),P.z+Math.cos(P.yaw)*cp*d);cam.lookAt(P.x,P.y+1.2,P.z);
  skyDome.position.copy(cam.position);sun.position.set(P.x+20,Math.max(P.y,0)+35,P.z+12);sun.target.position.set(P.x,Math.max(P.y,0),P.z)},
 tick(dt){if(!G.on)return;G.t+=dt;PL.x=P.x;PL.z=P.z;const all=[PL,...G.e];
  G.fcd-=dt;if(!(G.fire||keys.f))WLD.held=false;if((G.fire||keys.f)&&!ICE.ph&&G.fcd<=0&&PL.a&&!PL.air&&!GLD.lock()&&AM.can()&&WLD.ok()){G.fcd=WLD.cd();AM.use();shoot()}
  if(G.m=='br'){if(G.ph!='plane')G.zt+=dt;G.z=Math.max(10,140-130*Math.min(1,Math.max(0,G.zt-30)/330));zone.scale.set(G.z,1,G.z);for(const o of all)if(o.a&&!o.air&&Math.hypot(o.x,o.z)>G.z)hurt(o,3*dt,null)}
  if(G.wait>0&&(G.wait-=dt)<=0)G.round();
  for(const o of all)if(!o.a&&o.rs>0&&(o.rs-=dt)<=0)resp(o);
  for(const e of G.e)if(!e.a&&e.g.visible){const q=G.t+e.t;anim(e.g,q,0,false);if(q-e.g.userData.d0>2.5)e.g.visible=false}
  for(const e of G.e){if(!e.a||G.ph=='plane'||GLD.lock())continue;e.cd-=dt;let b=null,bd=1e9;for(const o of all)if(o.a&&!o.air&&o.team!=e.team){const d=Math.hypot(o.x-e.x,o.z-e.z);if(d<bd){bd=d;b=o}}
   let sp=0,dx=0,dz=0;
   if(b&&bd<32){e.fy=Math.atan2(b.x-e.x,b.z-e.z);if(bd>12){sp=3;dx=Math.sin(e.fy);dz=Math.cos(e.fy)}else if(bd<6){sp=3;dx=-Math.sin(e.fy);dz=-Math.cos(e.fy)}
    if(e.cd<=0){e.cd=.8+Math.random()*.7;e.g.userData.sh=G.t+e.t+.2;{const dd=Math.hypot(e.x-P.x,e.z-P.z);if(dd<55)SFX.shot(e.wk,.55*(1-dd/55))}if(Math.random()<.4){const wb=ICE.seg(e.x,e.z,b.x,b.z);if(wb)ICE.dmg(wb,8,null);else if(los(e.x,e.z,b.x,b.z))hurt(b,b.isP?9:16,e)}}}
   else{if(Math.hypot(e.wx-e.x,e.wz-e.z)<2.5||e.cd<-4){wp(e);e.cd=1}if(G.m=='br'&&Math.hypot(e.x,e.z)>G.z-4){e.wx=e.wz=0}e.fy=Math.atan2(e.wx-e.x,e.wz-e.z);sp=3;dx=Math.sin(e.fy);dz=Math.cos(e.fy)}
   e.x+=dx*sp*dt;e.z+=dz*sp*dt;collide(e);const L=G.lim-2;e.x=Math.max(-L,Math.min(L,e.x));e.z=Math.max(-L,Math.min(L,e.z));
   let a=e.fy-e.g.rotation.y;a=Math.atan2(Math.sin(a),Math.cos(a));e.g.rotation.y+=a*Math.min(1,dt*8);e.g.position.set(e.x,0,e.z);if(e.g.visible=Math.hypot(e.x-P.x,e.z-P.z)<90)anim(e.g,G.t+e.t,sp,false)}
  $('#gi').style.borderBottomColor=(G.fl-=dt)>0?'#ff4d5e':'';if((G.u+=dt)>.2){G.u=0;G.fm()}}};
// ---------- artes dos modos (desenhadas com os personagens do jogo) ----------
const ch=(i,x,y,sz=1,f=1,w=0)=>{const c=typeof i=='object'?i:CH[i%CH.length],H=hex;return `<g transform='translate(${x} ${y}) scale(${f*sz} ${sz})'><rect x=-4.5 y=-14 width=3.8 height=14 fill='${H(c.pa)}'/><rect x=.7 y=-14 width=3.8 height=14 fill='${H(c.pa)}'/><rect x=-5 y=-1.5 width=4.8 height=2.5 fill='${H(c.sw)}'/><rect x=.2 y=-1.5 width=4.8 height=2.5 fill='${H(c.sw)}'/><rect x=-6 y=-28 width=12 height=14.5 fill='${H(c.sh)}'/><rect x=-9 y=-27 width=3.4 height=11 fill='${H(c.sk)}'/><rect x=5.6 y=-27 width=3.4 height=11 fill='${H(c.sk)}'/><rect x=-4.6 y=-37.6 width=9.2 height=9.2 fill='${H(c.sk)}'/><rect x=-4.6 y=-37.6 width=9.2 height=3.2 fill='${H(c.h)}'/><rect x=-2.8 y=-33.6 width=1.6 height=1.6 fill='#111'/><rect x=1.2 y=-33.6 width=1.6 height=1.6 fill='#111'/>${w==1?`<rect x=2 y=-25 width=16 height=3 fill='#222'/><rect x=2 y=-22 width=4 height=5 fill='#222'/>`:w==2?`<rect x=8 y=-48 width=2.2 height=26 fill='#e8eef8' transform='rotate(22 9 -26)'/><rect x=5.5 y=-26 width=7 height=2 fill='#ffc233'/>`:''}</g>`};
const star=(cx,cy,R,r,n)=>Array.from({length:n*2},(_,i)=>{const a=i*Math.PI/n,d=i%2?r:R;return(cx+Math.cos(a)*d).toFixed(1)+','+(cy+Math.sin(a)*d).toFixed(1)}).join(' ');
const scn=(k,a,b,x)=>`<svg class=mi viewBox='0 0 100 150' preserveAspectRatio='xMidYMax meet' style='overflow:visible'><defs><linearGradient id='ag${k}' gradientUnits='userSpaceOnUse' x1=0 y1=-20 x2=0 y2=125><stop offset=0 stop-color='${a}'/><stop offset=1 stop-color='${b}'/></linearGradient></defs><rect x=-100 y=-100 width=300 height=400 fill='url(#ag${k})'/>${x}</svg>`;
const ART={
 br:()=>scn('br','#2b1a4a','#ff9a3d',`<circle cx=72 cy=70 r=15 fill='#ffd36b'/><rect x=-100 y=98 width=300 height=100 fill='#7a2e3a'/><path d='M0 100Q25 80 50 98T100 92V150H0z' fill='#7a2e3a'/><rect x=-100 y=118 width=300 height=100 fill='#3b1d34'/><ellipse cx=50 cy=112 rx=46 ry=9 fill='none' stroke='#ff4d5e' stroke-width=1.6 stroke-dasharray='5 3'/><path d='M0 118Q30 108 60 120T100 114V150H0z' fill='#3b1d34'/><g transform='translate(0 -20)'><path d='M30 58Q50 22 70 58z' fill='#ffc233'/><path d='M30 58Q40 40 50 58M50 58Q60 40 70 58' fill='none' stroke='#b57e00' stroke-width=.8/><path d='M32 58L47 88M68 58L53 88M50 58V88' stroke='#fff' stroke-width=.5/>${ch(0,50,106,.62)}</g>`),
 cs:()=>scn('cs','#0b2a5c','#4aa3e8',`<rect x=62 y=30 width=14 height=90 fill='#5a6b8a'/><rect x=60 y=26 width=18 height=6 fill='#3c4a66'/><rect x=66 y=40 width=3 height=5 fill='#ffd36b'/><rect x=-100 y=118 width=300 height=80 fill='#1b2f54'/><rect x=8 y=104 width=16 height=16 fill='#b08040'/><rect x=76 y=108 width=16 height=12 fill='#b08040'/>${ch(1,30,130,1.05,1,1)}${ch(3,74,130,1.05,-1,1)}<polygon points='48,100 57,102 49,103 56,107 48,106' fill='#ffd36b'/>`),
 dm:()=>scn('dm','#2a1250','#c04fd1',`<polygon points='${star(50,62,44,22,10)}' fill='#ffb347'/><polygon points='${star(50,62,30,14,10)}' fill='#fff2b0'/><rect x=-100 y=124 width=300 height=80 fill='#241040'/>${ch(0,22,132,.95,1,1)}${ch(2,78,132,.95,-1,1)}${ch(4,50,146,1.15,1,1)}`),
 gl:()=>scn('gl','#3a2406','#e0a62d',`<rect x=6 y=30 width=10 height=96 fill='#f3d9a0'/><rect x=84 y=30 width=10 height=96 fill='#f3d9a0'/><rect x=3 y=26 width=16 height=6 fill='#d9b46a'/><rect x=81 y=26 width=16 height=6 fill='#d9b46a'/><rect x=-100 y=130 width=300 height=80 fill='#7a5320'/><ellipse cx=50 cy=128 rx=48 ry=12 fill='#7a5320'/><ellipse cx=50 cy=126 rx=44 ry=9 fill='#caa05a'/>${ch(2,30,128,1.1,1,2)}${ch(5,70,128,1.1,-1,2)}`),
 tr:()=>scn('tr','#0e3d22','#7bd88f',`<circle cx=50 cy=56 r=26 fill='#fff'/><circle cx=50 cy=56 r=21 fill='#ff4d5e'/><circle cx=50 cy=56 r=15 fill='#fff'/><circle cx=50 cy=56 r=9 fill='#ff4d5e'/><circle cx=50 cy=56 r=3.5 fill='#ffc233'/><rect x=48 y=80 width=4 height=44 fill='#6b4a2b'/><rect x=-100 y=118 width=300 height=80 fill='#2e7d32'/><path d='M0 120Q50 108 100 120V150H0z' fill='#2e7d32'/><line x1=72 y1=34 x2=54 y2=54 stroke='#fff' stroke-width=1.4/><path d='M72 34l5-3-1 6z' fill='#ffc233'/>${ch(5,22,140,.9,1,1)}`),
 pe:()=>scn('pe','#1a2233','#6c7a91',`<circle cx=50 cy=56 r=24 fill='none' stroke='#ffc233' stroke-width=9 stroke-dasharray='6.28 6.28'/><circle cx=50 cy=56 r=19 fill='#2a3b57' stroke='#ffc233' stroke-width=4/><circle cx=50 cy=56 r=7 fill='#ffc233'/>${[[100,40],[116,25],[132,55]].map(([y,v])=>`<rect x=14 y=${y} width=72 height=4 rx=2 fill='#0b1430'/><rect x=14 y=${y} width=${v} height=4 rx=2 fill='#3de0ff'/><circle cx=${14+v} cy=${y+2} r=5 fill='#fff'/>`).join('')}`)};
// ---------- telas de carregamento: 4 imagens (a cada carregamento troca para a próxima) ----------
/* LDI -> js/loading.js */
{const st=document.createElement('style');st.textContent=`.lbg{display:none;position:absolute;inset:-20px;background-size:cover;background-position:center;filter:blur(16px) brightness(.45)}
.lw{--u:max(1vh,calc(100vw/239));position:absolute;inset:0;overflow:hidden}
.lwi{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:max(100%,calc(100vh*2.39));height:max(100%,calc(100vw/2.39))}.lw img{display:block;width:100%;height:100%;filter:contrast(1.07) saturate(1.12)}
.lgo{position:absolute;height:auto;overflow:visible;filter:drop-shadow(0 0 7px #8a3cff) drop-shadow(0 4px 0 rgba(0,0,0,.45));pointer-events:none}
.lw:after{content:'';position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at 50% 45%,transparent 58%,rgba(8,2,20,.5) 100%)}
.lov{position:absolute;left:0;right:0;bottom:0;height:calc(var(--u)*27);background:linear-gradient(to top,#0b0418 0,#0b0418 70%,rgba(11,4,24,0));z-index:1}
.lw .lt{position:absolute;left:4vw;right:auto;bottom:calc(var(--u)*9.5);text-align:left;font:700 calc(var(--u)*4.2) var(--f);letter-spacing:1px;color:#fff;text-shadow:0 0 8px #8a3cff}
.lbar{position:absolute;left:4vw;right:14vw;bottom:calc(var(--u)*4.5);height:calc(var(--u)*2.2);border-radius:8px;background:rgba(0,0,0,.55);border:2px solid #5b1fd6;overflow:hidden}
.lbar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#4b17c9,#b36bff 80%,#fff);box-shadow:0 0 10px #a35bff}
.lpc{position:absolute;right:4vw;bottom:calc(var(--u)*3.2);font:700 calc(var(--u)*5.2) var(--f);color:#fff;text-shadow:0 0 8px #8a3cff}
@media (max-aspect-ratio:2/1){.lbg{display:block}.lw{--u:calc(100vw/239);inset:auto;left:0;right:0;top:50%;transform:translateY(-50%);height:calc(100vw/2.39)}.lwi{left:0;top:0;transform:none;width:100%;height:100%}}`;document.head.appendChild(st)}
const LDP=[[18,4.4,178],[369,8.5,240],[9,9.5,176],[371,14.25,236]];let LGN=0;
const LGO=i=>{const k=++LGN,[x,y,w]=LDP[i],T=(t,X,Y,fs,len,fill)=>{const a=`x=${X} y=${Y} font-size=${fs} textLength=${len} lengthAdjust=spacingAndGlyphs`,g=`transform='translate(${(.1405*Y).toFixed(1)},0) skewX(-8)'`;return `<g ${g}><text ${a} fill=none stroke=#fff stroke-width=15 stroke-linejoin=round>${t}</text><text ${a} fill=none stroke=#14002e stroke-width=8 stroke-linejoin=round>${t}</text><text ${a} fill='${fill}'>${t}</text></g>`};
 return `<svg class=lgo viewBox='0 0 400 250' style='left:${(x/6.12).toFixed(2)}%;top:${(y/2.56).toFixed(2)}%;width:${(w/6.12).toFixed(2)}%'><defs><linearGradient id=lw${k} x1=0 y1=0 x2=0 y2=1><stop offset=0 stop-color=#fff /><stop offset=1 stop-color=#d9cfff /></linearGradient><linearGradient id=lp${k} x1=0 y1=0 x2=0 y2=1><stop offset=0 stop-color=#e3a8ff /><stop offset=.55 stop-color=#a24dff /><stop offset=1 stop-color=#6a22e8 /></linearGradient><linearGradient id=lc${k} x1=0 y1=0 x2=0 y2=1><stop offset=0 stop-color=#f3c6ff /><stop offset=1 stop-color=#a03dff /></linearGradient></defs>
<polygon points='140,64 152,22 180,46 200,8 220,46 248,22 260,64' fill='url(#lc${k})' stroke=#14002e stroke-width=6 stroke-linejoin=round /><rect x=140 y=62 width=120 height=15 rx=3 fill=#7a2cff stroke=#14002e stroke-width=5 />${[[152,22],[200,8],[248,22]].map(([a,b])=>`<circle cx=${a} cy=${b} r=7 fill=#fff stroke=#14002e stroke-width=4 />`).join('')}
${T('VIOXAR',20,152,92,360,`url(#lw${k})`)}${T('ROYALE',12,238,112,364,`url(#lp${k})`)}</svg>`};
const LDV=(i,t,id)=>`<div class=lbg style="background-image:url(${LDI[i]})"></div><div class=lw><div class=lwi><img src="${LDI[i]}" alt="">${LGO(i)}</div><div class=lov><div class=lt${id?' id=lt':''}>${t}</div><div class=lbar><i${id?' id=lf':''}></i></div>${id?'<b class=lpc id=lp>0%</b>':''}</div></div>`;
// ---------- tela de carregamento (logo -> carregando -> tela inicial) ----------
(()=>{const L=$('#ld'),bolt=`<svg viewBox='0 0 24 40'><polygon points='14,0 2,24 11,24 8,40 22,14 13,14' fill='#ffc233'/></svg>`,
 logo=`<div class=lg style='top:3vh;right:3vw'>${bolt}<div>VIOXAR<br><span>ROYALE</span></div></div>`,
 art=x=>`<svg class=art viewBox='0 0 160 72' preserveAspectRatio='xMidYMid slice'>${x}</svg>`,
 a1=art(`<defs><radialGradient id=lg1 cx=.5 cy=.3 r=.8><stop offset=0 stop-color='#7a1f2a'/><stop offset=1 stop-color='#12060c'/></radialGradient></defs><rect width=160 height=72 fill='url(#lg1)'/><circle cx=80 cy=14 r=15 fill='#ffc86b'/><path d='M65 14h30M80-1v30M70 4l20 20M90 4L70 24' stroke='#a8501f' stroke-width=.6 fill='none'/><polygon points='58,6 80,20 102,6 108,56 52,56' fill='#3a0f1c'/><polygon points='64,24 80,34 96,24 98,56 62,56' fill='#5a1426'/><ellipse cx=80 cy=57 rx=16 ry=3.2 fill='#ff3b2f' opacity=.85/><rect y=60 width=160 height=12 fill='#14060d'/>${ch(0,18,66,1.05,1,2)}${ch(1,34,67,1.1,1,2)}${ch(2,52,68,1.15,1,2)}${ch(3,108,68,1.15,-1,2)}${ch(4,126,67,1.1,-1,2)}${ch(5,142,66,1.05,-1,2)}`),
 a2=art(`<defs><linearGradient id=tg1 x1=0 y1=0 x2=1 y2=1><stop offset=0 stop-color='#2a1230'/><stop offset=.55 stop-color='#d9632a'/><stop offset=1 stop-color='#ffe6a8'/></linearGradient><radialGradient id=tg2 cx=.78 cy=.35 r=.55><stop offset=0 stop-color='#fff6d0' stop-opacity=.95/><stop offset=1 stop-color='#fff6d0' stop-opacity=0/></radialGradient></defs><rect width=160 height=72 fill='url(#tg1)'/><rect width=160 height=72 fill='url(#tg2)'/><polygon points='0,72 0,52 40,44 90,56 160,40 160,72' fill='#3a1a2a' opacity=.55/>${ch(5,134,68,1.35,-1,1)}${ch(2,60,66,1.35,1,1)}${ch(0,26,70,1.5,1,1)}${ch(4,102,70,1.6,-1,1)}${ch(3,80,72,1.7,1,1)}`);
 L.innerHTML=`<div id=l1><div class=sp>${LGO(0).replace(/style='[^']*'/,"style='position:static;width:min(62vw,560px);max-height:70vh'")}</div></div><div id=l2>${LDV(LDN.i,'CARREGANDO...',1)}</div><div id=l3>${LDV(LDN.i,'',0)}<div class=vs>v1.0.0</div><button class=ib id=ib>INICIAR JOGO</button></div>`;
 const go=n=>[1,2,3].forEach(i=>$('#l'+i).classList.toggle('on',i==n)),T0=2600,D=5200;
 setTimeout(()=>go(1),60);setTimeout(()=>go(0),2000);setTimeout(()=>go(2),T0-100);setTimeout(()=>go(3),T0+D+400);
 const tk=n=>{const p=Math.min(1,Math.max(0,(n-T0)/D));$('#lf').style.width=(Math.min(1,p+.05*Math.sin(p*14)*(1-p))*100)+'%';$('#lt').textContent='CARREGANDO'+'.'.repeat(1+(n/350|0)%3);$('#lp').textContent=Math.round(p*100)+'%';if(p<1||n<T0)requestAnimationFrame(()=>tk(performance.now()))};tk(performance.now());
 $('#ib').onclick=()=>{beep(700,.12);L.style.opacity=0;setTimeout(()=>L.hidden=true,500)}})();

// ---------- início de partida: busca → espera → ilha de pré-partida → avião ----------
const AM={n:30,max:30,rl:0,can:()=>AM.n>0&&!AM.rl,
 use(){AM.n--;if(!AM.n)AM.reload();AM.ui()},
 reload(){if(AM.rl||AM.n==AM.max||!AM.max)return;AM.rl=WLD.rt();SFX.reload();AM.ui()},
 ui(){$('#wa').textContent=AM.n;$('#wm').textContent='/'+AM.max;$('#wr').textContent=AM.rl?'Recarregando...':WLD.name()}};
const TIPS=['Mudar de posição com frequência confunde os inimigos.','Agache atrás de caixas para recarregar com segurança.','Deitar reduz sua velocidade, mas dificulta ser visto.','A zona segura sempre fecha: fique de olho no mapa.'];
const PM={on:0,t:0,tm:[],iv:0,
 at(f,ms){PM.tm.push(setTimeout(f,ms))},
 off(){PM.on=0;PM.tm.forEach(clearTimeout);PM.tm=[];clearInterval(PM.iv);['#mk','#wt','#tp'].forEach(s=>$(s).hidden=true)},
 start(){PM.off();const g=GM[S.gm];if(!g||!g.b){setMode('game');G.begin();return}
  let s=0;const tk=()=>$('#mkt').textContent='00:'+String(s).padStart(2,'0');tk();$('#mk').hidden=false;
  PM.iv=setInterval(()=>{s++;tk()},1000);$('#mkc').onclick=()=>{PM.off();beep(330,.05)};
  PM.at(()=>{clearInterval(PM.iv);$('#mk').hidden=true;PM.wait()},7000)},
 wait(){const W=$('#wt'),bolt=`<svg viewBox='0 0 24 40' style='height:1.7em'><polygon points='14,0 2,24 11,24 8,40 22,14 13,14' fill='#ffc233'/></svg>`;
  LDN.i=(LDN.i+1)%4;W.innerHTML=LDV(LDN.i,'ESPERANDO POR MAIS JOGADORES...');W.querySelector('.lbar i').style.animation='tpa 5s linear forwards';
  $('#lobby').hidden=true;W.hidden=false;
  PM.at(()=>{W.hidden=true;if(S.gm=='br')PM.pre();else{setMode('game');G.begin()}},5000)},
 pre(){G.clear();G.ph='';$('#bj').textContent='Pular';setMode('game');G.hud(1);$('#gi').style.display='none';PM.on=1;PM.t=30;PM.cls()},
 end(){const T=$('#tp');$('#tpt').textContent=TIPS[Math.random()*TIPS.length|0];T.hidden=false;
  PM.at(()=>{T.hidden=true;$('#wt').hidden=false},3200);
  PM.at(()=>{$('#wt').hidden=true;G.begin();AM.n=AM.max;AM.rl=0;AM.ui();PM.cls()},6200)},
 tick(dt){if(AM.rl>0&&(AM.rl-=dt)<=0){AM.rl=0;AM.n=AM.max;AM.ui()}
  if(!PM.on)return;G.fcd-=dt;if((G.fire||keys.f)&&!ICE.ph&&G.fcd<=0&&AM.can()){G.fcd=.17;AM.use();beep(300,.05)}
  PM.t-=dt;$('#pt').textContent='00:'+String(Math.max(0,Math.ceil(PM.t))).padStart(2,'0');if(PM.t<=0){PM.on=0;PM.end()}},
 cls(){if(mode!='game')return;const h=$('#hud'),m=G.on&&G.m=='br',a=G.on&&G.ph&&G.ph!='ground';
  h.classList.toggle('mt',!!m);h.classList.toggle('air',!!a);h.classList.toggle('pr',!!PM.on);
  $('#vm').innerHTML=`<b>Vivos ${PM.on?51:G.e.filter(e=>e.a).length+(PL.a?1:0)}</b><u>Mortes ${PL.k}</u>`;
  const d=((-P.yaw*57.3)%360+360)%360;$('#cp').textContent=['N','NE','L','SE','S','SO','O','NO'][Math.round(d/45)%8]+' '+Math.round(d)+'°';
  const r=Math.max(0,30-G.zt);$('#zb').innerHTML=r>0?`⚠ A zona segura fechará em <b>${String(r/60|0).padStart(2,'0')}:${String(Math.ceil(r)%60).padStart(2,'0')}</b>`:'⚠ A zona está fechando';
  $('#hpn').textContent='HP '+Math.ceil(PL.hp)+'/100';$('#hps').style.width=Math.max(0,PL.hp)+'%'}};
setInterval(()=>PM.cls(),250);
$('#br').onpointerdown=()=>{P.run=!P.run;$('#br').classList.toggle('on',P.run);beep(400,.05)};
$('#bp').onpointerdown=()=>{P.pr=!P.pr;if(P.pr){P.cr=false;$('#bc').classList.remove('on')}$('#bp').classList.toggle('on',P.pr);beep(260,.05)};
$('#bs').onpointerdown=()=>AM.reload();
$('#bz').onpointerdown=()=>{const z=cam.fov>50;cam.fov=z?35:60;cam.updateProjectionMatrix();$('#bz').classList.toggle('on',z);beep(500,.04)};
addEventListener('keydown',e=>{if(mode!='game')return;if(e.key=='r')AM.reload();if(e.key=='z')$('#bp').onpointerdown()});
// ---------- lente da luneta: o zoom aparece só dentro do círculo; fora dele o mundo fica normal ----------
const LENS={rt:null};
function lensInit(){const rt=new T.WebGLRenderTarget(768,768,{minFilter:T.LinearFilter,magFilter:T.LinearFilter,format:T.RGBAFormat});
 const m=new T.Mesh(new T.CircleGeometry(1,72),new T.MeshBasicMaterial({map:rt.texture,toneMapped:false,depthTest:false,depthWrite:false})),o=new T.Scene();o.add(m);
 Object.assign(LENS,{rt,m,o,c:new T.OrthographicCamera(-1,1,1,-1,-1,1)})}
function renderFrame(){if(!(window.__scoped&&mode=='game')){R.render(sc,cam);return}
 if(!LENS.rt)lensInit();const w=innerWidth,h=innerHeight,fz=cam.fov,as=cam.aspect;
 cam.aspect=1;cam.updateProjectionMatrix();R.setRenderTarget(LENS.rt);R.render(sc,cam);R.setRenderTarget(null);
 cam.aspect=as;cam.fov=60;cam.updateProjectionMatrix();R.render(sc,cam);
 const c=LENS.c;c.left=-w/2;c.right=w/2;c.top=h/2;c.bottom=-h/2;c.updateProjectionMatrix();LENS.m.scale.set(h*.3,h*.3,1);LENS.m.position.set(0,h*.04,0);
 R.autoClear=false;R.render(LENS.o,c);R.autoClear=true;
 cam.fov=fz;cam.updateProjectionMatrix()}
// ---------- loop ----------
let last=0,fc=0,ft=0,mf=0;
function loop(now){requestAnimationFrame(loop);const lim=1000/S.fps;if(now-last<lim-3)return;const dt=Math.min(.05,(now-last)/1000);last=now;t+=dt;
 if(mode=='lobby'){if(window.__fpv){me.visible=true;window.__fpv=0}anim(me,t,0,false);ring.rotation.z+=dt*.5}else{update(dt);G.tick(dt);PM.tick(dt);ICE.tick(dt);if(++mf%3==0)minimap()}
 fc++;ft+=dt;if(ft>=1){$('#fps').textContent=S.showfps?fc+' FPS':'';fc=0;ft=0}
 renderFrame()}
// ---------- PAREDE DE GELO: botão no HUD, prévia, colisão, vida, tempo de vida, loot, efeitos e sons ----------
/*ICE-PURE*/
const icRay=(o,d,w,mx=1e9)=>{let a=0,b=mx;for(const[p,q,lo,hi]of[[o.x,d.x,w.x-w.hw,w.x+w.hw],[o.y,d.y,w.y,w.y+w.h],[o.z,d.z,w.z-w.hd,w.z+w.hd]]){if(Math.abs(q)<1e-9){if(p<lo||p>hi)return -1}else{let u=(lo-p)/q,v=(hi-p)/q;if(u>v){const x=u;u=v;v=x}a=Math.max(a,u);b=Math.min(b,v);if(a>b)return -1}}return a};
const icSeg=(x0,z0,x1,z1,w)=>icRay({x:x0,y:w.y+1.2,z:z0},{x:x1-x0,y:0,z:z1-z0},w,1)>=0;
const icNear=(x,z,hw,hd,px,pz)=>Math.hypot(Math.max(Math.abs(px-x)-hw,0),Math.max(Math.abs(pz-z)-hd,0));
/*ICE-END*/
Object.assign(SFX,{
 ice(){if(!S.vol)return;const a=ac();if(!a)return;const t=a.currentTime,w=S.vol;SFX.ns(a,t,5000,.5,.35,.35*w,'highpass');[2400,3100,3900,4800].forEach((f,i)=>SFX.tone(a,t+i*.05,f,f*.8,.25,.12*w,'triangle'));SFX.tone(a,t,300,90,.3,.3*w)},
 shatter(k=1){if(!S.vol)return;const a=ac();if(!a)return;const t=a.currentTime,w=S.vol*k;SFX.ns(a,t,4500,.4,.5,.5*w,'highpass');for(let i=0;i<7;i++){const f=1500+Math.random()*3500;SFX.tone(a,t+Math.random()*.25,f,f*.6,.12,.1*w,'triangle')}SFX.tone(a,t,200,60,.2,.3*w)},
 crack(){if(!S.vol)return;const a=ac();if(!a||a.currentTime-(SFX.lc||0)<.05)return;SFX.lc=a.currentTime;SFX.ns(a,a.currentTime,4200,1.2,.06,.25*S.vol)},
 deny(){if(!S.vol)return;const a=ac();if(a)SFX.tone(a,a.currentTime,200,150,.12,.2*S.vol,'square')},
 pick(){if(!S.vol)return;const a=ac();if(!a)return;const t=a.currentTime;SFX.tone(a,t,700,1400,.15,.2*S.vol,'triangle');SFX.tone(a,t+.08,1050,2100,.15,.15*S.vol,'triangle')}});
const ICE={cfg:{start:3,max:9,cd:3,hp:300,life:30,len:4,h:2.6,thick:.5,build:.35,pickups:8,pick:1,drop:.5,dist:5,dmin:2.5,dmax:9,maxWalls:10},
 n:3,cd:0,ph:0,flip:0,dist:5,w:[],pk:[],fx:[],key:null,id:0,uk:'',pp:null,
 emit(ev,a,b){},// gancho: ao existir multiplayer, envie aqui place/dmg/kill/pick (id, x, z, rot, hp) para os outros jogadores
 tex(){if(ICE.tx)return ICE.tx;const cv=document.createElement('canvas');cv.width=cv.height=64;const x=cv.getContext('2d'),C=['#8fdcff','#a9e8ff','#6cc8f0','#c6f3ff','#7fd3f5'],cl=v=>Math.max(0,Math.min(62,v));
  for(let j=0;j<8;j++)for(let i=0;i<8;i++){x.fillStyle=C[(vhash(i,j,5)*5)|0];x.fillRect(i*8,j*8,8,8);if(vhash(i,j,9)>.8){x.fillStyle='rgba(255,255,255,.7)';x.fillRect(i*8+2,j*8+2,3,3)}}
  for(const[col,o]of[['rgba(20,90,150,.65)',1],['rgba(255,255,255,.9)',0]])for(let k=0;k<4;k++){x.fillStyle=col;let a=((vhash(k,1,3+o)*60)|0)&~1,b=((vhash(k,2,4+o)*60)|0)&~1;for(let q=0;q<16;q++){x.fillRect(a,b,2,2);a=cl(a+(vhash(q,k,7+o)>.5?2:-2));b=cl(b+(vhash(q,k,8+o)>.35?2:0)-(vhash(q,k,2+o)>.8?2:0))}}
  const t=new T.CanvasTexture(cv);t.magFilter=t.minFilter=T.NearestFilter;t.generateMipmaps=false;return ICE.tx=t},
 place(x,z,y,rot,own){const c=ICE.cfg;if(ICE.w.length>=c.maxWalls)ICE.kill(ICE.w[0],'old');
  const L=c.len,H=c.h,Th=c.thick,hw=rot?Th/2:L/2,hd=rot?L/2:Th/2,w={id:++ICE.id,x,z,y,rot,hw,hd,h:H,hp:c.hp,max:c.hp,t:0,fl:0,own,g:new T.Group()},
  body=new T.MeshLambertMaterial({map:ICE.tex(),color:0xbfefff,emissive:0x1a78b0,transparent:true,opacity:.78}),glow=new T.MeshBasicMaterial({color:0x3de0ff,transparent:true,opacity:.7,blending:T.AdditiveBlending,depthWrite:false}),edge=new T.LineBasicMaterial({color:0x9ff3ff,transparent:true,fog:false}),g=w.g,u=g.userData;
  const bm=vp(g,vbox(L,H,Th),body,0,H/2,0);bm.add(new T.LineSegments(ICE.eg(),edge));vp(g,vbox(L*.92,H*.9,Th*.45),glow,0,H/2,0).castShadow=false;
  for(const[cx,ch,cy]of[[-1.3,.5,.2],[.2,.8,.3],[1.4,.4,.15]])vp(g,vbox(.4,ch,.4),body,cx,H+cy-.1,0).rotation.y=.4;
  ICE.sm=ICE.sm||M(0xeaffff);for(const q of[[-1.7,.12,.35],[1.2,.1,-.35],[-.4,.1,.38],[1.8,.12,-.3]])vp(g,vbox(.25,.2,.25),ICE.sm,...q);
  const pa=new Float32Array(42),pg=new T.BufferGeometry();for(let k=0;k<14;k++){pa[k*3]=(Math.random()-.5)*L;pa[k*3+1]=Math.random()*H;pa[k*3+2]=(Math.random()-.5)*1}
  pg.setAttribute('position',new T.BufferAttribute(pa,3));ICE.snm=ICE.snm||new T.PointsMaterial({color:0xffffff,size:.12,transparent:true,opacity:.9,fog:false});const sn=new T.Points(pg,ICE.snm);sn.frustumCulled=false;g.add(sn);
  Object.assign(u,{body,glow,edge,pos:pa,pg});g.position.set(x,y,z);g.rotation.y=rot?Math.PI/2:0;g.scale.y=.04;sc.add(g);
  w.s={x,z,hw,hd,h:y+H,ice:1};solids.push(w.s);ICE.w.push(w);ICE.burst(x,y+.3,z,24,hw,hd,6,0);ICE.burst(x,y+.5,z,10,hw,hd,2,1);SFX.ice();ICE.emit('place',w);return w},
 eg(){return ICE.egm||(ICE.egm=new T.EdgesGeometry(vbox(ICE.cfg.len,ICE.cfg.h,ICE.cfg.thick)))},
 dmg(w,d,pt){if(!w||w.hp<=0)return;w.hp-=d;w.fl=.12;const q=pt||{x:w.x+rr(w.hw),y:w.y+1.2,z:w.z+rr(w.hd)};ICE.burst(q.x,q.y,q.z,4,.1,.1,3,0);SFX.crack();ICE.emit('dmg',w);if(w.hp<=0)ICE.kill(w,'dmg')},// também serve para explosivos: ICE.dmg(parede, dano)
 kill(w,why){const i=ICE.w.indexOf(w);if(i<0)return;ICE.w.splice(i,1);const j=solids.indexOf(w.s);if(j>=0)solids.splice(j,1);sc.remove(w.g);const u=w.g.userData;u.body.dispose();u.glow.dispose();u.edge.dispose();u.pg.dispose();
  const ex=why=='exp',m=Math.max(w.hw,w.hd);if(why!='old'){ICE.burst(w.x,w.y+1.3,w.z,ex?10:30,w.hw,w.hd,ex?3:7,0);ICE.burst(w.x,w.y+1.3,w.z,ex?6:16,w.hw,w.hd,2.5,1);SFX.shatter(ex?.4:1)}ICE.emit('kill',w,why)},
 burst(x,y,z,n,hx,hz,v,sn){if(!ICE.mf){ICE.mf=new T.MeshBasicMaterial({color:0x8fe8ff,transparent:true,opacity:.9});ICE.mw=new T.MeshBasicMaterial({color:0xffffff})}
  for(let i=0;i<n&&ICE.fx.length<90;i++){const z0=sn?.09:[.14,.2,.28][i%3],m=new T.Mesh(vbox(z0,z0,z0),sn?ICE.mw:ICE.mf);m.position.set(x+(Math.random()-.5)*2*hx,y+(Math.random()-.5)*1.2,z+(Math.random()-.5)*2*hz);sc.add(m);
   ICE.fx.push({m,vx:(Math.random()-.5)*v,vy:1.5+Math.random()*v*.7,vz:(Math.random()-.5)*v,l:.8+Math.random()*.7})}},
 free(x,z,hw,hd,y){const L=G.lim-2;if(Math.abs(x)>L||Math.abs(z)>L)return false;if(window.ISL&&ISL.on&&ISL.blocked(x,z,hw,hd,y))return false;
  for(const s of solids)if(Math.abs(x-s.x)<hw+s.hw+.05&&Math.abs(z-s.z)<hd+s.hd+.05&&y<s.h-.15)return false;
  for(const k of trees)if(icNear(x,z,hw,hd,k.x,k.z)<k.r+.15)return false;
  if(icNear(x,z,hw,hd,P.x,P.z)<.7)return false;for(const e of G.e)if(e.a&&icNear(x,z,hw,hd,e.x,e.z)<.7)return false;return true},
 ray(r){let b=null;for(const w of ICE.w){if(w.t<.1)continue;const d=icRay(r.origin,r.direction,w);if(d>=0&&(!b||d<b.d))b={w,d}}if(b)b.p=r.at(b.d,new T.Vector3());return b},
 seg(x0,z0,x1,z1){for(const w of ICE.w)if(w.t>.1&&icSeg(x0,z0,x1,z1,w))return w;return null},
 press(){const c=ICE.cfg;if(!(mode=='game'&&(!G.ph||G.ph=='ground')&&!G.dead))return;if(ICE.ph){ICE.cancel();beep(300,.05);return}if(ICE.n<=0)return ICE.deny('Sem gelo');if(ICE.cd>0)return ICE.deny('Recarregando');ICE.ph=1;ICE.flip=0;ICE.dist=c.dist;ICE.fb();ICE.toast('Toque em ATIRAR para colocar','#7fe9ff');beep(900,.05)},
 confirm(){const p=ICE.pp;if(!p||!p.ok)return ICE.deny('Local inválido');ICE.place(p.x,p.z,p.y,p.rot,0);ICE.n--;ICE.cd=ICE.cfg.cd;ICE.cancel()},
 cancel(){ICE.ph=0;if(ICE.pg)ICE.pg.visible=false;ICE.fb()},
 ico:"<svg viewBox='0 0 46 46'><path d='M5 40V16l6-5 6 4 6-7 6 6 6-4 6 5v25z' fill='#e8fbff' stroke='#0b5e94' stroke-width='2.5' stroke-linejoin='round'/><path d='M5 40V16l6-5v29z' fill='#9fe6ff'/><path d='M17 15l6-7v32h-6z' fill='#6cc8f0' opacity='.7'/><path d='M13 20l4 5-3 5 4 5M30 18l-3 6 4 4-3 8' fill='none' stroke='#2a86bd' stroke-width='1.6'/></svg>",
 // o botão Atirar vira um ícone de gelo enquanto a parede está sendo posicionada
 fb(){const f=$('#bf'),on=f.classList.contains('ice');if(ICE.ph&&!on){f.dataset.t=f.innerHTML;f.innerHTML=ICE.ico;f.classList.add('ice')}else if(!ICE.ph&&on){f.innerHTML=f.dataset.t;f.classList.remove('ice')}},
 deny(m){SFX.deny();ICE.toast(m,'#ff4d5e')},
 toast(m,c='#fff'){const d=document.createElement('div');d.className='itz';d.textContent=m;d.style.color=c;$('#hud').appendChild(d);setTimeout(()=>d.remove(),1400)},
 mkPk(x,z){const g=new T.Group(),c=vbox(.36,.36,.36);ICE.pkm=ICE.pkm||new T.MeshBasicMaterial({color:0x6fe6ff});ICE.pkl=ICE.pkl||new T.LineBasicMaterial({color:0xffffff});ICE.pkb=ICE.pkb||new T.MeshBasicMaterial({color:0x3de0ff,transparent:true,opacity:.35,blending:T.AdditiveBlending,depthWrite:false});
  const b=new T.Mesh(c,ICE.pkm);b.rotation.set(.6,0,.6);b.add(new T.LineSegments(new T.EdgesGeometry(c),ICE.pkl));g.add(b);const bm=new T.Mesh(vbox(.1,2.4,.1),ICE.pkb);bm.position.y=1.2;g.add(bm);g.position.set(x,0,z);sc.add(g);ICE.pk.push({g,x,z,t:Math.random()*6})},
 spawnPk(){const L=G.lim-6;for(let i=0;i<ICE.cfg.pickups;i++)for(let k=0;k<20;k++){const x=rr(L),z=rr(L);if(ICE.free(x,z,.4,.4,0)&&Math.hypot(x-P.x,z-P.z)>6){ICE.mkPk(x,z);break}}},
 drop(x,z){if(Math.random()<ICE.cfg.drop&&ICE.pk.length<40)ICE.mkPk(x,z)},
 clearPk(){ICE.pk.forEach(p=>sc.remove(p.g));ICE.pk=[]},
 reset(){ICE.cancel();for(const w of ICE.w.slice())ICE.kill(w,'old');ICE.fx.forEach(f=>sc.remove(f.m));ICE.fx=[];ICE.clearPk();ICE.n=ICE.cfg.start;ICE.cd=0;ICE.key=null},
 ui(){const k=ICE.n+'|'+Math.ceil(ICE.cd*10)+'|'+ICE.ph;if(k==ICE.uk)return;ICE.uk=k;const b=$('#bi'),cd=ICE.cd;$('#bin').textContent=ICE.n;b.classList.toggle('z',ICE.n<=0);b.classList.toggle('pl',!!ICE.ph);$('#bic').style.background=cd>0?`conic-gradient(rgba(5,12,30,.75) ${cd/ICE.cfg.cd*360}deg,transparent 0)`:'none';$('#bit').textContent=cd>0?cd.toFixed(1):''},
 tick(dt){const c=ICE.cfg,key=G.city?'c':'w';
  if(ICE.key!=key){ICE.key=key;ICE.clearPk();ICE.spawnPk()}
  if(ICE.cd>0)ICE.cd=Math.max(0,ICE.cd-dt);
  if(ICE.ph&&(G.dead||(G.ph&&G.ph!='ground')))ICE.cancel();
  for(let i=ICE.w.length-1;i>=0;i--){const w=ICE.w[i],u=w.g.userData;w.t+=dt;if(w.t>=c.life){ICE.kill(w,'exp');continue}
   const b=Math.min(1,w.t/c.build),e=1-(1-b)**3,fd=Math.min(1,(c.life-w.t)/1.5),hr=w.hp/w.max;w.fl=Math.max(0,w.fl-dt);
   w.g.scale.y=.04+.96*e;u.body.opacity=(.5+.28*hr)*fd*(.35+.65*e);u.glow.opacity=Math.max(0,(.2+.6*(1-b)+.06*Math.sin(w.t*3)+w.fl*3)*fd);u.edge.opacity=fd;
   const pa=u.pos;for(let k=0;k<14;k++){pa[k*3+1]+=dt*(.25+.1*(k%3));if(pa[k*3+1]>c.h)pa[k*3+1]=0}u.pg.attributes.position.needsUpdate=true}
  if(ICE.ph){if(!ICE.pg){const g=new T.Group();ICE.pm=new T.MeshBasicMaterial({color:0x58ff9a,transparent:true,opacity:.32,depthWrite:false});ICE.pe=new T.LineBasicMaterial({color:0x58ff9a,fog:false});const b=new T.Mesh(vbox(c.len,c.h,c.thick),ICE.pm);b.position.y=c.h/2;b.add(new T.LineSegments(ICE.eg(),ICE.pe));g.add(b);sc.add(g);ICE.pg=g}
   const yw=P.yaw,rot=(Math.abs(Math.sin(yw))>Math.abs(Math.cos(yw))?1:0)^ICE.flip,L=G.lim-2,x=Math.max(-L,Math.min(L,P.x-Math.sin(yw)*ICE.dist)),z=Math.max(-L,Math.min(L,P.z-Math.cos(yw)*ICE.dist)),hw=rot?c.thick/2:c.len/2,hd=rot?c.len/2:c.thick/2,y=P.gr?P.y:0,ok=ICE.free(x,z,hw,hd,y);
   ICE.pg.visible=true;ICE.pg.position.set(x,y,z);ICE.pg.rotation.y=rot?Math.PI/2:0;ICE.pm.color.set(ok?0x58ff9a:0xff4d5e);ICE.pe.color.set(ok?0x58ff9a:0xff4d5e);ICE.pp={x,z,y,rot,ok}}
  const can=(!G.ph||G.ph=='ground')&&!G.dead;
  for(let i=ICE.pk.length-1;i>=0;i--){const p=ICE.pk[i],m=p.g.children[0];p.t+=dt;m.position.y=.75+Math.sin(p.t*2.5)*.12;m.rotation.y=p.t*2;
   if(can&&ICE.n<c.max&&Math.hypot(P.x-p.x,P.z-p.z)<1.6){sc.remove(p.g);ICE.pk.splice(i,1);ICE.n=Math.min(c.max,ICE.n+c.pick);SFX.pick();ICE.toast('+'+c.pick+' ❄️ Gelo','#7fe9ff');ICE.emit('pick',p)}}
  for(let i=ICE.fx.length-1;i>=0;i--){const f=ICE.fx[i],m=f.m;f.l-=dt;if(f.l<=0){sc.remove(m);ICE.fx.splice(i,1);continue}f.vy-=14*dt;m.position.x+=f.vx*dt;m.position.y+=f.vy*dt;m.position.z+=f.vz*dt;
   if(m.position.y<.1){m.position.y=.1;f.vy*=-.3;f.vx*=.6;f.vz*=.6}m.rotation.x+=dt*5;m.rotation.z+=dt*4;m.scale.setScalar(Math.max(.01,Math.min(1,f.l/.4)))}
  ICE.ui()}};
{const st=document.createElement('style');st.textContent=`#bf.ice{background:radial-gradient(circle at 35% 30%,#fff 0,#7fe3ff 45%,#1b8fd0 100%);border-color:#bff4ff;box-shadow:0 0 18px rgba(61,224,255,.8),inset 0 0 8px #fff}#bf.ice svg{width:56px;height:56px}#bi{right:198px;bottom:calc(44px + env(safe-area-inset-bottom));border-color:#bff4ff;background:radial-gradient(circle at 35% 30%,#fff 0,#7fe3ff 45%,#1b8fd0 100%);box-shadow:0 0 14px rgba(61,224,255,.7),inset 0 0 8px #fff;transition:transform .08s,filter .2s;touch-action:none}
#bi:active{transform:scale(.86)}#bi.pl{background:radial-gradient(circle at 35% 30%,#fff 0,#9dffd0 45%,#1bd07a 100%);box-shadow:0 0 18px #58ff9a,inset 0 0 8px #fff}#bi.z{filter:grayscale(.85) brightness(.7)}#bi svg{position:absolute;left:11px;top:11px;width:42px;height:42px}
#bin{position:absolute;right:-6px;bottom:-6px;min-width:24px;height:24px;border-radius:12px;background:#0b1430;border:2px solid #bff4ff;color:#fff;font:700 17px/20px var(--f);text-align:center;pointer-events:none}
#bic{position:absolute;inset:0;border-radius:50%;pointer-events:none}#bit{position:absolute;inset:0;display:grid;place-items:center;font:700 22px var(--f);color:#fff;text-shadow:0 0 4px #000;pointer-events:none}
#ip{position:absolute;left:50%;top:16%;transform:translateX(-50%);display:flex;gap:10px}#ip button{width:52px;height:52px;border-radius:50%;background:rgba(11,20,48,.82);border:3px solid var(--volt);font-size:22px;touch-action:none}#ip button:active{transform:scale(.88)}#ip .ok{background:#1bb86b;border-color:#bfffe0}#ip .no{border-color:var(--red)}
@keyframes tz{0%{opacity:0;transform:translate(-50%,10px)}15%{opacity:1;transform:translate(-50%,0)}80%{opacity:1}100%{opacity:0;transform:translate(-50%,-14px)}}.itz{position:absolute;left:50%;top:30%;font:700 26px var(--f);text-shadow:0 0 6px #000;pointer-events:none;animation:tz 1.3s forwards}`;document.head.appendChild(st);
 const h=$('#hud'),b=document.createElement('button');b.id='bi';b.className='act gb';b.innerHTML=`<svg viewBox='0 0 46 46'><path d='M5 40V16l6-5 6 4 6-7 6 6 6-4 6 5v25z' fill='#e8fbff' stroke='#0b5e94' stroke-width='2.5' stroke-linejoin='round'/><path d='M5 40V16l6-5v29z' fill='#9fe6ff'/><path d='M17 15l6-7v32h-6z' fill='#6cc8f0' opacity='.7'/><path d='M13 20l4 5-3 5 4 5M30 18l-3 6 4 4-3 8' fill='none' stroke='#2a86bd' stroke-width='1.6'/></svg><i id='bic'></i><span id='bit'></span><b id='bin'>3</b>`;h.appendChild(b);
 b.addEventListener('pointerdown',e=>{e.preventDefault();ICE.press()});}
setChar();{// roda de emotes: toque no personagem para abrir; 6 casas (2 danças prontas)
const EM=[[1,'💃','Dança'],[2,'👋','Aceno'],[0],[0],[0],[0]],w=document.createElement('div'),R=100,r=44,Pt=(a,q)=>[110+q*Math.sin(a),110-q*Math.cos(a)];
w.hidden=true;w.style.cssText='position:absolute;inset:0;z-index:7;pointer-events:auto;background:rgba(3,8,22,.35)';$('#lobby').appendChild(w);
let ot=0;const ok=()=>!w.hidden&&performance.now()-ot>500,close=()=>{w.hidden=true},draw=()=>{const cur=me.userData.emote|0;let h='';
 EM.forEach((m,i)=>{const a0=i*Math.PI/3-Math.PI/6,a1=a0+Math.PI/3,[x0,y0]=Pt(a0,R),[x1,y1]=Pt(a1,R),[x2,y2]=Pt(a1,r),[x3,y3]=Pt(a0,r),[tx,ty]=Pt((a0+a1)/2,72),on=m[0]&&m[0]==cur;
  h+=`<g data-i=${i} style='pointer-events:auto;cursor:pointer'><path d='M${x0} ${y0}A${R} ${R} 0 0 1 ${x1} ${y1}L${x2} ${y2}A${r} ${r} 0 0 0 ${x3} ${y3}Z' fill='${on?'#ffc233':m[0]?'rgba(20,16,44,.88)':'rgba(20,16,44,.55)'}' stroke='#0b1430' stroke-width=2.5 />`+
  (m[0]?`<text x=${tx} y=${ty+2} text-anchor=middle font-size=26>${m[1]}</text><text x=${tx} y=${ty+16} text-anchor=middle font-size=8 font-weight=700 fill='${on?'#1a1000':'#fff'}'>${m[2].toUpperCase()}</text>`:`<text x=${tx} y=${ty+6} text-anchor=middle font-size=18 fill='rgba(255,255,255,.3)'>＋</text>`)+`</g>`});
 w.innerHTML=`<svg viewBox='0 0 220 220' style='position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(88vh,80vw);pointer-events:none;overflow:visible'><circle cx=110 cy=110 r=${R+3} fill='rgba(0,0,0,.35)'/>${h}</svg>`;
 w.querySelectorAll('g').forEach(g=>g.onclick=e=>{e.stopPropagation();if(!ok())return;const m=EM[g.dataset.i];if(!m[0]){beep(220,.05);return}const u=me.userData;u.emote=u.emote==m[0]?0:m[0];beep(660,.06);close()})};
w.onclick=e=>{if(e.target===w&&ok()){beep(330,.05);close()}};
const z=$('#rz');let d0=null;z.addEventListener('pointerdown',e=>{d0=[e.clientX,e.clientY]});
z.addEventListener('pointerup',e=>{if(!d0||mode!='lobby')return;const m=Math.hypot(e.clientX-d0[0],e.clientY-d0[1]);d0=null;if(m>8)return;
 rc.setFromCamera({x:e.clientX/innerWidth*2-1,y:-(e.clientY/innerHeight*2-1)},cam);if(rc.intersectObject(me,true).length){draw();ot=performance.now();w.hidden=false;beep(660,.05)}})}applyQ();refresh();setMode('lobby');requestAnimationFrame(loop);

// ---------- perfil do jogador (toque no nome) ----------
Object.assign(MENU,{perfil(){
 const c=$('#pf'),L=$('#lobby');let tab='gal',sub=0;
 const NAV=[['gal','Galeria'],['vis','Visão geral',['Battle Royale','Contra Squad','Tempo limitado']],['fun','Função',['BR ranqueado','CS ranqueado']],['his','Histórico'],['arm','Armas'],['alb','Álbum',['Destaque','Meus vídeos','Minhas fotos']],['cre','Credibilidade da conta'],['des','Lista de desejos']];
 const em=t=>`<p class=pfe>${t}</p>`;
 const radar=()=>{const n=['Curandeiro','Voraz','Parceria','Confiável','Líder'],v=[.6,.5,.5,.5,.6],pt=(i,r)=>{const a=-Math.PI/2+i*2*Math.PI/5;return[100+Math.cos(a)*r,100+Math.sin(a)*r]};
  return `<svg viewBox='0 0 200 200' class=rd>${[1,.66,.33].map(k=>`<polygon points='${n.map((_,i)=>pt(i,70*k).join(',')).join(' ')}' fill=none stroke='rgba(255,255,255,.25)'/>`).join('')}<polygon points='${v.map((x,i)=>pt(i,70*x).join(',')).join(' ')}' fill='rgba(255,194,51,.35)' stroke='#ffc233' stroke-width=2 />${n.map((t,i)=>{const[x,y]=pt(i,92);return `<text x=${x} y=${y} fill='#fff' font-size=10 text-anchor=middle>${t}</text>`}).join('')}</svg>`};
 const ic=d=>`<svg width=20 height=20 viewBox='0 0 24 24' fill=none stroke=#fff stroke-width=2 stroke-linecap=round stroke-linejoin=round>${d}</svg>`,
 AV=`<svg width='70%' viewBox='0 0 24 24' fill=#fff><circle cx=12 cy=8 r=4 /><path d='M4 21c0-4 4-6 8-6s8 2 8 6z' /></svg>`,
 CO=`<i style='display:inline-block;width:12px;height:12px;border-radius:50%;background:#ffc233;margin-right:6px'></i>`,
 DI=`<i style='display:inline-block;width:10px;height:10px;transform:rotate(45deg);background:#3de0ff;margin:0 8px 0 2px'></i>`,
 TC=['#cd7f32','#c0c7d1','#ffc233','#7fe0d0','#6fb7ff','#c06bff','#ff5d73'],
 medal=(p,n)=>{const col=TC[p>=1800?6:p/300|0];return `<svg width=44 height=50 viewBox='0 0 44 50'><defs><linearGradient id=mg${n} x1=0 y1=0 x2=1 y2=1><stop offset=0 stop-color='#fff' stop-opacity=.7 /><stop offset=.35 stop-color='${col}' /><stop offset=1 stop-color='#000' stop-opacity=.55 /></linearGradient></defs><polygon points='22,2 41,13 41,37 22,48 3,37 3,13' fill='url(#mg${n})' stroke='${col}' stroke-width=2 /><polygon points='22,9 35,16 35,34 22,41 9,34 9,16' fill=none stroke='rgba(255,255,255,.55)' /><path d='M14 28l8-9 8 9M14 33l8-9 8 9' fill=none stroke='#fff' stroke-width=2.5 stroke-linecap=round stroke-linejoin=round opacity=.9 /></svg>`},
 row=(a,b)=>`<div class=sr><span>${a}</span><b>${b}</b></div>`;
 const PG={
  gal:()=>`<div class=pfr><button>${ic(`<rect x=3 y=7 width=18 height=13 rx=2 /><circle cx=12 cy=13 r=3.5 />`)}</button><button>${ic(`<circle cx=12 cy=8 r=4 /><path d='M4 21c0-4 4-6 8-6s8 2 8 6' />`)}</button><button>${ic(`<rect x=3 y=3 width=7 height=7 /><rect x=14 y=3 width=7 height=7 /><rect x=3 y=14 width=7 height=7 /><path d='M14 14h3v3M21 14v7M14 21h3' />`)}</button><button>${ic(`<path d='M12 15V3M7 8l5-5 5 5M5 13v8h14v-8' />`)}</button></div><div class=pfc><div class=pfh><b class=pfl>VIOXAR <span>ROYALE</span></b><button class=pfg id=pfg>${ic(`<circle cx=12 cy=12 r=3 /><path d='M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1' />`)}</button></div><div class=pfb><div class=pfa>${AV}<small>Nv. 1</small></div><div class=pfi><b>${esc(S.name)}</b><span>Português</span><span>Curtidas: 0</span></div><small class=pfu>UID: ${S.id}</small></div><div class=pfs>⇌ ${GM[S.gm].n}</div><div class=pfm style='grid-template-columns:repeat(2,1fr)'><div>${medal(S.rp.br,0)}<small>${rk(S.rp.br)}</small></div><div>${medal(S.rp.cs,1)}<small>${rk(S.rp.cs)}</small></div></div></div></div>`,
  vis:()=>`<div class=pfv><div class=pfrd><div class=pft>SQUAD</div>${radar()}</div><div class=pfls>${row('Pontuação','0.0')+row('Quantidade de medalhas','0')+row('Reviveu','0')+row('Média de dano por partida','0')}</div></div>`,
  fun:()=>{const k=sub?'cs':'br';return `<h2 class=sth>${NAV[2][2][sub]}</h2>${row('Patente atual',rk(S.rp[k]))+row('Pontos',S.rp[k])}`},
  his:()=>`<div class=pfth><span>Resultado</span><span>Modo</span><span>Abate</span><span>Tempo</span></div>${em('Nenhuma partida registrada ainda.')}`,
  arm:()=>em('Nenhuma arma com estatísticas ainda.'),
  alb:()=>`<div class=pfab><span>FOTOS NORMAIS</span><span style='opacity:.6'>DESTAQUES</span></div>${em('Ainda sem foto. As fotos e capturas de tela que você salvar no jogo vão aparecer aqui.')}`,
  cre:()=>`<h2 class=sth>CREDIBILIDADE DA CONTA</h2>${row('Pontuação','100')}`,
  des:()=>em('Sua lista de desejos está vazia.')};
 const draw=()=>{const g=tab=='gal';c.className='ov'+(g?'':' dk');
  c.innerHTML=`<div class=z id=pz style='left:12%;width:34%'></div><div class=cmt><div class=prof><i class=av>${AV}</i><div style='display:flex;flex-direction:column;line-height:1'><b>${esc(S.name)}</b><small>ID ${S.id}</small></div></div><div class=cur><span>${CO}<b>${S.coins}</b></span><span>${DI}<b>${S.dia}</b></span></div><h1>PERFIL</h1></div><div class=pfn>${NAV.map(([k,n,s])=>`<button data-t=${k}${k==tab?' class=on':''}>${n}${s?(k==tab?' ▴':' ▾'):''}</button>${s&&k==tab?s.map((x,i)=>`<button class='sb${i==sub?' on':''}' data-s=${i}>${x}</button>`).join(''):''}`).join('')}</div><div class='pfp2${g?' g':''}'>${PG[tab]()}</div><button class=stx id=pfx>✕</button>`;
  c.querySelectorAll('.pfn button').forEach(b=>b.onclick=()=>{if(b.dataset.t){tab=b.dataset.t;sub=0}else sub=+b.dataset.s;beep(500,.05);draw()});
  if(g)drag($('#pz'),(e,dx)=>{me.rotation.y+=dx*.012});
  const gr=$('#pfg');gr&&(gr.onclick=()=>{$('#st').style.zIndex=7;MENU.set()});
  $('#pfx').onclick=()=>{c.hidden=true;L.hidden=false;cam.position.set(0,1.4,4.2);cam.lookAt(0,1.05,0);beep(330,.05)}};
 draw();L.hidden=true;c.hidden=false;cam.position.set(1.1,1.4,4.2);cam.lookAt(1.1,1.05,0);beep(660,.05)}});
$('#lobby .prof').onclick=()=>MENU.perfil();

// ---------- TELA DE NOVIDADES (popup de lançamento) ----------
// Para anunciar uma roupa nova: adicione um item em NEWS. Ele aparece sozinho 1x para o jogador e fica reabrível pelo banner do lobby.
// campos: id (único), tag (faixa de cima), sub (linha pequena), title (nome grande), rows ([[rótulo,valor],...]), gar (faixa amarela),
//         cta (texto do botão), go (função ao tocar no botão), art (SVG 100x150 do personagem), badge (selo, ex.: 'ATÉ 03/12'), pieces ([[nome,svg 40x40],...])
const NIC={
 head:`<rect x=9 y=7 width=22 height=11 fill=#0b0910 stroke=#8a2bff /><rect x=10 y=17 width=20 height=14 fill=#f0c8a0 /><rect x=13 y=21 width=6 height=3 fill=#d9a3ff /><rect x=22 y=21 width=6 height=3 fill=#d9a3ff /><rect x=10 y=26 width=20 height=6 fill=#0b0910 />`,
 mask:`<rect x=7 y=12 width=26 height=18 fill=#0b0910 stroke=#8a2bff /><rect x=10 y=17 width=7 height=3 fill=#d9a3ff /><rect x=23 y=17 width=7 height=3 fill=#d9a3ff /><rect x=7 y=22 width=26 height=2 fill=#8a2bff />`,
 torso:`<rect x=3 y=9 width=9 height=22 fill=#100c1a stroke=#8a2bff /><rect x=28 y=9 width=9 height=22 fill=#100c1a stroke=#8a2bff /><rect x=11 y=7 width=18 height=26 fill=#100c1a stroke=#8a2bff /><polygon points='15,24 16,17 18,20 20,15 22,20 24,17 25,24' fill=#c06bff /><rect x=11 y=7 width=18 height=3 fill=#0b0910 />`,
 legs:`<rect x=9 y=5 width=10 height=30 fill=#0b0910 stroke=#8a2bff /><rect x=21 y=5 width=10 height=30 fill=#0b0910 stroke=#8a2bff /><rect x=10 y=8 width=2 height=24 fill=#c06bff /><rect x=28 y=8 width=2 height=24 fill=#c06bff /><rect x=9 y=5 width=22 height=4 fill=#1c1730 />`,
 shoe:`<path d='M5 14h12v8l16 4v6H5z' fill=#0b0910 stroke=#8a2bff /><rect x=4 y=31 width=30 height=4 fill=#fff /><rect x=7 y=17 width=7 height=3 fill=#c06bff /><rect x=24 y=24 width=8 height=3 fill=#c06bff />`};
const NEWS=[
 {id:'sombra2',tag:'NOVO NO SORTE ROYALE',sub:'CONJUNTO LENDÁRIO',title:'SOMBRA REAL',
  rows:[['RARIDADE','LENDÁRIA'],['ONDE ENCONTRAR','SORTE ROYALE']],gar:'PRÊMIO MÁXIMO · GARANTIDO NO 215º GIRO',
  cta:'TENTAR A SORTE',go:()=>MENU.sorte(),art:()=>sbThumb(),badge:'NO SORTE ROYALE',
  pieces:[['CABEÇA',NIC.head],['MÁSCARA',NIC.mask],['TORSO',NIC.torso],['PERNAS',NIC.legs],['CALÇADO',NIC.shoe]]}];
const NEWSUI={el:$('#nv'),cur:null,
 css(){const st=document.createElement('style');st.textContent=`#nv{pointer-events:auto;z-index:8;display:flex;align-items:center;justify-content:center}.nvb{position:absolute;inset:0;background:rgba(3,2,14,.72);backdrop-filter:blur(3px)}
.nvp{--h:min(86vh,calc(92vw/1.7));position:relative;height:var(--h);width:calc(var(--h)*1.7);background:radial-gradient(ellipse at 72% 40%,#7a2cd0 0,#3a1380 45%,#150738 100%);box-shadow:0 0 0 2px rgba(192,107,255,.5),0 0 60px rgba(138,43,255,.55);overflow:hidden;animation:nvin .28s ease-out}
@keyframes nvin{from{transform:scale(.85);opacity:0}}.nvp:before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(115deg,rgba(255,255,255,.035) 0 2px,transparent 2px 22px);pointer-events:none}
.nvx{position:absolute;right:calc(var(--h)*-.0);top:0;width:calc(var(--h)*.09);height:calc(var(--h)*.09);background:rgba(5,2,20,.85);border:2px solid #fff;font:700 calc(var(--h)*.055) var(--f);color:#fff;z-index:3;line-height:1}.nvx:active{background:var(--red)}
.nvl{position:absolute;left:4%;top:6%;width:56%;display:flex;flex-direction:column;align-items:center;text-align:center}
.nvt{background:linear-gradient(90deg,#4a1a9e,#a24dff,#4a1a9e);padding:0 4%;font:700 calc(var(--h)*.045) var(--f);letter-spacing:1px;transform:skewX(-8deg);border-bottom:2px solid #d9a3ff;white-space:nowrap}
.nvs{margin-top:2%;white-space:nowrap;font:italic 700 calc(var(--h)*.055) var(--f);letter-spacing:1px;text-shadow:0 2px 0 #14002e}
.nvh{white-space:nowrap;font:italic 700 calc(var(--h)*.13) var(--f);line-height:1;transform:skewX(-8deg);background:linear-gradient(#fff 8%,#e3b8ff 40%,#9b3cff 85%);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 3px 0 #14002e) drop-shadow(0 0 14px rgba(192,107,255,.8))}
.nvi{margin-top:2%;width:100%;border:2px solid #b36bff;border-radius:calc(var(--h)*.03);background:rgba(15,4,48,.6);padding:1% 4%}.nvi div{display:flex;justify-content:space-between;align-items:center;gap:4%;white-space:nowrap;font:600 calc(var(--h)*.048) var(--f);padding:calc(var(--h)*.01) 0}.nvi div+div{border-top:1px solid rgba(255,255,255,.25)}.nvi b{color:#ffc233;font-weight:700}
.nvg{margin-top:3%;width:104%;padding:calc(var(--h)*.01) 0;white-space:nowrap;background:linear-gradient(90deg,#ff9d2e,#ffe27a,#ff9d2e);color:#2a1700;font:700 calc(var(--h)*.04) var(--f);transform:skewX(-8deg);box-shadow:0 3px 0 #b57e00}
.nvc{margin-top:3%;width:90%;padding:calc(var(--h)*.012) 0;white-space:nowrap;background:linear-gradient(90deg,#4a1a9e,#8a2bff);border:0;border-bottom:3px solid #d9a3ff;font:700 calc(var(--h)*.06) var(--f);letter-spacing:1px;transform:skewX(-8deg);color:#fff}.nvc:active{filter:brightness(1.3)}
.nvr{position:absolute;right:3%;top:2%;width:34%;height:58%}.nvr svg{width:100%;height:100%;overflow:visible;filter:drop-shadow(0 0 18px rgba(192,107,255,.7))}
.nvd{position:absolute;right:3%;white-space:nowrap;background:linear-gradient(90deg,#a02a8f,#ff5dc8);padding:0 3%;font:700 calc(var(--h)*.042) var(--f);transform:skewX(-8deg);border:1px solid #ffc2ee}
.nvk{position:absolute;right:3%;bottom:3%;width:37%}.nvkt{background:linear-gradient(90deg,#ff9d2e,#ffe27a,#ff9d2e);color:#2a1700;text-align:center;font:700 calc(var(--h)*.032) var(--f);white-space:nowrap;transform:skewX(-8deg)}
.nvkr{display:flex;gap:2%;margin-top:3%}.nvkr div{flex:1;aspect-ratio:.82;background:linear-gradient(160deg,#3a1a6e,#120826);border:2px solid #b36bff;border-radius:6px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding:3% 0 0;overflow:hidden}.nvkr svg{width:80%;flex:1;min-height:0}.nvkr small{width:100%;text-align:center;background:rgba(0,0,0,.6);font:600 calc(var(--h)*.021) var(--f);white-space:nowrap;overflow:hidden}`;document.head.appendChild(st)},
 open(id){const n=NEWS.find(x=>x.id==id);if(!n)return;if(!NEWSUI.css.done){NEWSUI.css();NEWSUI.css.done=1}NEWSUI.cur=n;
  NEWSUI.el.innerHTML=`<div class=nvb></div><div class=nvp><button class=nvx>✕</button><div class=nvl><div class=nvt>${n.tag}</div><div class=nvs>${n.sub}</div><div class=nvh>${n.title}</div><div class=nvi>${n.rows.map(r=>`<div><span>${r[0]}</span><b>${r[1]}</b></div>`).join('')}</div><div class=nvg>${n.gar}</div><button class=nvc>${n.cta} ▶</button></div>
   <div class=nvr><svg viewBox='0 0 100 150' preserveAspectRatio='xMidYMax meet'>${n.art()}</svg></div>${n.badge?`<b class=nvd style='bottom:calc(var(--h)*.285)'>${n.badge}</b>`:''}<div class=nvk><div class=nvkt>O CONJUNTO INTEIRO: ${n.pieces.length} PEÇAS</div><div class=nvkr>${n.pieces.map(p=>`<div><svg viewBox='0 0 40 40'>${p[1]}</svg><small>${p[0]}</small></div>`).join('')}</div></div></div>`;
  NEWSUI.el.hidden=false;beep(780,.08);const c=()=>NEWSUI.close(0);NEWSUI.el.querySelector('.nvx').onclick=c;NEWSUI.el.querySelector('.nvb').onclick=c;
  NEWSUI.el.querySelector('.nvc').onclick=()=>NEWSUI.close(1)},
 close(go){const n=NEWSUI.cur;if(!n)return;NEWSUI.cur=null;NEWSUI.el.hidden=true;S.seen=S.seen||[];if(!S.seen.includes(n.id))S.seen.push(n.id);save();
  if(go){n.go&&n.go();beep(880,.1)}else beep(330,.05);setTimeout(NEWSUI.next,250)},
 // mostra a próxima novidade que o jogador ainda não viu (só no lobby)
 next(){if(NEWSUI.cur||mode!='lobby')return;NEWSUI.sh=NEWSUI.sh||[];const n=NEWS.find(x=>!NEWSUI.sh.includes(x.id));if(n){NEWSUI.sh.push(n.id);NEWSUI.open(n.id)}}};
document.querySelectorAll('[data-n]').forEach(b=>b.onclick=()=>NEWSUI.open(b.dataset.n));
$('#ib').addEventListener('click',()=>setTimeout(NEWSUI.next,700));

/* ===== HUD QUADRADO — estilo Free Fire ===== */
;(()=>{try{
const st=document.createElement('style');st.textContent=`
#hud{--u:clamp(46px,11vh,70px);--mm:clamp(110px,29vh,170px);--pw:clamp(110px,28vh,170px);--pu:#a855f7;color:#fff}
#hud #vm,#hud #cp,#hud #zb,#hud #hp,#hud #fps{display:none!important}
#hud .sq,#hud .sqs{border-radius:4px!important;width:var(--u)!important;height:var(--u)!important;padding:0;touch-action:none;display:grid;place-items:center;font-size:13px}
#hud .sq{background:linear-gradient(#2a2e3e,#151824);border:2px solid rgba(225,230,245,.75);color:#fff;box-shadow:inset 0 0 0 2px rgba(0,0,0,.45),0 2px 6px rgba(0,0,0,.5)}
#hud .sq.pu{border-color:var(--pu);box-shadow:inset 0 0 0 2px rgba(0,0,0,.45),0 0 8px rgba(168,85,247,.55)}
#hud .sq.on{background:linear-gradient(#7c3aed,#4c1d95);border-color:#e9d5ff}
#hud .sq:active,#hud .sqs:active{transform:scale(.92);filter:brightness(1.3)}
#hud .sq svg{width:64%;height:64%;pointer-events:none}
#hud .sq b.n{position:absolute;right:4px;bottom:0;font:700 19px var(--f);text-shadow:0 1px 3px #000}
#hud #bj{right:2%;top:58%;bottom:auto}#hud #bz{right:2%;top:42%;bottom:auto;width:calc(var(--u)*.9)!important;height:calc(var(--u)*.9)!important}
#hud #bf{right:8.5%;top:auto;bottom:30%;width:calc(var(--u)*1.9)!important;height:calc(var(--u)*1.9)!important;background:linear-gradient(#2a2e3e,#151824);border:3px solid rgba(225,230,245,.8);color:#fff;box-shadow:inset 0 0 0 2px rgba(0,0,0,.5),0 3px 10px rgba(0,0,0,.6)}
#hud #bf svg{width:70%;height:70%;pointer-events:none}
#hud #bc{right:7%;bottom:4%}#hud #bp{right:17.5%;bottom:6%}#hud #bs{right:25.5%;bottom:5%}
#hud #bi{right:27%;bottom:19%;left:auto;top:auto}#hud #bic{border-radius:3px}
#hud #br{left:31%;right:auto;bottom:19%}
#hud #bj small,#hud #bj{font-size:12px}
#hud #bg,#hud #bm,#hud #bn{left:1.5%;right:auto;bottom:auto}#hud #bg{top:36%}#hud #bm{top:49%}#hud #bn{top:62%}
#pad{position:absolute;left:10%;bottom:3%;width:var(--pw);height:var(--pw);background:rgba(20,24,18,.55);border:3px solid #cfd3dc;box-shadow:inset 0 0 0 3px rgba(0,0,0,.4);touch-action:none}
#pad i{position:absolute;color:rgba(255,255,255,.65);font:normal 22px/1 sans-serif;pointer-events:none}
#pad .u{left:50%;top:4px;transform:translateX(-50%)}#pad .d{left:50%;bottom:4px;transform:translateX(-50%)}#pad .l{left:6px;top:50%;transform:translateY(-50%)}#pad .r{right:6px;top:50%;transform:translateY(-50%)}
#padk{position:absolute;left:50%;top:50%;width:34%;height:34%;margin:-17% 0 0 -17%;background:linear-gradient(#aab2c8,#6a7390);border:3px solid #e6e9f2;pointer-events:none}
#hud #mm{left:1%;top:2%;width:var(--mm);height:var(--mm);border-radius:4px;border:2px solid #dfe3ee;box-shadow:0 0 0 2px rgba(0,0,0,.5);pointer-events:auto;z-index:3}
#mmo{position:absolute;left:1%;top:2%;width:var(--mm);height:var(--mm);pointer-events:none;z-index:4}
#mmo::before{content:'';position:absolute;left:50%;top:50%;width:62%;height:62%;transform:translate(-50%,-50%);border:2px solid rgba(255,255,255,.75);border-radius:50%}
#mmo svg{position:absolute;left:50%;top:50%;width:20%;transform:translate(-50%,-55%);filter:drop-shadow(0 0 3px #000)}
#hud.mmb #mm,#hud.mmb #mmo{width:min(78vh,62vw);height:min(78vh,62vw);left:50%;top:50%;transform:translate(-50%,-50%);z-index:9}
#ic2{position:absolute;left:calc(1% + var(--mm) + 10px);top:2%;display:flex;flex-direction:column;gap:7px}
#ic2 button{width:clamp(30px,7.5vh,40px);height:clamp(30px,7.5vh,40px);background:rgba(20,24,38,.8);border:2px solid #cfd3dc;border-radius:4px;font-size:18px;box-shadow:inset 0 0 0 2px rgba(0,0,0,.4)}
#ic2 button.off{opacity:.55;border-color:#ff4d5e}
#wf{position:absolute;left:calc(1% + var(--mm) + 70px);top:2%;font:600 20px var(--f);display:flex;gap:6px;align-items:center;text-shadow:0 1px 3px #000}
#sq2{position:absolute;left:1%;top:calc(2% + var(--mm) + 10px);width:clamp(120px,24vw,190px);display:flex;flex-direction:column;gap:3px;pointer-events:none}
#sq2 div{position:relative;display:flex;align-items:center;height:clamp(17px,4.4vh,24px);background:rgba(10,12,22,.6);font:600 clamp(12px,3vh,16px) var(--f);text-shadow:0 1px 2px #000}
#sq2 em{font-style:normal;width:clamp(17px,4.4vh,24px);height:100%;display:grid;place-items:center;color:#111;margin-right:6px}
#sq2 s{position:absolute;left:clamp(17px,4.4vh,24px);bottom:0;height:2px;background:#fff;width:80%}
#cmp{position:absolute;top:0;left:50%;transform:translateX(-50%);width:min(44vw,520px);height:clamp(26px,6.5vh,40px);overflow:hidden;background:linear-gradient(90deg,transparent,rgba(10,16,40,.7) 15%,rgba(10,16,40,.7) 85%,transparent);font:600 clamp(14px,3.6vh,20px) var(--f);pointer-events:none;text-shadow:0 1px 3px #000}
#cmp span{position:absolute;top:50%;transform:translate(-50%,-50%);opacity:.9}#cmp span.t{opacity:.55;font-size:.8em}
#cmp b{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);padding:0 6px;background:rgba(10,16,40,.85);color:#fff;border-bottom:2px solid var(--sun)}
#cmq{position:absolute;top:0;left:50%;transform:translateX(-50%);width:0;height:0;border:6px solid transparent;border-top:8px solid #fff;pointer-events:none}
#zn{position:absolute;top:clamp(28px,7.5vh,44px);left:50%;transform:translateX(-50%);display:none;align-items:center;gap:10px;padding:3px 26px;background:linear-gradient(90deg,transparent,rgba(10,20,50,.85) 15%,rgba(10,20,50,.85) 85%,transparent);font:600 clamp(15px,3.8vh,22px) var(--f);white-space:nowrap;pointer-events:none}
#hud.mt #zn{display:flex!important}#zn svg{width:1.3em;height:1.3em}
#hud #gi{top:clamp(60px,15vh,88px);font-size:clamp(13px,3.2vh,17px)}
#hud #pt{top:clamp(30px,8vh,46px)}
#tb{position:absolute;top:0;right:0;display:flex;height:clamp(26px,6.5vh,38px);font:600 clamp(15px,3.8vh,22px) var(--f);align-items:stretch}
#tb>*{display:flex;align-items:center;gap:6px;padding:0 14px}
#tb .cn{background:linear-gradient(#0e5c91,#0a3f66)}#tb .cn i{font:700 15px sans-serif;font-style:normal;background:#f5b400;color:#4a3000;border-radius:50%;width:22px;height:22px;display:grid;place-items:center}
#tb .pl2{background:#13a0d8}#tb .kl{background:#c4262f}
#tgr{background:#1b2236;font-size:20px;padding:0 12px;pointer-events:auto}
#hud #back{top:auto;right:auto;left:1%;bottom:1.5%;font-size:15px;padding:2px 12px;z-index:2}
#hud #wpn{top:clamp(34px,8.5vh,50px);right:.8%;width:clamp(190px,24vw,290px);min-width:0;padding:4px 10px 8px;background:linear-gradient(135deg,rgba(14,18,34,.85),rgba(10,12,22,.85));border:2px solid rgba(205,210,225,.7);border-radius:3px;text-align:left}
#hud #wpn b{font-size:clamp(26px,7vh,40px)}#wpn small{font-size:clamp(14px,3.4vh,20px)}
#wi{position:absolute;right:8px;top:2px;width:46%;height:60%;color:#fff;font-style:normal}#wi svg{width:100%;height:100%}
#wpn u{display:block;height:3px;background:#fff;margin-top:3px;text-decoration:none}
#sl2{position:absolute;top:calc(clamp(34px,8.5vh,50px) + clamp(70px,17vh,100px));right:.8%;display:flex;gap:6px}
#sl2 button{position:relative;width:clamp(58px,8.3vw,84px);height:clamp(44px,12vh,70px);background:rgba(14,18,34,.8);border:2px solid rgba(205,210,225,.6);border-radius:3px;color:#fff;font:600 clamp(14px,3.5vh,20px) var(--f);padding:0}
#sl2 button.on{border-color:var(--sun);background:rgba(60,44,6,.8)}#sl2 button svg{width:70%;height:55%;position:absolute;left:12%;top:6%}#sl2 button span{position:absolute;left:8px;bottom:2px}
#hb{position:absolute;left:50%;bottom:1.2%;transform:translateX(-50%);width:min(36vw,430px);font:600 clamp(13px,3.4vh,18px) var(--f);pointer-events:none;text-shadow:0 1px 3px #000}
#hb .sk{display:flex;justify-content:flex-end;gap:8px;margin-bottom:3px}#hb .sk i{width:clamp(24px,6vh,34px);height:clamp(24px,6vh,34px);background:rgba(14,18,34,.75);border:2px solid #cfd3dc;border-radius:50%;display:grid;place-items:center;font-style:normal;font-size:clamp(13px,3.4vh,18px)}
#hb .rw{display:flex;align-items:center;gap:6px;margin-top:1px}#hb .rw>em{width:clamp(70px,13vw,100px);font-style:normal}
#hb .br{flex:1;height:clamp(7px,2vh,11px);background:rgba(255,255,255,.2)}#hb .br s{display:block;height:100%}
#hb .ep s{background:#ffc233}#hb .hp s{background:#fff}#hb .ei{display:flex;gap:4px;position:absolute;left:0;top:clamp(22px,6.5vh,38px)}
#xh{font-size:0!important;width:clamp(34px,8vh,52px);height:clamp(34px,8vh,52px);color:#fff}
#xh::before{content:'';position:absolute;inset:0;background:linear-gradient(currentColor,currentColor) 0 0/10px 3px,linear-gradient(currentColor,currentColor) 0 0/3px 10px,linear-gradient(currentColor,currentColor) 100% 0/10px 3px,linear-gradient(currentColor,currentColor) 100% 0/3px 10px,linear-gradient(currentColor,currentColor) 0 100%/10px 3px,linear-gradient(currentColor,currentColor) 0 100%/3px 10px,linear-gradient(currentColor,currentColor) 100% 100%/10px 3px,linear-gradient(currentColor,currentColor) 100% 100%/3px 10px;background-repeat:no-repeat}
#xh::after{content:'';position:absolute;left:50%;top:50%;width:4px;height:4px;margin:-2px;background:currentColor;border-radius:50%}
#hud.air #pad,#hud.air #hb .sk{display:none}
`;document.head.appendChild(st);

const sv=b=>`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${b}</svg>`;
const I={
bag:sv('<rect x=12 y=14 width=24 height=26 rx=3 fill=currentColor fill-opacity=.25 /><path d="M18 14v-4h12v4M12 28h24M20 28v4h8v-4"/>'),
med:sv('<rect x=8 y=14 width=32 height=26 rx=3 fill=currentColor fill-opacity=.2 /><path d="M17 14v-4h14v4M24 21v12M18 27h12"/>'),
gren:sv('<circle cx=22 cy=29 r=11 fill=currentColor fill-opacity=.25 /><path d="M22 18v-5h8M30 13l5-4M18 24l4-3"/>'),
jump:sv('<circle cx=24 cy=9 r=3.5 fill=currentColor /><path d="M24 15v13M24 19l-9-5M24 19l9-5M24 28l-8 10M24 28l9 7"/>'),
crouch:sv('<circle cx=19 cy=10 r=3.5 fill=currentColor /><path d="M20 16l-1 12 9 2M19 28l-8 3 6 9M22 19l12-3M34 12v10"/>'),
prone:sv('<circle cx=10 cy=28 r=3.5 fill=currentColor /><path d="M15 29h20l8 6M20 29l-3 8M35 29l9-3"/>'),
fire:sv('<path d="M10 38L30 10c4-3 8-2 9 0s0 6-3 9L16 40z" fill=currentColor fill-opacity=.3 /><path d="M8 32l-3 10 10-3M34 6l3-3M42 14l3 1"/>'),
scope:sv('<circle cx=24 cy=24 r=12 /><path d="M24 4v12M24 32v12M4 24h12M32 24h12"/><circle cx=24 cy=24 r=2 fill=currentColor />'),
reload:sv('<path d="M38 20a14 14 0 1 0 2 8M38 8v12H26"/>'),
run:sv('<circle cx=28 cy=9 r=3.5 fill=currentColor /><path d="M26 16l-5 9 7 4-2 10M21 25l-9 1M27 17l8 6M28 29l8 6"/>'),
smg:'<svg viewBox="0 0 64 32" fill="currentColor"><path d="M2 11h30l4-4h20v6h-9v5h-8l-2 4h-5v9h-8v-9h-6l-2 9H8l3-9H2z"/></svg>',
rifle:'<svg viewBox="0 0 64 32" fill="currentColor"><path d="M1 13h22l4-3h18l3-3h8v6h-8v3H33l-3 5h-4l-2 8h-7l3-8h-6v-3H1z"/></svg>',
pistol:'<svg viewBox="0 0 48 32" fill="currentColor"><path d="M6 8h34v8H26l-2 14h-9l2-14H6z"/></svg>',
fist:sv('<path d="M14 22v-8a3 3 0 0 1 6 0v-3a3 3 0 0 1 6 0v3a3 3 0 0 1 6 0v6a3 3 0 0 1 6 0v10c0 7-6 12-12 12s-12-5-12-12z" fill=currentColor fill-opacity=.3 />')};

const h=$('#hud');
// ---- botões existentes viram quadrados com ícone
const ico=(id,svg)=>{const b=$('#'+id);b.classList.add('sq');b.innerHTML=svg};
ico('bc',I.crouch);ico('bp',I.prone);ico('br',I.run);ico('bs',I.reload);ico('bz',I.scope);
const bj=$('#bj');bj.classList.add('sq');bj.innerHTML=I.jump;
new MutationObserver(()=>{if(!bj.querySelector('svg')&&bj.textContent=='Pular')bj.innerHTML=I.jump}).observe(bj,{childList:true,characterData:true,subtree:true});
$('#bf').classList.add('sqs');$('#bf').innerHTML=I.fire;$('#bi').classList.add('sqs');

// ---- novos elementos
h.insertAdjacentHTML('beforeend',`
<button id=bg class="act gb sq pu">${I.bag}</button>
<button id=bm class="act gb sq pu">${I.med}<b class=n id=bmn>5</b></button>
<button id=bn class="act gb sq pu">${I.gren}<b class=n id=bnn>2</b></button>
<div id=pad class=gb><i class=u>▲</i><i class=d>▼</i><i class=l>◀</i><i class=r>▶</i><div id=padk></div></div>
<div id=mmo><svg viewBox="0 0 20 20"><path d="M10 1l7 17-7-4-7 4z" fill="#3de0ff" stroke="#fff" stroke-width="1.5"/></svg></div>
<div id=ic2><button id=isd>🔊</button><button id=imc>🎤</button><button id=iem>😊</button><button id=ich>💬</button></div>
<div id=wf><svg width=22 height=18 viewBox="0 0 24 20" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><path d="M2 7a14 14 0 0 1 20 0M5.5 11a9 9 0 0 1 13 0M9 15a4 4 0 0 1 6 0"/></svg><b id=png>17</b></div>
<div id=sq2></div><div id=cmp></div><div id=cmq></div>
<div id=zn class=mo><svg viewBox="0 0 24 24"><path d="M12 2L1 21h22z" fill="#e0262f" stroke="#fff" stroke-width="1.5"/><path d="M12 9v5M12 16.5v2" stroke="#fff" stroke-width="2"/></svg><span id=znt></span></div>
<div id=tb><span class=cn><i>F</i><b id=tcn>0</b></span><span class=pl2>👤<b id=tpl>0</b></span><span class=kl>💀<b id=tkl>0</b></span><button id=tgr>⚙</button></div>
<div id=sl2><button class=on data-i=0><span>150</span>${I.smg}</button><button data-i=1><span>12</span>${I.pistol}</button><button data-i=2><span>∞</span>${I.fist}</button></div>
<div id=hb class=gb><div class=sk><i>🔥</i><i>🛡</i><i>💎</i><i>🔥</i></div><div class="rw ep"><em>EP <b id=epn>200/200</b></em><div class=br><s id=eps style="width:100%"></s></div></div><div class="rw hp"><em>HP <b id=hpv>200/200</b></em><div class=br><s id=hps2 style="width:100%"></s></div></div></div>`);
// arma: ícone e barra no painel
$('#wpn').insertAdjacentHTML('afterbegin','<i id=wi></i>');$('#wpn').insertAdjacentHTML('beforeend','<u id=wbar></u>');
$('#wi').innerHTML=I.smg;

// ---- joystick fixo
const pad=$('#pad'),pk=$('#padk');let pid=null;
const mv=e=>{const r=pad.getBoundingClientRect(),c=r.width/2;let x=e.clientX-r.left-c,y=e.clientY-r.top-c;const m=c*.55,l=Math.hypot(x,y);if(l>m){x*=m/l;y*=m/l}pk.style.transform=`translate(${x}px,${y}px)`;inp.jx=x/m;inp.jy=-y/m};
pad.addEventListener('pointerdown',e=>{if(P.run){P.run=false;$('#br').classList.remove('on')}pid=e.pointerId;pad.setPointerCapture(pid);mv(e)});
pad.addEventListener('pointermove',e=>{if(e.pointerId==pid)mv(e)});
const up=e=>{if(e.pointerId==pid){pid=null;pk.style.transform='';inp.jx=inp.jy=0}};
pad.addEventListener('pointerup',up);pad.addEventListener('pointercancel',up);

// ---- itens: cura, granada, mochila
let MED=5,GR=2,gcd=0,healing=0;window.__inv={med:n=>{MED+=n},gr:n=>{GR+=n}};
const heal=()=>{if(mode!='game'||G.dead||healing)return;if(MED<=0)return ICE.deny('Sem kits');if(PL.hp>=100)return ICE.deny('Vida cheia');healing=1;ICE.toast('Curando...','#58ff9a');beep(500,.05);
 setTimeout(()=>{healing=0;if(G.dead)return;PL.hp=Math.min(100,PL.hp+50);MED--;beep(700,.08);ICE.toast('+50 HP','#58ff9a')},1800)};
const gren=()=>{if(mode!='game'||G.dead||gcd)return;if(GR<=0)return ICE.deny('Sem granadas');GR--;gcd=1;setTimeout(()=>gcd=0,800);
 const d=new T.Vector3();cam.getWorldDirection(d);const x0=P.x,z0=P.z,tx=x0+d.x*13,tz=z0+d.z*13,m=new T.Mesh(new T.SphereGeometry(.22,8,6),new T.MeshBasicMaterial({color:0x222222})),t0=performance.now();sc.add(m);beep(200,.06);
 const iv=setInterval(()=>{const k=Math.min(1,(performance.now()-t0)/1100);m.position.set(x0+(tx-x0)*k,1.5+12*k*(1-k)-1.3*k,z0+(tz-z0)*k);
  if(k>=1){clearInterval(iv);sc.remove(m);ICE.burst(tx,1,tz,34,1.5,1.5,9,0);beep(90,.25);try{for(const e of G.e)if(e.a&&Math.hypot(e.x-tx,e.z-tz)<6)hurt(e,70,PL);for(const w of ICE.w.slice())if(Math.hypot(w.x-tx,w.z-tz)<6)ICE.dmg(w,200)}catch(_){}}},30)};
const bag=()=>{if(mode!='game')return;modal('Mochila',`<div style="font:600 22px var(--f);line-height:1.7">🔫 Munição: 150<br>🩹 Kits médicos: ${MED}<br>💣 Granadas: ${GR}<br>🧊 Gelo: ${ICE.n}</div>`)};
$('#bm').addEventListener('pointerdown',heal);$('#bn').addEventListener('pointerdown',gren);$('#bg').addEventListener('pointerdown',bag);

// ---- armas (slots)
const sel=i=>WLD.sel(i);
document.querySelectorAll('#sl2 button').forEach(b=>b.addEventListener('pointerdown',()=>sel(+b.dataset.i)));
// ---- MIRA DE LUNETA (só em armas com luneta; pistola/punho não mostram)
document.head.insertAdjacentHTML('beforeend',`<style id=scpcss>
#scp{position:absolute;inset:0;display:none;pointer-events:none;z-index:0}#scp.on{display:block}
#scp .ln{position:absolute;left:50%;top:46%;width:60vh;height:60vh;transform:translate(-50%,-50%);border-radius:50%;background:radial-gradient(circle,transparent 58%,rgba(0,0,0,.38) 100%);box-shadow:inset 0 0 3vh 1vh rgba(0,0,0,.55)}
#scp .ln::before{content:'';position:absolute;inset:-5vh;border-radius:50%;border:5vh solid #0d0d10;box-shadow:inset 0 0 0 .5vh #3b3b45,inset 0 0 2vh #000,0 0 0 .4vh #000,0 1vh 3vh rgba(0,0,0,.6)}
#scp .bd{position:absolute;left:50%;transform:translateX(-50%);top:calc(46% + 33vh);bottom:0;width:36vh;background:linear-gradient(90deg,#050507,#1b1b21 40%,#1b1b21 60%,#050507);clip-path:polygon(6% 0,94% 0,100% 100%,0 100%)}
#scp .tu{position:absolute;left:calc(50% + 33vh);top:calc(46% - 5vh);width:7vh;height:10vh;background:linear-gradient(90deg,#1b1b21,#050507);border-radius:1vh;box-shadow:0 0 0 .3vh #000}
#scp svg{position:absolute;inset:0;width:100%;height:100%}
</style>`);
$('#hud').insertAdjacentHTML('afterbegin',`<div id=scp><i class=bd></i><i class=tu></i><div class=ln><svg viewBox="0 0 100 100"><g stroke="#000" opacity=".75" stroke-width=".3"><path d="M44 50H47M53 50H56M50 44V47M50 53V56"/></g><circle cx=50 cy=50 r=.9 fill="#ff2b24"/><circle cx=50 cy=50 r=1.8 fill="none" stroke="#ff2b24" stroke-width=".25" opacity=".6"/></svg></div></div>`);
const zb=$('#bz'),zo=zb.onpointerdown;
zb.onpointerdown=e=>{zo&&zo.call(zb,e);scTick()};
function scTick(){const g=mode=='game'&&!G.dead&&cam.fov<50;
 if(g){const t=WLD.zoom();if(Math.abs(cam.fov-t)>.1){cam.fov=t;cam.updateProjectionMatrix()}}
 const on=!!(g&&WLD.scope());window.__scoped=on;$('#scp').classList.toggle('on',on);const x=$('#xh');if(x)x.style.visibility=on?'hidden':''}
setInterval(scTick,50);


// ---- ícones laterais, minimapa e engrenagem
let vol0=S.vol||.5;
$('#isd').onclick=e=>{if(S.vol){vol0=S.vol;S.vol=0}else S.vol=vol0;e.target.textContent=S.vol?'🔊':'🔇';e.target.classList.toggle('off',!S.vol)};
$('#imc').onclick=e=>{e.target.classList.toggle('off');e.target.textContent=e.target.classList.contains('off')?'🔇':'🎤'};
const EMO=['😊','😂','😎','😡','👍','🔥'];let ei=0;$('#iem').onclick=()=>{ICE.toast(EMO[ei++%EMO.length],'#fff');beep(700,.04)};
const CH=['Preciso de ajuda!','Inimigo à frente!','Vamos avançar!','Boa jogada!'];let ci=0;$('#ich').onclick=()=>{ICE.toast('💬 '+CH[ci++%CH.length],'#ffe27a');beep(500,.04)};
$('#mm').addEventListener('pointerdown',()=>h.classList.toggle('mmb'));
$('#tgr').onclick=()=>{const b=document.querySelector('#lobby [data-m=set]');if(b)b.click()};
addEventListener('keydown',e=>{if(mode!='game')return;const k=e.key.toLowerCase();if(k=='h')heal();if(k=='g')gren();if(k=='b')bag();if(k>='1'&&k<='3')sel(k-1)});

// ---- reset ao iniciar partida
const _sm=setMode;setMode=function(m){_sm(m);if(m=='game'){MED=5;GR=2;h.classList.remove('mmb');WLD.reset()}else{const u=me.userData;if(u.gun){while(u.gun.children.length)u.gun.remove(u.gun.children[0]);while(u.bk.children.length)u.bk.remove(u.bk.children[0]);u._hk=u._bk=undefined}}};

// ---- atualização do HUD
const LET={0:'N',45:'NE',90:'E',135:'SE',180:'S',225:'SW',270:'W',315:'NW'},COL=['#3de0ff','#ffa51f','#ff63c8','#a855f7'];let ping=17,pt=0;
const sq=$('#sq2');sq.innerHTML=[0,1,2,3].map(i=>`<div><em style="background:${COL[i]}">${i+1}</em><span class=nm></span><s></s></div>`).join('');
const tick=()=>{if(mode!='game')return;
 const d=((-P.yaw*57.3)%360+360)%360,c=Math.round(d/15)*15;let s='';for(let k=-90;k<=90;k+=15){const a=((c+k)%360+360)%360,x=50+((c+k-d)/150)*100;if(x<0||x>100)continue;s+=`<span class="${LET[a]?'':'t'}" style="left:${x}%">${LET[a]||a}</span>`}
 $('#cmp').innerHTML=s+`<b>${Math.round(d)%360}</b>`;
 const r=Math.max(0,30-G.zt);$('#znt').textContent=r>0&&G.m=='br'?`A zona segura fechará em ${String(r/60|0).padStart(2,'0')}:${String(Math.ceil(r)%60).padStart(2,'0')}`:'A zona segura está diminuindo';
 const v=$('#vm').textContent.match(/\d+/g)||[0,0];$('#tpl').textContent=v[0];$('#tkl').textContent=v[1]||0;$('#tcn').textContent=S.co|0;
 if(++pt%20==0){ping=Math.max(8,Math.min(60,ping+((Math.random()*8-4)|0)));$('#png').textContent=ping}
 {const nq={br:4,cs:3}[S.gm]||1;sq.querySelectorAll('div').forEach((d,i)=>d.style.display=i<nq?'':'none')}
 sq.querySelector('.nm')&&sq.querySelectorAll('.nm').forEach((n,i)=>{n.textContent=i?'VIOXAR_0'+(i+1):($('#pn').textContent||'VIOXAR_01')});
 sq.querySelector('s').style.width=Math.max(0,PL.hp)+'%';
 const hp=Math.ceil(Math.max(0,PL.hp)*2);$('#hpv').textContent=hp+'/200';$('#hps2').style.width=hp/2+'%';
 window.__ep=Math.max(0,Math.min(200,(window.__ep??200)+(P.run?-1.2:.5)));$('#epn').textContent=Math.round(window.__ep)+'/200';$('#eps').style.width=window.__ep/2+'%';
 if(!WLD.w()){$('#wa').textContent='∞';$('#wm').textContent='';$('#wr').textContent='Punho'}
 $('#wbar').style.width=(AM.max?AM.n/AM.max*100:100)+'%';if(mode=='game')WLD.ui();$('#bmn').textContent=MED;$('#bnn').textContent=GR};
setInterval(tick,100);
}catch(err){console.error('HUD2',err)}})();

/* ===== EDITOR DE HUD ===== */
;(()=>{try{
const IDS={bj:'Pular',bc:'Agachar',bp:'Deitar',br:'Correr',bs:'Recarregar',bz:'Mira',bf:'Atirar',bi:'Gelo',bg:'Mochila',bm:'Cura',bn:'Granada',pad:'Joystick',mm:'Minimapa',sq2:'Time',ic2:'Atalhos',wpn:'Arma',sl2:'Slots de arma',hb:'Vida / EP',cmp:'Bússola',tb:'Barra superior',zn:'Aviso da zona',back:'Sair'};
const h=$('#hud');S.hudl=S.hudl||{};
let L=JSON.parse(JSON.stringify(S.hudl)),sel=null;
const st=document.createElement('style');st.id='hudcss';document.head.appendChild(st);
const css0=document.createElement('style');css0.textContent=`
#hud.edit>*{pointer-events:none!important}#hud.edit #bf{display:grid!important}#hud.edit #zn{display:flex!important}#hud.edit #xh{display:none!important}
#hud.edit .ed{outline:1.5px dashed rgba(255,255,255,.6);outline-offset:2px}#hud.edit .ed.sel{outline:3px solid #ffc233;box-shadow:0 0 14px #ffc233}
#he{position:fixed;inset:0;z-index:12;touch-action:none;cursor:grab}
#het{position:absolute;left:50%;bottom:2%;transform:translateX(-50%);display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:center;padding:8px 12px;background:rgba(8,10,24,.92);border:2px solid #a855f7;border-radius:4px;font:600 18px var(--f);max-width:96vw}
#het button{background:#2a2e3e;border:2px solid #cfd3dc;border-radius:3px;padding:2px 14px;font:600 18px var(--f);color:#fff}
#het .ok{background:#1bb86b;border-color:#bfffe0}#het .no{border-color:#ff4d5e}#het .sv{background:#ffc233;color:#1a1000;border-color:#fff}
#hel{position:absolute;left:50%;top:9%;transform:translateX(-50%);font:600 20px var(--f);background:rgba(8,10,24,.85);padding:2px 16px;border-left:4px solid #ffc233;pointer-events:none;white-space:nowrap}`;
document.head.appendChild(css0);
const render=()=>{let c='';for(const id in L){const o=L[id];if(!o)continue;const t=`left:${o.x}%!important;top:${o.y}%!important;right:auto!important;bottom:auto!important;transform:scale(${o.s||1})!important;transform-origin:0 0!important`;
 c+=id=='mm'?`#hud:not(.mmb) #mm,#hud:not(.mmb) #mmo{${t}}`:`#hud #${id}{${t}}`}st.textContent=c};
const elOf=id=>document.getElementById(id);
const hit=(x,y)=>{let b=null,ba=1e12;for(const id in IDS){const e=elOf(id);if(!e)continue;const r=e.getBoundingClientRect();if(r.width<2||!(x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom))continue;const a=r.width*r.height;if(a<ba){ba=a;b=id}}return b};
const mark=()=>{for(const id in IDS){const e=elOf(id);if(e){e.classList.add('ed');e.classList.toggle('sel',id==sel)}}$('#hel').textContent=sel?'Selecionado: '+IDS[sel]:'Toque e arraste um botão'};
const unmark=()=>{for(const id in IDS){const e=elOf(id);e&&e.classList.remove('ed','sel')}};
const base=id=>{const e=elOf(id),r=e.getBoundingClientRect(),o=L[id];return{x:r.left/innerWidth*100,y:r.top/innerHeight*100,s:o?o.s||1:1}};
let he=null,drag=null;
const open=()=>{if(mode!='lobby'){beep(220,.1);return}
 h.classList.remove('air','mmb');h.classList.add('edit');h.hidden=false;$('#lobby').hidden=true;
 he=document.createElement('div');he.id='he';he.innerHTML=`<div id=hel></div><div id=het><button id=hm>－</button><span>Tamanho</span><button id=hp2>＋</button><button id=hr class=no>Restaurar</button><button id=hc class=no>Cancelar</button><button id=hs class=sv>Salvar</button></div>`;document.body.appendChild(he);
 sel=null;L=JSON.parse(JSON.stringify(S.hudl));mark();
 he.addEventListener('pointerdown',e=>{if(e.target.closest('#het'))return;const id=hit(e.clientX,e.clientY);sel=id;mark();if(!id)return;const b=base(id);drag={id,sx:e.clientX,sy:e.clientY,b};he.setPointerCapture(e.pointerId);beep(600,.03)});
 he.addEventListener('pointermove',e=>{if(!drag)return;const r=elOf(drag.id).getBoundingClientRect(),dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
  let x=drag.b.x+dx/innerWidth*100,y=drag.b.y+dy/innerHeight*100;x=Math.max(0,Math.min(100-r.width/innerWidth*100,x));y=Math.max(0,Math.min(100-r.height/innerHeight*100,y));
  L[drag.id]={x:+x.toFixed(2),y:+y.toFixed(2),s:drag.b.s};render()});
 const end=()=>{drag=null};he.addEventListener('pointerup',end);he.addEventListener('pointercancel',end);
 const sc=d=>{if(!sel)return beep(220,.05);const b=base(sel),s=Math.max(.5,Math.min(2,+((b.s)+d).toFixed(2)));L[sel]={x:+b.x.toFixed(2),y:+b.y.toFixed(2),s};render();beep(500,.03)};
 $('#hm').onclick=()=>sc(-.1);$('#hp2').onclick=()=>sc(.1);
 $('#hr').onclick=()=>{if(sel&&L[sel]){delete L[sel]}else L={};render();mark();beep(400,.05)};
 $('#hc').onclick=()=>close(0);$('#hs').onclick=()=>close(1);render()};
const close=ok=>{if(ok){S.hudl=JSON.parse(JSON.stringify(L));save()}else{L=JSON.parse(JSON.stringify(S.hudl));render()}
 unmark();he&&he.remove();he=null;h.classList.remove('edit');setMode('lobby');beep(ok?800:330,.08)};
window.HUDEDIT={reload:()=>{S.hudl=S.hudl||{};L=JSON.parse(JSON.stringify(S.hudl));render()},open,reset:()=>{S.hudl={};L={};save();render()}};
render();
}catch(err){console.error('HUDEDIT',err)}})();

/* ===== LOGIN / REGISTRO + SALVAMENTO POR CONTA ===== */
;(()=>{try{
const AK='tempesta_acc',SK='tempesta_sess';
const getA=()=>{try{const a=JSON.parse(localStorage.getItem(AK));if(a&&a.users)return a}catch(e){}return{next:10000,users:{}}};
const putA=a=>localStorage.setItem(AK,JSON.stringify(a));
const c53=s=>{let a=0xdeadbeef,b=0x41c6ce57;for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);a=Math.imul(a^c,2654435761);b=Math.imul(b^c,1597334677)}a=Math.imul(a^(a>>>16),2246822507)^Math.imul(b^(b>>>13),3266489909);b=Math.imul(b^(b>>>16),2246822507)^Math.imul(a^(a>>>13),3266489909);return(4294967296*(2097151&b)+(a>>>0)).toString(16)};
const hash=async(u,p)=>{const s='tempesta|'+u+'|'+p;try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}return'c'+c53(s)+c53(s+'x')};
/* DONOS: nomes de usuário que recebem TODAS as roupas automaticamente. Ao criar uma roupa nova, some o nome dela em ROUPAS. */
const DONOS=[],ROUPAS=['Sombra Real','Rei Dourado'];
/* PRESENTES: dá itens uma única vez para o nome de usuário indicado. Exemplo: {nome:'SeuNome',id:'dia1m',dia:1000000} */
const PRESENTES=[{nome:'owner',conta:10000,id:'dia1m',dia:1000000}];
const presentes=()=>{if(!S.id)return;S.pres=S.pres||{};let c=0;for(const g of PRESENTES)if(String(g.nome).toLowerCase()==String(S.name).toLowerCase()&&(!g.conta||S.id==g.conta)&&!S.pres[g.id]){S.pres[g.id]=1;S.dia=(S.dia|0)+(g.dia|0);S.coins=(S.coins|0)+(g.moedas|0);c=1}if(c){save();try{refresh()}catch(e){}}};
const dono=()=>{if(S.id&&DONOS.some(n=>n.toLowerCase()==String(S.name).toLowerCase())){S.inv=S.inv||[];let c=0;for(const r of ROUPAS)if(!S.inv.includes(r)){S.inv.push(r);c=1}if(c)save()}};
const st=document.createElement('style');st.textContent=`
#auth{position:absolute;left:50%;bottom:calc(20px + env(safe-area-inset-bottom));transform:translateX(-50%) skewX(-8deg);padding:6px 34px;background:var(--sun);color:var(--ink);font:700 clamp(30px,8vh,46px) var(--f);box-shadow:0 5px 0 #b57e00;white-space:nowrap;z-index:3}
#auth:active{transform:translateX(-50%) skewX(-8deg) translateY(3px);box-shadow:0 2px 0 #b57e00}
#lobby:not(.nolog) #auth{display:none}#lobby.nolog #go{display:none}
#au{position:fixed;inset:0;z-index:20;background:rgba(3,6,18,.82);display:flex;align-items:center;justify-content:center;pointer-events:auto}#au[hidden]{display:none}
.aub{position:relative;width:min(400px,92vw);max-height:94vh;overflow:auto;background:var(--panel);border-top:4px solid var(--sun);padding:14px 20px 18px;display:flex;flex-direction:column;gap:9px;backdrop-filter:blur(6px)}
.aut{display:flex;gap:6px}.aut button{flex:1;background:#16244f;padding:6px 0;font:600 22px var(--f);border-bottom:4px solid transparent;color:#fff}.aut button.on{border-color:var(--sun)}
.aub input{width:100%;box-sizing:border-box;padding:9px 10px;font-size:16px;background:#0b1430;color:#fff;border:1px solid var(--volt)}
#aue{margin:0;min-height:20px;color:#ff6b78;font:600 16px var(--f)}
.aug{background:var(--sun);color:var(--ink);font:700 28px var(--f);padding:4px 0}
.aux{position:absolute;right:8px;top:8px;background:none;color:#fff;font-size:18px;padding:2px 8px}`;
document.head.appendChild(st);
const lob=$('#lobby');lob.insertAdjacentHTML('beforeend','<button id=auth>REGISTRAR / ENTRAR</button>');
const au=document.createElement('div');au.id='au';au.hidden=true;
au.innerHTML=`<div class=aub><button class=aux id=aux>✕</button><div class=aut><button data-t=l class=on>ENTRAR</button><button data-t=r>REGISTRAR</button></div><input id=aun type=text placeholder="Nome de usuário" maxlength=16 autocomplete=username autocapitalize=off><input id=aup type=password placeholder="Senha" autocomplete=current-password><input id=auc type=password placeholder="Confirmar senha" autocomplete=new-password><p id=aue></p><button id=aug class=aug>ENTRAR</button></div>`;
document.body.appendChild(au);
let tab='l';
const setTab=t=>{tab=t;au.querySelectorAll('.aut button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));$('#auc').style.display=t=='r'?'':'none';$('#aug').textContent=t=='r'?'CRIAR CONTA':'ENTRAR';$('#aue').textContent=''};
const open=t=>{setTab(t||'l');au.hidden=false;beep(660,.05)},shut=()=>{au.hidden=true;$('#aup').value=$('#auc').value=''};
const sync=()=>{lob.classList.toggle('nolog',!S.id);if(!S.id){$('#pn').textContent='Convidado';$('#pid').textContent='Faça login para jogar'}};
const apply=data=>{for(const k of Object.keys(S))delete S[k];Object.assign(S,JSON.parse(JSON.stringify(S0)),data);S.mode=S.gm=='pe'?1:0;if(S.sh==null)S.sh=+S.q>0?1:0;dono();presentes();
 localStorage.setItem(SK,S.id);try{save();setChar();applyQ();applyF();refresh();HUDEDIT.reload()}catch(e){location.reload();return}sync()};
const go=async()=>{const u=$('#aun').value.trim(),p=$('#aup').value,err=m=>{$('#aue').textContent=m;beep(220,.08)};
 if(!/^[A-Za-z0-9_]{3,16}$/.test(u))return err('Nome: 3 a 16 letras, números ou _');
 if(p.length<4)return err('A senha precisa ter pelo menos 4 caracteres');
 const A=getA(),k=u.toLowerCase();let data;
 if(tab=='r'){if(p!==$('#auc').value)return err('As senhas não são iguais');if(A.users[k])return err('Esse nome já está em uso');
  const id=A.next;A.next=id+1;A.users[k]={name:u,id,h:await hash(k,p)};data={name:u,id};
  if(id==10000){try{const old=JSON.parse(localStorage.getItem('tempesta1'));if(old&&typeof old=='object')data=Object.assign(old,data)}catch(e){}}
  try{putA(A);localStorage.setItem('tempesta_u_'+id,JSON.stringify(data))}catch(e){return err('Não foi possível salvar os dados neste aparelho')}}
 else{const a=A.users[k];if(!a||a.h!==await hash(k,p))return err('Nome ou senha incorretos');
  try{data=JSON.parse(localStorage.getItem('tempesta_u_'+a.id)||'{}')}catch(e){data={}}data.id=a.id;data.name=a.name}
 apply(data);shut();beep(880,.1)};
au.querySelectorAll('.aut button').forEach(b=>b.onclick=()=>{setTab(b.dataset.t);beep(500,.04)});
$('#aug').onclick=go;$('#aux').onclick=shut;au.addEventListener('keydown',e=>{if(e.key=='Enter')go()});
$('#auth').onclick=()=>open('l');
const _ps=PM.start;PM.start=function(){if(!S.id){open('l');return}return _ps.apply(this,arguments)};
window.AUTH={open,logout:()=>{try{save()}catch(e){}localStorage.removeItem(SK);location.reload()}};
dono();presentes();sync();
}catch(err){console.error('AUTH',err)}})();

;(()=>{const _it=ICE.tick;ICE.tick=function(dt){_it.call(ICE,dt);try{WLD.tick(dt);GLD.tick(dt)}catch(e){console.error('WLD',e)}}})();
