/* Adaptações para Android e PC (não altera a lógica do jogo) */
(()=>{
 const touch=matchMedia('(pointer:coarse)').matches;
 /* evita menu de contexto / seleção por toque longo no celular */
 document.addEventListener('contextmenu',e=>{if(touch&&!/INPUT|TEXTAREA/.test(e.target.tagName))e.preventDefault()});
 /* Android: tela cheia + paisagem no primeiro toque (se o navegador permitir) */
 if(touch){
  const go=()=>{
   document.removeEventListener('touchend',go,true);
   const el=document.documentElement,fs=el.requestFullscreen||el.webkitRequestFullscreen;
   try{if(fs&&!document.fullscreenElement&&!navigator.standalone)Promise.resolve(fs.call(el)).then(()=>screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})).catch(()=>{})}catch(e){}
  };
  document.addEventListener('touchend',go,true);
 }
 /* PWA: funciona também offline depois do primeiro acesso */
 if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)){
  addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
 }
})();
